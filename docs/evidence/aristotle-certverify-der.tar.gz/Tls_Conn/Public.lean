module

public import C2lean.Public

@[expose] public section

noncomputable section

namespace «Tls_Conn»

open Ctype.integerBaseType Ctype.integerType Ctype.realFloatingType Ctype.floatingType Ctype.basicType Ctype.ctype Ctype.tag_definition pointer_value object_value loaded_value value
set_option compiler.extract_closed false

/-! The public interface of the translation unit: its tag definitions and named function handles.
State properties using these and `C2lean.Public.Vocab` (see `C2lean/Public.lean`).
`Program.lean` retains the function signatures and implementation. -/

open C2lean.Public

def tagDefs : List (String × Ctype.tag_definition) := [
  ("__cerb.imaxdiv_t", StructDef [("quot", none, Basic (Integer (Signed Intmax_t))), ("rem", none, Basic (Integer (Signed Intmax_t)))] [0, 8] none 16 8),
  ("__cerb.max_align_t", StructDef [("__max_align_ll", none, Basic (Integer (Signed LongLong))), ("__max_align_ld", none, Basic (Floating (RealFloating LongDouble)))] [0, 16] none 32 16),
  ("__cerb.__mbstate_t", StructDef [("__count", none, Basic (Integer (Signed Int_))), ("__value", none, Union "__cerb.__mbstate_t.__value")] [0, 4] none 8 4),
  ("__cerb.__mbstate_t.__value", UnionDef [("__wch", none, Basic (Integer (Unsigned Int_))), ("__wchb", none, Array_ (Basic (Integer Char)) (some 4))] 4 4),
  ("_G_fpos_t", StructDef [("__pos", none, Basic (Integer (Signed Long))), ("__state", none, Struct "__cerb.__mbstate_t")] [0, 8] none 16 8),
  ("_G_fpos64_t", StructDef [("__pos", none, Basic (Integer (Signed Long))), ("__state", none, Struct "__cerb.__mbstate_t")] [0, 8] none 16 8),
  ("div", StructDef [("quot", none, Basic (Integer (Signed Int_))), ("rem", none, Basic (Integer (Signed Int_)))] [0, 4] none 8 4),
  ("ldiv", StructDef [("quot", none, Basic (Integer (Signed Long))), ("rem", none, Basic (Integer (Signed Long)))] [0, 8] none 16 8),
  ("lldiv", StructDef [("quot", none, Basic (Integer (Signed LongLong))), ("rem", none, Basic (Integer (Signed LongLong)))] [0, 8] none 16 8),
  ("__cerbty_sigset_t", StructDef [("__val", none, Array_ (Basic (Integer (Unsigned Long))) (some 16))] [0] none 128 8),
  ("__cerbty_pthread_attr_t", StructDef [("__data", some (.AlignInteger 8), Array_ (Basic (Integer (Unsigned Ichar))) (some 56))] [0] none 56 8),
  ("__cerbty_pthread_barrier_t", StructDef [("__data", some (.AlignInteger 8), Array_ (Basic (Integer (Unsigned Ichar))) (some 32))] [0] none 32 8),
  ("__cerbty_pthread_barrierattr_t", StructDef [("__data", some (.AlignInteger 4), Array_ (Basic (Integer (Unsigned Ichar))) (some 4))] [0] none 4 4),
  ("__cerbty_pthread_cond_t", StructDef [("__data", some (.AlignInteger 8), Array_ (Basic (Integer (Unsigned Ichar))) (some 48))] [0] none 48 8),
  ("__cerbty_pthread_condattr_t", StructDef [("__data", some (.AlignInteger 4), Array_ (Basic (Integer (Unsigned Ichar))) (some 4))] [0] none 4 4),
  ("__pthread_internal_list", StructDef [("__prev", none, Pointer (Struct "__pthread_internal_list")), ("__next", none, Pointer (Struct "__pthread_internal_list"))] [0, 8] none 16 8),
  (
    "__pthread_mutex_s",
    StructDef
      [
        ("__lock", none, Basic (Integer (Signed Int_))),
        ("__count", none, Basic (Integer (Unsigned Int_))),
        ("__owner", none, Basic (Integer (Signed Int_))),
        ("__nusers", none, Basic (Integer (Unsigned Int_))),
        ("__kind", none, Basic (Integer (Signed Int_))),
        ("__spins", none, Basic (Integer (Signed Short))),
        ("__elision", none, Basic (Integer (Signed Short))),
        ("__list", none, Struct "__pthread_internal_list")
      ]
      [0, 4, 8, 12, 16, 20, 22, 24]
      none
      40
      8
  ),
  (
    "__cerbty_pthread_mutex_t",
    UnionDef [("__data", none, Struct "__pthread_mutex_s"), ("__size", none, Array_ (Basic (Integer Char)) (some 40)), ("__align", none, Basic (Integer (Signed Long)))] 40 8
  ),
  ("__cerbty_pthread_mutexattr_t", StructDef [("__data", some (.AlignInteger 4), Array_ (Basic (Integer (Unsigned Ichar))) (some 4))] [0] none 4 4),
  ("__cerbty_pthread_rwlock_t", StructDef [("__data", some (.AlignInteger 8), Array_ (Basic (Integer (Unsigned Ichar))) (some 56))] [0] none 56 8),
  ("__cerbty_pthread_rwlockattr_t", StructDef [("__data", some (.AlignInteger 8), Array_ (Basic (Integer (Unsigned Ichar))) (some 8))] [0] none 8 8),
  ("__cerb.fd_set", StructDef [("fds_bits", none, Array_ (Basic (Integer (Signed Long))) (some 16))] [0] none 128 8),
  ("timeval", StructDef [("tv_sec", none, Basic (Integer (Signed Long))), ("tv_usec", none, Basic (Integer (Signed Long)))] [0, 8] none 16 8),
  ("timespec", StructDef [("tv_sec", none, Basic (Integer (Signed Long))), ("tv_nsec", none, Basic (Integer (Signed Long)))] [0, 8] none 16 8),
  (
    "random_data",
    StructDef
      [
        ("fptr", none, Pointer (Basic (Integer (Signed Int_)))),
        ("rptr", none, Pointer (Basic (Integer (Signed Int_)))),
        ("state", none, Pointer (Basic (Integer (Signed Int_)))),
        ("rand_type", none, Basic (Integer (Signed Int_))),
        ("rand_deg", none, Basic (Integer (Signed Int_))),
        ("rand_sep", none, Basic (Integer (Signed Int_))),
        ("end_ptr", none, Pointer (Basic (Integer (Signed Int_))))
      ]
      [0, 8, 16, 24, 28, 32, 40]
      none
      48
      8
  ),
  (
    "drand48_data",
    StructDef
      [
        ("__x", none, Array_ (Basic (Integer (Unsigned Short))) (some 3)),
        ("__old_x", none, Array_ (Basic (Integer (Unsigned Short))) (some 3)),
        ("__c", none, Basic (Integer (Unsigned Short))),
        ("__init", none, Basic (Integer (Unsigned Short))),
        ("__a", none, Basic (Integer (Unsigned LongLong)))
      ]
      [0, 6, 12, 14, 16]
      none
      24
      8
  ),
  (
    "tm",
    StructDef
      [
        ("tm_sec", none, Basic (Integer (Signed Int_))),
        ("tm_min", none, Basic (Integer (Signed Int_))),
        ("tm_hour", none, Basic (Integer (Signed Int_))),
        ("tm_mday", none, Basic (Integer (Signed Int_))),
        ("tm_mon", none, Basic (Integer (Signed Int_))),
        ("tm_year", none, Basic (Integer (Signed Int_))),
        ("tm_wday", none, Basic (Integer (Signed Int_))),
        ("tm_yday", none, Basic (Integer (Signed Int_))),
        ("tm_isdst", none, Basic (Integer (Signed Int_))),
        ("tm_gmtoff", none, Basic (Integer (Signed Long))),
        ("tm_zone", none, Pointer (Basic (Integer Char)))
      ]
      [0, 4, 8, 12, 16, 20, 24, 28, 32, 40, 48]
      none
      56
      8
  ),
  ("itimerspec", StructDef [("it_interval", none, Struct "timespec"), ("it_value", none, Struct "timespec")] [0, 16] none 32 8),
  ("__cerb.FStar_Bytes_bytes", StructDef [("length", none, Basic (Integer (Unsigned Int_))), ("data", none, Pointer (Basic (Integer Char)))] [0, 8] none 16 8),
  ("__cerb.__m64", StructDef [("__v", some (.AlignInteger 8), Array_ (Basic (Integer (Signed Int_))) (some 2))] [0] none 8 8),
  ("__cerb.__m128", StructDef [("__v", some (.AlignInteger 16), Array_ (Basic (Floating (RealFloating Float))) (some 4))] [0] none 16 16),
  ("__cerb.__m128d", StructDef [("__v", some (.AlignInteger 16), Array_ (Basic (Floating (RealFloating Double))) (some 2))] [0] none 16 16),
  ("__cerb.__m128i", StructDef [("__v", some (.AlignInteger 16), Array_ (Basic (Integer (Signed LongLong))) (some 2))] [0] none 16 16),
  ("__cerb.__m512", StructDef [("__v", some (.AlignInteger 64), Array_ (Basic (Floating (RealFloating Float))) (some 16))] [0] none 64 64),
  ("__cerb.__m512i", StructDef [("__v", some (.AlignInteger 64), Array_ (Basic (Integer (Signed LongLong))) (some 8))] [0] none 64 64),
  ("__cerb.__m512d", StructDef [("__v", some (.AlignInteger 64), Array_ (Basic (Floating (RealFloating Double))) (some 8))] [0] none 64 64),
  ("__cerb.__m512bh", StructDef [("__v", some (.AlignInteger 64), Array_ (Basic (Integer (Signed Short))) (some 32))] [0] none 64 64),
  ("__cerb.__m128bh", StructDef [("__v", some (.AlignInteger 16), Array_ (Basic (Integer (Signed Short))) (some 8))] [0] none 16 16),
  (
    "termios",
    StructDef
      [
        ("c_iflag", none, Basic (Integer (Unsigned Int_))),
        ("c_oflag", none, Basic (Integer (Unsigned Int_))),
        ("c_cflag", none, Basic (Integer (Unsigned Int_))),
        ("c_lflag", none, Basic (Integer (Unsigned Int_))),
        ("c_line", none, Basic (Integer (Unsigned Ichar))),
        ("c_cc", none, Array_ (Basic (Integer (Unsigned Ichar))) (some 32)),
        ("c_ispeed", none, Basic (Integer (Unsigned Int_))),
        ("c_ospeed", none, Basic (Integer (Unsigned Int_)))
      ]
      [0, 4, 8, 12, 16, 17, 52, 56]
      none
      60
      4
  )
]

def Fn.«Tls_Conn#__c2l_endian_bswap64» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#__c2l_endian_bswap64"}

def Fn.«Tls_Conn#__c2l_endian_identity64» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#__c2l_endian_identity64"}

def Fn.time : _root_.C2lean.Public.CFun := {name:="time"}

def Fn.memcpy : _root_.C2lean.Public.CFun := {name:="memcpy"}

def Fn.memset : _root_.C2lean.Public.CFun := {name:="memset"}

def Fn.«Tls_Conn#load64» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#load64"}

def Fn.«Tls_Conn#store64» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#store64"}

def Fn.«Tls_Conn#FStar_UInt64_eq_mask» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#FStar_UInt64_eq_mask"}

def Fn.«Tls_Conn#FStar_UInt64_gte_mask» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#FStar_UInt64_gte_mask"}

def Fn.Tls_Conn_set_res : _root_.C2lean.Public.CFun := {name:="Tls_Conn_set_res"}

def Fn.Tls_Conn_fatal : _root_.C2lean.Public.CFun := {name:="Tls_Conn_fatal"}

def Fn.Tls_Conn_open_rec : _root_.C2lean.Public.CFun := {name:="Tls_Conn_open_rec"}

def Fn.Tls_Conn_run_ch : _root_.C2lean.Public.CFun := {name:="Tls_Conn_run_ch"}

def Fn.Tls_Conn_phase0 : _root_.C2lean.Public.CFun := {name:="Tls_Conn_phase0"}

def Fn.Tls_Conn_check_cfin : _root_.C2lean.Public.CFun := {name:="Tls_Conn_check_cfin"}

def Fn.Tls_Conn_phase1 : _root_.C2lean.Public.CFun := {name:="Tls_Conn_phase1"}

def Fn.Tls_Conn_phase2 : _root_.C2lean.Public.CFun := {name:="Tls_Conn_phase2"}

def Fn.Tls_Conn_input : _root_.C2lean.Public.CFun := {name:="Tls_Conn_input"}

def Fn.Tls_Conn_seal_app : _root_.C2lean.Public.CFun := {name:="Tls_Conn_seal_app"}

def Fn.Tls_Conn_close_notify : _root_.C2lean.Public.CFun := {name:="Tls_Conn_close_notify"}

def Fn.Tls_Conn_init : _root_.C2lean.Public.CFun := {name:="Tls_Conn_init"}

def Fn.Tls_Util_put_lit_go : _root_.C2lean.Public.CFun := {name:="Tls_Util_put_lit_go"}

def Fn.Tls_Util_ct_eq : _root_.C2lean.Public.CFun := {name:="Tls_Util_ct_eq"}

def Fn.Tls_Util_lit_at : _root_.C2lean.Public.CFun := {name:="Tls_Util_lit_at"}

def Fn.Tls_Crypto_make_nonce : _root_.C2lean.Public.CFun := {name:="Tls_Crypto_make_nonce"}

def Fn.Tls_Crypto_inc_seq : _root_.C2lean.Public.CFun := {name:="Tls_Crypto_inc_seq"}

def Fn.Tls_Crypto_last_nz : _root_.C2lean.Public.CFun := {name:="Tls_Crypto_last_nz"}

def Fn.Tls_State_first_nz : _root_.C2lean.Public.CFun := {name:="Tls_State_first_nz"}

def Fn.Tls_Hello_pick_suite : _root_.C2lean.Public.CFun := {name:="Tls_Hello_pick_suite"}

def Fn.Tls_Hello_has_u16 : _root_.C2lean.Public.CFun := {name:="Tls_Hello_has_u16"}

def Fn.Tls_Hello_scan_ks : _root_.C2lean.Public.CFun := {name:="Tls_Hello_scan_ks"}

def Fn.Tls_Hello_scan_alpn : _root_.C2lean.Public.CFun := {name:="Tls_Hello_scan_alpn"}

def Fn.Tls_Hello_scan_ext : _root_.C2lean.Public.CFun := {name:="Tls_Hello_scan_ext"}

def Fn.Tls_ChValid_validate_prefix : _root_.C2lean.Public.CFun := {name:="Tls_ChValid_validate_prefix"}

def Fn.Hacl_P256_ecdsa_sign_p256_sha2 : _root_.C2lean.Public.CFun := {name:="Hacl_P256_ecdsa_sign_p256_sha2"}

def Fn.Hacl_Hash_SHA2_hash_256 : _root_.C2lean.Public.CFun := {name:="Hacl_Hash_SHA2_hash_256"}

def Fn.Hacl_HMAC_compute_sha2_256 : _root_.C2lean.Public.CFun := {name:="Hacl_HMAC_compute_sha2_256"}

def Fn.Hacl_HKDF_expand_sha2_256 : _root_.C2lean.Public.CFun := {name:="Hacl_HKDF_expand_sha2_256"}

def Fn.Hacl_HKDF_extract_sha2_256 : _root_.C2lean.Public.CFun := {name:="Hacl_HKDF_extract_sha2_256"}

def Fn.Hacl_Curve25519_51_secret_to_public : _root_.C2lean.Public.CFun := {name:="Hacl_Curve25519_51_secret_to_public"}

def Fn.Hacl_Curve25519_51_ecdh : _root_.C2lean.Public.CFun := {name:="Hacl_Curve25519_51_ecdh"}

def Fn.Hacl_AEAD_Chacha20Poly1305_encrypt : _root_.C2lean.Public.CFun := {name:="Hacl_AEAD_Chacha20Poly1305_encrypt"}

def Fn.Hacl_AEAD_Chacha20Poly1305_decrypt : _root_.C2lean.Public.CFun := {name:="Hacl_AEAD_Chacha20Poly1305_decrypt"}

def Fn.EverCrypt_AEAD_encrypt_expand_aes128_gcm : _root_.C2lean.Public.CFun := {name:="EverCrypt_AEAD_encrypt_expand_aes128_gcm"}

def Fn.EverCrypt_AEAD_decrypt_expand_aes128_gcm : _root_.C2lean.Public.CFun := {name:="EverCrypt_AEAD_decrypt_expand_aes128_gcm"}

def Fn.«Tls_Conn#put_u8» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#put_u8"}

def Fn.«Tls_Conn#put_u16» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#put_u16"}

def Fn.«Tls_Conn#put_u24» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#put_u24"}

def Fn.«Tls_Conn#put_buf» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#put_buf"}

def Fn.«Tls_Conn#put_lit_c» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#put_lit_c"}

def Fn.«Tls_Conn#rd16» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#rd16"}

def Fn.«Tls_Conn#rd24» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#rd24"}

def Fn.«Tls_Conn#expand_label» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#expand_label"}

def Fn.«Tls_Conn#derive_secret» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#derive_secret"}

def Fn.«Tls_Conn#traffic_keys» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#traffic_keys"}

def Fn.«Tls_Conn#seq_ok» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#seq_ok"}

def Fn.«Tls_Conn#seal» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#seal"}

def Fn.«Tls_Conn#unseal» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#unseal"}

def Fn.«Tls_Conn#get_trlen» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#get_trlen"}

def Fn.«Tls_Conn#set_trlen» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#set_trlen"}

def Fn.«Tls_Conn#tr_add» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#tr_add"}

def Fn.«Tls_Conn#tr_hash» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#tr_hash"}

def Fn.«Tls_Conn#send_rec» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#send_rec"}

def Fn.«Tls_Conn#send_alert» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#send_alert"}

def Fn.«Tls_Conn#der_int» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#der_int"}

def Fn.«Tls_Conn#save32» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#save32"}

def Fn.«Tls_Conn#install_keys» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#install_keys"}

def Fn.«Tls_Conn#derived» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#derived"}

def Fn.«Tls_Conn#hs_secret» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#hs_secret"}

def Fn.«Tls_Conn#master_secret» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#master_secret"}

def Fn.«Tls_Conn#traffic_secrets» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#traffic_secrets"}

def Fn.«Tls_Conn#key_sched» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#key_sched"}

def Fn.«Tls_Conn#app_secret» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#app_secret"}

def Fn.«Tls_Conn#install_client_app» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#install_client_app"}

def Fn.«Tls_Conn#finished_mac» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#finished_mac"}

def Fn.«Tls_Conn#do_ext» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#do_ext"}

def Fn.«Tls_Conn#parse» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#parse"}

def Fn.«Tls_Conn#build_sh» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#build_sh"}

def Fn.«Tls_Conn#build_ee» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#build_ee"}

def Fn.«Tls_Conn#der_sig» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#der_sig"}

def Fn.«Tls_Conn#sign_cv» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#sign_cv"}

def Fn.«Tls_Conn#add_cert» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#add_cert"}

def Fn.«Tls_Conn#add_cv» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#add_cv"}

def Fn.«Tls_Conn#add_fin» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#add_fin"}

def Fn.«Tls_Conn#build_flight» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#build_flight"}

def Fn.«Tls_Conn#check_ch» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#check_ch"}

def Fn.«Tls_Conn#emit_sh» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#emit_sh"}

def Fn.«Tls_Conn#ecdh_part» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#ecdh_part"}

def Fn.«Tls_Conn#flight_part» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#flight_part"}

def Fn.«Tls_Conn#note_hello» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#note_hello"}

def Fn.«Tls_Conn#hello_part» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#hello_part"}

def Fn.«Tls_Conn#do_ch» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#do_ch"}

def Fn.«Tls_Conn#record_content_type» : _root_.C2lean.Public.CFun := {name:="Tls_Conn#record_content_type"}

