# Summary of changes for run fe04166e-e5af-4f78-aba2-a4f8b52705df
I proved every property you asked for (`der_sig` and `add_cv`) about the submitted `generated/Tls_Conn.c`. The proofs cover the actual function bodies and contain no `sorry`. They are partial-correctness results: each postcondition holds if the function returns. The configuration is Linux x86-64 with `-std=gnu11 -Igenerated -Icsrc/hacl -Icsrc/krml`. All supplied functions in the call graph have their bodies proved; nothing was left out of scope.

**Verified** (public contracts in `Spec/Tls_Conn/DerSig.lean`, `Spec/Tls_Conn/AddCv.lean` and `Spec/Tls_Conn/Helpers.lean`; vocabulary in `Spec/Tls_Conn/Model.lean`; build instructions in `Spec/BUILD.md`):
- **`der_sig`** (`TlsConnSpec.der_sig_spec`):
  - **Caller obligations:** `der` is an 80-byte buffer owned only by the call, so it cannot overlap `sig64`. `sig64` is a readable 64-byte buffer.
  - **Memory safety:** the call has no undefined behaviour, including inside the real `der_int`, `Tls_State_first_nz`, `put_u8`, `put_buf` and `memcpy` calls.
  - **Bounds and preservation:** the result `ret` satisfies \(8 \le ret \le 72\). `der[ret..80)` and all of `sig64` are unchanged.
  - **Encoding:** `der[0..ret)` is exactly one DER `SEQUENCE { INTEGER r, INTEGER s }` with short-form lengths and no trailing bytes.
  - **INTEGERs:** each INTEGER has the minimal non-negative encoding: no redundant leading `0x00`, exactly one `0x00` when the top bit is set, and `02 01 00` for an all-zero half. Read big-endian, they equal `r = sig64[0..32)` and `s = sig64[32..64)`.
- **`add_cv`** (`TlsConnSpec.add_cv_spec`):
  - **Caller obligations:** `st` is 512 bytes, `tr` 20480, `pkey` 32 and `rnd` 96, all readable. `fl` is a 14000-byte buffer owned only by the call, and `pos ≤ 12100`.
  - **Signing input:** `add_cv` signs the RFC 8446 server CertificateVerify input (64 spaces, the context string, `0x00`, then the SHA-256 of the stored transcript) with `pkey` and nonce `rnd[64..96)`.
  - **On success:** `fl[pos..)` holds `0x0F`, u24(4+l), `04 03`, u16(l), then the canonical DER encoding of the 64-byte signing output, whose INTEGER values are its two halves. The rest of `fl` is unchanged and the result is `pos+8+l`.
  - **On signing failure:** the result is `0` and `fl` is unchanged.
  - **Inputs:** `st`, `tr`, `pkey` and `rnd` are unchanged.
- **Helpers:** each also has its own proved memory-safety and functional contract: `Tls_State_first_nz`, `der_int`, `put_u8`, `put_u16`, `put_u24`, `put_buf`, `get_trlen`, `tr_hash`, `Tls_Util_put_lit_go`, `put_lit_c` and `sign_cv`.

**Assumed external contracts** (stated as explicit premises; they are not proved):
- **`Hacl_P256_ecdsa_sign_p256_sha2`** (`HaclP256SignContract`): it only reads the message, key and 32-byte nonce. It writes 64 bytes into an output buffer owned only by the call and returns a 1/0 status, related to its inputs by an abstract signing relation.
- **`Hacl_Hash_SHA2_hash_256`** (`HaclSha256Contract`): it writes a 32-byte digest of the first `input_len` bytes.
- **`memcpy` and `memset`:** the standard C library contracts.

Nothing about ECDSA or SHA-256 themselves is assumed or proved. The HACL* sources were not supplied, so their implementations are not verified.

**Other conditions:**
- `der_sig`'s contract has the precondition that every `sig64` entry is in 0..255, which always holds for a `uint8_t` array.
- `sign_cv` reads the string literal `"TLS 1.3, server CertificateVerify"`, so `sign_cv` and `add_cv` also hand a read-only share of that literal back to the caller. Their contracts state this explicitly.
- `put_buf`'s contract covers only `len > 0`; every call made here passes at least 3.
- No unresolved obligations remain.