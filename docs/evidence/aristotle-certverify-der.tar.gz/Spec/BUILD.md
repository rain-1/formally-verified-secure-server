# Building the public specifications

The public contracts for `generated/Tls_Conn.c` are the Lean modules under `Spec/Tls_Conn/`:

| Module | Contents |
| --- | --- |
| `Spec/Tls_Conn/Model.lean` | Mathematical vocabulary: byte strings, big-endian values, canonical DER INTEGER / ECDSA-Sig-Value encodings, TLS `uint16`/`uint24`, the CertificateVerify message, the signed context string and the stored transcript. |
| `Spec/Tls_Conn/Contracts.lean` | The assumed contracts of the HACL* functions `Hacl_P256_ecdsa_sign_p256_sha2` and `Hacl_Hash_SHA2_hash_256`. |
| `Spec/Tls_Conn/DerSig.lean` | Contract of `der_sig`. |
| `Spec/Tls_Conn/AddCv.lean` | Contract of `add_cv`. |
| `Spec/Tls_Conn/Helpers.lean` | Contracts of the helper functions called by `der_sig` and `add_cv`. |

They depend on the generated function-handle interface `Tls_Conn/Public.lean` and on the public
support sources `C2lean/Public.lean`, `C2lean/Public/{Types,Array,Integer,Resources}.lean`,
`C2lean/IList.lean` and `C2lean/IrisCompat.lean`, all delivered alongside.

## Fresh project

1. Install Lean `leanprover/lean4:v4.34.0` (e.g. with `elan`).
2. Place the delivered files in an empty directory, keeping their paths:
   `Spec/...`, `Tls_Conn/Public.lean`, `C2lean/...`.
3. Create `lean-toolchain` containing

   ```
   leanprover/lean4:v4.34.0
   ```

4. Create `lakefile.toml`:

   ```toml
   name = "tls_conn_public_spec"
   defaultTargets = ["Spec"]

   [[lean_lib]]
   name = "C2lean"
   globs = ["C2lean.+"]

   [[lean_lib]]
   name = "Tls_Conn"
   roots = ["Tls_Conn.Public"]

   [[lean_lib]]
   name = "Spec"
   globs = ["Spec.+"]

   [[require]]
   name = "iris"
   git = "https://github.com/leanprover-community/iris-lean"
   subDir = "Iris"
   rev = "391b22c69f63169c3b1c9dbb0ff736ebeef6514f"

   [[require]]
   name = "mathlib"
   git = "https://github.com/leanprover-community/mathlib4"
   rev = "5ed2965256430c3649e86755f9576b54eca72435"

   [[require]]
   name = "aesop"
   git = "https://github.com/leanprover-community/aesop"
   rev = "v4.34.0"

   [[require]]
   name = "batteries"
   git = "https://github.com/leanprover-community/batteries"
   rev = "v4.34.0"
   ```

5. From that directory run

   ```
   lake update
   lake exe cache get
   lake build Spec
   ```

## Reading the contracts

Each contract `foo_spec S hProp` is stated for an arbitrary C vocabulary `S` and takes the
abstract premise `LibCSpecs S` standing for the standard C library contracts (here only
`memcpy` and `memset` are used). Contracts are partial-correctness statements: their
postconditions describe the state if the function returns. External HACL* behaviour is not
proved; it appears as the explicit premises `HaclP256SignContract S sign` and
`HaclSha256Contract S sha256`.
