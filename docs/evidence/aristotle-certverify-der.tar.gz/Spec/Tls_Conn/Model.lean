module

@[expose] public section

/-!
# Mathematical vocabulary for the CertificateVerify specifications

Independent definitions used by the public contracts of `der_int`, `der_sig` and `add_cv` in
`generated/Tls_Conn.c`. Byte strings are lists of integers; a byte is an integer in `0 .. 255`.
-/

namespace TlsConnSpec

/-- Every entry of `bs` is an octet value in `0 .. 255`. -/
def IsBytes (bs : List Int) : Prop := ∀ b ∈ bs, 0 ≤ b ∧ b < 256

/-- The unsigned big-endian value of a byte string (`beValue [] = 0`). -/
def beValue (bs : List Int) : Int := bs.foldl (fun acc b => 256 * acc + b) 0

/-- `c` is the DER (X.690 §8.3, §10) content-octet string of the INTEGER whose value is the
nonnegative integer `v`:
* it is a nonempty string of octets;
* its first octet is below `0x80`, so the two's-complement value is nonnegative;
* it is minimal: it does not start with a `0x00` octet followed by an octet below `0x80`
  (a redundant leading zero), so a value needing a sign octet gets exactly one `0x00`;
* read as an unsigned big-endian number (equal to its two's-complement value, since the first
  octet is below `0x80`), it equals `v`. -/
def IsDerNonnegIntContent (c : List Int) (v : Int) : Prop :=
  IsBytes c ∧ c ≠ [] ∧ c.headD 0 < 128 ∧
  (∀ (c1 : Int) (rest : List Int), c = 0 :: c1 :: rest → 128 ≤ c1) ∧
  beValue c = v

/-- The DER TLV of an INTEGER with content octets `c`, with tag `0x02` and a short-form length
octet (valid when `c` has fewer than 128 octets). -/
def derIntegerTLV (c : List Int) : List Int := [0x02, (c.length : Int)] ++ c

/-- `enc` is exactly one DER `SEQUENCE { INTEGER r, INTEGER s }` (the ECDSA-Sig-Value
structure), with short-form length octets and nothing after it: tag `0x30`, the length of the
two INTEGER TLVs, and the TLVs of the canonical encodings of `r` and `s`. -/
def IsDerEcdsaSig (enc : List Int) (r s : Int) : Prop :=
  ∃ cr cs : List Int,
    IsDerNonnegIntContent cr r ∧ IsDerNonnegIntContent cs s ∧
    (derIntegerTLV cr ++ derIntegerTLV cs).length < 128 ∧
    enc = [0x30, ((derIntegerTLV cr ++ derIntegerTLV cs).length : Int)] ++
      derIntegerTLV cr ++ derIntegerTLV cs

/-- The two octets of `n`, most significant first (a TLS `uint16`). -/
def u16be (n : Int) : List Int := [n / 256 % 256, n % 256]

/-- The three octets of `n`, most significant first (a TLS `uint24`). -/
def u24be (n : Int) : List Int := [n / 65536 % 256, n / 256 % 256, n % 256]

/-- The TLS 1.3 (RFC 8446 §4.4.3) CertificateVerify handshake message carrying the signature
octets `sigBytes` under the scheme `ecdsa_secp256r1_sha256` (`0x0403`): handshake type `15`, a
24-bit body length `4 + |sigBytes|`, the scheme, the 16-bit signature length and the
signature octets. -/
def certificateVerifyMessage (sigBytes : List Int) : List Int :=
  [15] ++ u24be (4 + sigBytes.length) ++ u16be 0x0403 ++ u16be sigBytes.length ++ sigBytes

/-- The ASCII octets of a string literal (without its terminating NUL). -/
def asciiBytes (s : String) : List Int := s.toList.map fun c => (c.toNat : Int)

/-- The TLS 1.3 server CertificateVerify signature input for the transcript hash `th`
(RFC 8446 §4.4.3): 64 spaces, the context string, a zero separator and `th`. -/
def serverCvSignInput (th : List Int) : List Int :=
  List.replicate 64 32 ++ asciiBytes "TLS 1.3, server CertificateVerify" ++ [0] ++ th

/-- The handshake transcript stored in the connection state: the first
`st[240] + 256 * st[241]` bytes of the transcript buffer `tr`, or no bytes if that stored length
exceeds `20480`. -/
def storedTranscript (st tr : List Int) : List Int :=
  let n := st.getD 240 0 + 256 * st.getD 241 0
  tr.take (if 20480 < n then 0 else n).toNat

end TlsConnSpec
