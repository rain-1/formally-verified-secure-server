module

public import Tls_Conn.Public
public import C2lean.Public
public import Spec.Tls_Conn.Model
public import Spec.Tls_Conn.Contracts
public import Spec.Tls_Conn.AddCv

open scoped C2lean

@[expose] public section

/-!
# Public specifications of the helper functions of `generated/Tls_Conn.c`

Memory safety and functional correctness of the helpers called (directly or indirectly) by
`der_sig` and `add_cv`:

```c
uint32_t Tls_State_first_nz(uint8_t *b, uint32_t i);
static uint32_t put_u8(uint8_t *out, uint32_t pos, uint8_t v);
static uint32_t put_u16(uint8_t *out, uint32_t pos, uint32_t v);
static uint32_t put_u24(uint8_t *out, uint32_t pos, uint32_t v);
static uint32_t put_buf(uint8_t *out, uint32_t pos, uint8_t *src, uint32_t len);
static uint32_t der_int(uint8_t *out, uint32_t pos, uint8_t *src);
static uint32_t get_trlen(uint8_t *st);
static void tr_hash(uint8_t *st, uint8_t *tr, uint8_t *out);
uint32_t Tls_Util_put_lit_go(uint8_t *out, uint32_t pos, uint8_t *lit, uint32_t l, uint32_t j);
static uint32_t put_lit_c(uint8_t *out, uint32_t pos, uint8_t *lit, uint32_t l);
static uint32_t sign_cv(uint8_t *st, uint8_t *tr, uint8_t *pkey, uint8_t *nonce, uint8_t *der);
```

Byte buffers are lists of integers (`List Int`); "writable" means exclusive ownership (fraction
`1`), hence disjointness from every other buffer mentioned in the same contract; "readable"
means a share with any fraction `q`. All postconditions describe the state if the call returns.
Every contract takes the abstract C library premise `LibCSpecs S` (only `put_buf`, `der_int` and
`sign_cv` use it: `memcpy`, and `memset` for `sign_cv`).
-/

namespace TlsConnSpec

open Iris Iris.BI C2lean.Public Ctype

/-- The index of the first nonzero byte of `bs` among the positions `i, i+1, …, 30`, or `31` if
there is none (or `31 ≤ i`); position `31` itself is never inspected. This is the value returned
by `Tls_State_first_nz(b, i)`. -/
def firstNonzeroFrom (bs : List Int) (i : Nat) : Nat :=
  if 31 ≤ i then 31 else if bs.getD i 0 ≠ 0 then i else firstNonzeroFrom bs (i + 1)
termination_by 31 - i

/-- The DER INTEGER content octets that `der_int` writes for the 32-byte big-endian unsigned
integer `src`: the bytes of `src` from its first nonzero byte on (at least its last byte), preceded
by one `0x00` octet when the first of them is `≥ 0x80`. -/
def derIntContent (src : List Int) : List Int :=
  (if 128 ≤ src.getD (firstNonzeroFrom src 0) 0 then [0] else []) ++
    src.drop (firstNonzeroFrom src 0)

/-- Functional correctness and memory safety of `Tls_State_first_nz(b, i)`.

For a readable 32-byte buffer `b` (contents `bs`) and `i ≤ 31`, a returning call gives `b` back
unchanged and returns `firstNonzeroFrom bs i`: the first index `j` in `i .. 30` with `b[j] ≠ 0`,
or `31` if there is none. -/
def first_nz_spec {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (b : location) (bs : List Int) (q : ℚ) (i : Nat) (Q : value → PROP),
    -- PRECONDITIONS
    -- `b` holds 32 bytes;
    bs.length = 32 →
    -- the start index `i` is at most 31.
    i ≤ 31 →
    ⊢
    -- `b` is readable (any fraction `q`).
    S.array b «unsigned char» f_LVspecified_OVinteger q bs -∗
    -- POSTCONDITIONS (if `Tls_State_first_nz` returns)
    -- `b` is unchanged and the result is the index of the first nonzero byte from `i` on.
    (S.array b «unsigned char» f_LVspecified_OVinteger q bs -∗
      Q ((firstNonzeroFrom bs i : Nat) : Int)) -∗
    S.call Tls_Conn.Fn.Tls_State_first_nz [b, (i : Int)] Q

/-- Functional correctness and memory safety of `put_u8(out, pos, v)`.

For a writable buffer `out` (contents `vs`), an in-bounds index `pos` and a byte `v`, a returning
call stores `v` at `out[pos]`, leaves every other byte of `out` unchanged and returns `pos + 1`. -/
def put_u8_spec {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (out : location) (pos v : Int) (vs : List Int) (Q : value → PROP),
    -- PRECONDITIONS
    -- `0 ≤ pos < length of out` (the write `out[pos]` is in bounds);
    0 ≤ pos → pos < vs.length →
    -- `v` is a `uint8_t` value;
    0 ≤ v → v < 256 →
    -- `pos + 1` does not wrap around as a `uint32_t`.
    pos < 4294967295 →
    ⊢
    -- `out` is exclusively owned and writable.
    S.array out «unsigned char» f_LVspecified_OVinteger 1 vs -∗
    -- POSTCONDITIONS (if `put_u8` returns)
    -- `out[pos] = v`, the rest of `out` unchanged; the result is `pos + 1`.
    (S.array out «unsigned char» f_LVspecified_OVinteger 1
        (vs.take pos.toNat ++ [v] ++ vs.drop (pos.toNat + 1)) -∗
      Q ((pos + 1 : Int))) -∗
    S.call Tls_Conn.Fn.«Tls_Conn#put_u8» [out, pos, v] Q

/-- Functional correctness and memory safety of `put_u16(out, pos, v)`.

For a writable buffer `out` (contents `vs`) with room for two bytes at `pos` and a `uint32_t`
value `v`, a returning call stores the two low-order octets of `v`, most significant first
(`u16be v`), at `out[pos]`, `out[pos + 1]`, leaves the rest of `out` unchanged and returns
`pos + 2`. -/
def put_u16_spec {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (out : location) (pos v : Int) (vs : List Int) (Q : value → PROP),
    -- PRECONDITIONS
    -- `0 ≤ pos` and `pos + 2 ≤ length of out` (both writes are in bounds);
    0 ≤ pos → pos + 2 ≤ vs.length →
    -- `v` is a `uint32_t` value;
    0 ≤ v → v < 4294967296 →
    -- `pos + 2` does not wrap around as a `uint32_t`.
    pos + 2 ≤ 4294967295 →
    ⊢
    -- `out` is exclusively owned and writable.
    S.array out «unsigned char» f_LVspecified_OVinteger 1 vs -∗
    -- POSTCONDITIONS (if `put_u16` returns)
    -- `out[pos .. pos+2) = u16be v`, the rest of `out` unchanged; the result is `pos + 2`.
    (S.array out «unsigned char» f_LVspecified_OVinteger 1
        (vs.take pos.toNat ++ u16be v ++ vs.drop (pos.toNat + 2)) -∗
      Q ((pos + 2 : Int))) -∗
    S.call Tls_Conn.Fn.«Tls_Conn#put_u16» [out, pos, v] Q

/-- Functional correctness and memory safety of `put_u24(out, pos, v)`.

For a writable buffer `out` (contents `vs`) with room for three bytes at `pos` and a `uint32_t`
value `v`, a returning call stores the three low-order octets of `v`, most significant first
(`u24be v`), at `out[pos .. pos+3)`, leaves the rest of `out` unchanged and returns `pos + 3`. -/
def put_u24_spec {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (out : location) (pos v : Int) (vs : List Int) (Q : value → PROP),
    -- PRECONDITIONS
    -- `0 ≤ pos` and `pos + 3 ≤ length of out` (all three writes are in bounds);
    0 ≤ pos → pos + 3 ≤ vs.length →
    -- `v` is a `uint32_t` value;
    0 ≤ v → v < 4294967296 →
    -- `pos + 3` does not wrap around as a `uint32_t`.
    pos + 3 ≤ 4294967295 →
    ⊢
    -- `out` is exclusively owned and writable.
    S.array out «unsigned char» f_LVspecified_OVinteger 1 vs -∗
    -- POSTCONDITIONS (if `put_u24` returns)
    -- `out[pos .. pos+3) = u24be v`, the rest of `out` unchanged; the result is `pos + 3`.
    (S.array out «unsigned char» f_LVspecified_OVinteger 1
        (vs.take pos.toNat ++ u24be v ++ vs.drop (pos.toNat + 3)) -∗
      Q ((pos + 3 : Int))) -∗
    S.call Tls_Conn.Fn.«Tls_Conn#put_u24» [out, pos, v] Q

/-- Functional correctness and memory safety of `put_buf(out, pos, src, len)`.

For a writable buffer `out` (contents `vs`) and a readable buffer `src` holding exactly the
`len > 0` bytes `ss`, with `out[pos .. pos+len)` in bounds, a returning call copies `ss` to
`out[pos .. pos+len)` (with `memcpy`), leaves the rest of `out` and all of `src` unchanged and
returns `pos + len`. Since `out` is exclusively owned, the two buffers do not overlap, as `memcpy`
requires. -/
def put_buf_spec {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (out src : location) (pos len : Int) (vs ss : List Int) (q : ℚ) (Q : value → PROP),
    -- PRECONDITIONS
    -- `0 ≤ pos`, `0 < len` and `pos + len ≤ length of out` (the copy is in bounds);
    0 ≤ pos → 0 < len → pos + len ≤ vs.length →
    -- `src` holds exactly `len` bytes;
    (ss.length : Int) = len →
    -- `pos + len` does not wrap around as a `uint32_t`.
    pos + len ≤ 4294967295 →
    ⊢
    -- `out` is exclusively owned and writable (hence disjoint from `src`) ...
    S.array out «unsigned char» f_LVspecified_OVinteger 1 vs -∗
    -- ... and `src` is readable (any fraction `q`).
    S.array src «unsigned char» f_LVspecified_OVinteger q ss -∗
    -- POSTCONDITIONS (if `put_buf` returns)
    -- `out[pos .. pos+len) = ss`, the rest of `out` and `src` unchanged; result `pos + len`.
    (S.array out «unsigned char» f_LVspecified_OVinteger 1
        (vs.take pos.toNat ++ ss ++ vs.drop (pos.toNat + ss.length)) -∗
      S.array src «unsigned char» f_LVspecified_OVinteger q ss -∗
      Q ((pos + len : Int))) -∗
    S.call Tls_Conn.Fn.«Tls_Conn#put_buf» [out, pos, src, len] Q

/-- Functional correctness and memory safety of `der_int(out, pos, src)`.

For a writable buffer `out` (contents `vs`) with room for 35 bytes at `pos` and a readable
32-byte buffer `src` (contents `ss`, the big-endian unsigned integer `r`), a returning call writes
at `out[pos ..)` the DER INTEGER TLV `enc = 0x02, |c|, c` of `r`, where
`c = derIntContent ss` is the canonical (minimal, nonnegative) DER content of `r`, leaves the rest
of `out` and all of `src` unchanged, and returns `pos + |enc|`, with `3 ≤ |enc| ≤ 35`. -/
def der_int_spec {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (out src : location) (pos : Int) (vs ss : List Int) (q : ℚ) (Q : value → PROP),
    -- PRECONDITIONS
    -- `0 ≤ pos` and `pos + 35 ≤ length of out` (room for the longest TLV);
    0 ≤ pos → pos + 35 ≤ vs.length →
    -- `src` holds 32 bytes;
    ss.length = 32 →
    -- `pos + 35` does not wrap around as a `uint32_t`.
    pos + 35 ≤ 4294967295 →
    ⊢
    -- `out` is exclusively owned and writable (hence disjoint from `src`) ...
    S.array out «unsigned char» f_LVspecified_OVinteger 1 vs -∗
    -- ... and `src` is readable (any fraction `q`).
    S.array src «unsigned char» f_LVspecified_OVinteger q ss -∗
    -- POSTCONDITIONS (if `der_int` returns)
    (∀ (enc : List Int),
      -- the bytes written are the INTEGER TLV of the canonical DER content of `r`;
      ⌊enc = derIntegerTLV (derIntContent ss) ∧
        IsDerNonnegIntContent (derIntContent ss) (beValue ss) ∧
        3 ≤ enc.length ∧ enc.length ≤ 35⌋ -∗
      -- `out[pos .. pos+|enc|) = enc`, the rest of `out` is unchanged;
      S.array out «unsigned char» f_LVspecified_OVinteger 1
        (vs.take pos.toNat ++ enc ++ vs.drop (pos.toNat + enc.length)) -∗
      -- `src` is unchanged;
      S.array src «unsigned char» f_LVspecified_OVinteger q ss -∗
      -- and the result is the position after the TLV.
      Q ((pos + enc.length : Int))) -∗
    S.call Tls_Conn.Fn.«Tls_Conn#der_int» [out, pos, src] Q

/-- Functional correctness and memory safety of `get_trlen(st)`.

For a readable connection state `st` (contents `stv`) of at least 242 bytes, a returning call
gives `st` back unchanged and returns the stored transcript length `st[240] + 256 * st[241]`. -/
def get_trlen_spec {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (st : location) (stv : List Int) (q : ℚ) (Q : value → PROP),
    -- PRECONDITIONS
    -- `st` holds at least 242 bytes (so `st[240]`, `st[241]` are in bounds).
    242 ≤ stv.length →
    ⊢
    -- `st` is readable (any fraction `q`).
    S.array st «unsigned char» f_LVspecified_OVinteger q stv -∗
    -- POSTCONDITIONS (if `get_trlen` returns)
    -- `st` unchanged; result `st[240] + 256 * st[241]`.
    (S.array st «unsigned char» f_LVspecified_OVinteger q stv -∗
      Q ((stv.getD 240 0 + 256 * stv.getD 241 0 : Int))) -∗
    S.call Tls_Conn.Fn.«Tls_Conn#get_trlen» [st] Q

/-- Functional correctness and memory safety of `tr_hash(st, tr, out)`.

Assuming the HACL* contract `HaclSha256Contract S sha256` for `Hacl_Hash_SHA2_hash_256`: for a
readable connection state `st` (at least 242 bytes), a readable 20480-byte transcript buffer `tr`
and a writable 32-byte buffer `out`, a returning call stores into `out` a 32-byte `digest` with
`sha256 (storedTranscript stv trv) digest` — the hash of the first `st[240] + 256 * st[241]`
bytes of `tr`, or of no bytes if that stored length exceeds 20480 — and leaves `st` and `tr`
unchanged. -/
def tr_hash_spec {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (sha256 : List Int → List Int → Prop),
  -- ASSUMED EXTERNAL CONTRACT (HACL*, implementation not supplied)
  HaclSha256Contract S sha256 →
  ∀ (st tr out : location) (stv trv old : List Int) (qs qt : ℚ) (Q : value → PROP),
    -- PRECONDITIONS
    -- `st` holds at least 242 bytes, `tr` holds 20480 bytes, `out` holds 32 bytes.
    242 ≤ stv.length →
    trv.length = 20480 →
    old.length = 32 →
    ⊢
    -- `st` and `tr` readable (any fractions); `out` exclusively owned and writable.
    S.array st «unsigned char» f_LVspecified_OVinteger qs stv -∗
    S.array tr «unsigned char» f_LVspecified_OVinteger qt trv -∗
    S.array out «unsigned char» f_LVspecified_OVinteger 1 old -∗
    -- POSTCONDITIONS (if `tr_hash` returns)
    (∀ (digest : List Int),
      -- `digest` is the SHA-256 of the stored transcript;
      ⌊sha256 (storedTranscript stv trv) digest ∧ digest.length = 32⌋ -∗
      -- `st` and `tr` unchanged, `out` holds `digest`.
      S.array st «unsigned char» f_LVspecified_OVinteger qs stv -∗
      S.array tr «unsigned char» f_LVspecified_OVinteger qt trv -∗
      S.array out «unsigned char» f_LVspecified_OVinteger 1 digest -∗
      Q value.Vunit) -∗
    S.call Tls_Conn.Fn.«Tls_Conn#tr_hash» [st, tr, out] Q

/-- Functional correctness and memory safety of `Tls_Util_put_lit_go(out, pos, lit, l, j)`.

For a writable buffer `out` (contents `vs`), a readable buffer `lit` holding exactly `l` bytes
`ls`, `out[pos .. pos+l)` in bounds and `j ≤ l`, a returning call copies `lit[j .. l)` to
`out[pos+j .. pos+l)`, leaves the rest of `out` and all of `lit` unchanged and returns `pos + l`. -/
def put_lit_go_spec {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (out lit : location) (vs ls : List Int) (q : ℚ) (pos : Int) (j : Nat) (Q : value → PROP),
    -- PRECONDITIONS
    -- `0 ≤ pos` and `pos + l ≤ length of out`, where `l` is the length of `lit`;
    0 ≤ pos → pos + ls.length ≤ vs.length →
    -- `pos + l` does not wrap around as a `uint32_t`;
    pos + ls.length ≤ 4294967295 →
    -- the start index satisfies `j ≤ l`.
    j ≤ ls.length →
    ⊢
    -- `out` is exclusively owned and writable (hence disjoint from `lit`) ...
    S.array out «unsigned char» f_LVspecified_OVinteger 1 vs -∗
    -- ... and `lit` is readable (any fraction `q`).
    S.array lit «unsigned char» f_LVspecified_OVinteger q ls -∗
    -- POSTCONDITIONS (if `Tls_Util_put_lit_go` returns)
    -- `out[pos+j .. pos+l) = lit[j .. l)`, the rest of `out` and `lit` unchanged; result `pos + l`.
    (S.array out «unsigned char» f_LVspecified_OVinteger 1
        (vs.take (pos.toNat + j) ++ ls.drop j ++ vs.drop (pos.toNat + ls.length)) -∗
      S.array lit «unsigned char» f_LVspecified_OVinteger q ls -∗
      Q ((pos + ls.length : Int))) -∗
    S.call Tls_Conn.Fn.Tls_Util_put_lit_go [out, pos, lit, (ls.length : Int), (j : Int)] Q

/-- Functional correctness and memory safety of `put_lit_c(out, pos, lit, l)`.

For a writable buffer `out` (contents `vs`), a readable buffer `lit` holding exactly `l` bytes
`ls` and `out[pos .. pos+l)` in bounds, a returning call copies `lit` to `out[pos .. pos+l)`,
leaves the rest of `out` and all of `lit` unchanged and returns `pos + l`. -/
def put_lit_c_spec {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (out lit : location) (vs ls : List Int) (q : ℚ) (pos : Int) (Q : value → PROP),
    -- PRECONDITIONS
    -- `0 ≤ pos` and `pos + l ≤ length of out`, where `l` is the length of `lit`;
    0 ≤ pos → pos + ls.length ≤ vs.length →
    -- `pos + l` does not wrap around as a `uint32_t`.
    pos + ls.length ≤ 4294967295 →
    ⊢
    -- `out` is exclusively owned and writable (hence disjoint from `lit`) ...
    S.array out «unsigned char» f_LVspecified_OVinteger 1 vs -∗
    -- ... and `lit` is readable (any fraction `q`).
    S.array lit «unsigned char» f_LVspecified_OVinteger q ls -∗
    -- POSTCONDITIONS (if `put_lit_c` returns)
    -- `out[pos .. pos+l) = lit`, the rest of `out` and `lit` unchanged; result `pos + l`.
    (S.array out «unsigned char» f_LVspecified_OVinteger 1
        (vs.take pos.toNat ++ ls ++ vs.drop (pos.toNat + ls.length)) -∗
      S.array lit «unsigned char» f_LVspecified_OVinteger q ls -∗
      Q ((pos + ls.length : Int))) -∗
    S.call Tls_Conn.Fn.«Tls_Conn#put_lit_c» [out, pos, lit, (ls.length : Int)] Q

/-- Functional correctness and memory safety of `sign_cv(st, tr, pkey, nonce, der)`.

Assuming the HACL* contracts `HaclP256SignContract S sign` and `HaclSha256Contract S sha256`
(and the C library contracts `LibCSpecs S` for `memcpy`/`memset`): for the readable 512-byte
connection state `st`, 20480-byte transcript buffer `tr`, 32-byte private key `pkey` and 32-byte
nonce `nonce`, and the writable 80-byte buffer `der`, a returning call hashes the stored
transcript to `digest`, signs the TLS 1.3 server CertificateVerify input
`serverCvSignInput digest` with `pkey` and `nonce` (status `ok`, 64-byte signature `sig`),
writes the canonical DER `SEQUENCE { INTEGER r, INTEGER s }` `enc` of
`(r, s) = (sig[0..32), sig[32..64))` at the start of `der` (the rest of `der` unchanged), leaves
the read-only inputs unchanged, and returns `|enc|` (between 8 and 72) if signing succeeded and
`0` otherwise. The call also hands back a read-only share of the string literal
`"TLS 1.3, server CertificateVerify"`. -/
def sign_cv_spec {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (sign : List Int → List Int → List Int → Bool → List Int → Prop)
    (sha256 : List Int → List Int → Prop),
  -- ASSUMED EXTERNAL CONTRACTS (HACL*, implementations not supplied)
  HaclP256SignContract S sign →
  HaclSha256Contract S sha256 →
  ∀ (st tr pkey nonce der : location) (stv trv kv nv dv : List Int) (qs qt qk qn : ℚ)
    (Q : value → PROP),
    -- PRECONDITIONS
    -- buffer sizes: `st` 512, `tr` 20480, `pkey` 32, `nonce` 32, `der` 80 bytes.
    stv.length = 512 →
    trv.length = 20480 →
    kv.length = 32 →
    nv.length = 32 →
    dv.length = 80 →
    ⊢
    -- `st`, `tr`, `pkey`, `nonce` readable (any fractions); `der` exclusively owned, writable.
    S.array st «unsigned char» f_LVspecified_OVinteger qs stv -∗
    S.array tr «unsigned char» f_LVspecified_OVinteger qt trv -∗
    S.array pkey «unsigned char» f_LVspecified_OVinteger qk kv -∗
    S.array nonce «unsigned char» f_LVspecified_OVinteger qn nv -∗
    S.array der «unsigned char» f_LVspecified_OVinteger 1 dv -∗
    -- POSTCONDITIONS (if `sign_cv` returns)
    (∀ (digest sig enc : List Int) (ok : Bool),
      -- `digest` is the SHA-256 of the stored transcript, `ok`/`sig` the result of signing
      -- the CertificateVerify input with `pkey` and `nonce`, `sig` is a 64-byte string, and
      -- `enc` is the canonical DER `SEQUENCE { INTEGER r, INTEGER s }` of its two halves;
      ⌊sha256 (storedTranscript stv trv) digest ∧
        sign (serverCvSignInput digest) kv nv ok sig ∧ sig.length = 64 ∧ IsBytes sig ∧
        IsDerEcdsaSig enc (beValue (sig.take 32)) (beValue (sig.drop 32)) ∧
        8 ≤ enc.length ∧ enc.length ≤ 72⌋ -∗
      -- a read-only share of the string literal `"TLS 1.3, server CertificateVerify"`;
      (∃ ql : ℚ, S.points_to (global "Tls_Conn#__cerb_stringLit_sign_cv_0")
        (.Array_ char (some 34)) ql cvContextLiteral) -∗
      -- read-only inputs unchanged;
      S.array st «unsigned char» f_LVspecified_OVinteger qs stv -∗
      S.array tr «unsigned char» f_LVspecified_OVinteger qt trv -∗
      S.array pkey «unsigned char» f_LVspecified_OVinteger qk kv -∗
      S.array nonce «unsigned char» f_LVspecified_OVinteger qn nv -∗
      -- `der` starts with `enc`, the rest `der[|enc| .. 80)` is unchanged (also on failure);
      S.array der «unsigned char» f_LVspecified_OVinteger 1 (enc ++ dv.drop enc.length) -∗
      -- result: `|enc|` if signing succeeded, `0` otherwise.
      Q ((if ok then (enc.length : Int) else 0 : Int))) -∗
    S.call Tls_Conn.Fn.«Tls_Conn#sign_cv» [st, tr, pkey, nonce, der] Q

end TlsConnSpec
