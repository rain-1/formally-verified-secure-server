module

public import Tls_Conn.Public
public import C2lean.Public
public import Spec.Tls_Conn.Model
public import Spec.Tls_Conn.Contracts

open scoped C2lean

@[expose] public section

/-!
# Public specification of `add_cv` in `generated/Tls_Conn.c`

```c
static uint32_t
add_cv(uint8_t *st, uint8_t *tr, uint8_t *fl, uint32_t pos, uint8_t *pkey, uint8_t *rnd);
```

`add_cv` signs the TLS 1.3 server CertificateVerify input for the stored transcript and, on
success, appends the CertificateVerify handshake message (type 15, scheme `0x0403`) carrying the
DER-encoded signature to the flight buffer `fl` at offset `pos`.
-/

namespace TlsConnSpec

open Iris Iris.BI C2lean.Public Ctype

/-- The context string signed by `sign_cv` (called by `add_cv`). -/
def cvContextString : String := "TLS 1.3, server CertificateVerify"

/-- The stored value of the read-only C string literal `"TLS 1.3, server CertificateVerify"`
(`char[34]`, NUL-terminated) used by `sign_cv`. -/
def cvContextLiteral : loaded_value :=
  .LVspecified (.OVarray ((asciiBytes cvContextString ++ [0]).map f_LVspecified_OVinteger))

/-- Functional correctness and memory safety of `add_cv(st, tr, fl, pos, pkey, rnd)`.

Inputs (from the contract of `Tls.Flight.add_cv`): `st` is the 512-byte connection state,
`tr` the 20480-byte transcript buffer, `fl` the 14000-byte flight buffer with
`pos ≤ 12100`, `pkey` the 32-byte private key and `rnd` 96 random bytes (the signing nonce is
`rnd[64..96)`); `fl` is exclusively owned and so disjoint from the read-only inputs.

Assuming the HACL* contracts `HaclP256SignContract S sign` and `HaclSha256Contract S sha256`
(and the C library contracts `LibCSpecs S` for `memcpy`/`memset`), if `add_cv` returns, then
for the transcript digest `digest` and the signing status/output `ok`, `sig` (64 bytes),
and with `enc` the canonical DER encoding of `(r, s) = (sig[0..32), sig[32..64))`:
* if signing succeeded (`ok`), `fl[pos ..)` holds
  `certificateVerifyMessage enc = 15, u24(4 + |enc|), 0x04 0x03, u16(|enc|), enc`, the rest of
  `fl` is unchanged, and the result is `pos + 8 + |enc|`;
* if signing failed, `fl` is unchanged and the result is `0`;
all read-only inputs are unchanged. The call also hands back a read-only share of the string
literal used by `sign_cv`. -/
def add_cv_spec {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (sign : List Int → List Int → List Int → Bool → List Int → Prop)
    (sha256 : List Int → List Int → Prop),
  -- ASSUMED EXTERNAL CONTRACTS (HACL*, implementations not supplied)
  HaclP256SignContract S sign →
  HaclSha256Contract S sha256 →
  ∀ (st tr fl : location) (pos : Int) (pkey rnd : location)
    (stv trv flv kv rv : List Int) (qs qt qk qr : ℚ) (Q : value → PROP),
    -- PRECONDITIONS
    -- buffer sizes: `st` 512, `tr` 20480, `fl` 14000, `pkey` 32, `rnd` 96 bytes;
    stv.length = 512 →
    trv.length = 20480 →
    flv.length = 14000 →
    kv.length = 32 →
    rv.length = 96 →
    -- `pos ≤ 12100`;
    0 ≤ pos → pos ≤ 12100 →
    ⊢
    -- `st`, `tr`, `pkey`, `rnd` readable (any fractions); `fl` exclusively owned, writable.
    S.array st «unsigned char» f_LVspecified_OVinteger qs stv -∗
    S.array tr «unsigned char» f_LVspecified_OVinteger qt trv -∗
    S.array fl «unsigned char» f_LVspecified_OVinteger 1 flv -∗
    S.array pkey «unsigned char» f_LVspecified_OVinteger qk kv -∗
    S.array rnd «unsigned char» f_LVspecified_OVinteger qr rv -∗
    -- POSTCONDITIONS (if `add_cv` returns)
    (∀ (digest sig enc : List Int) (ok : Bool),
      -- `digest` is the SHA-256 of the stored transcript, `ok`/`sig` the result of signing
      -- the CertificateVerify input with `pkey` and nonce `rnd[64..96)`, and `enc` is the
      -- canonical DER `SEQUENCE { INTEGER r, INTEGER s }` of the two halves of `sig`;
      ⌊sha256 (storedTranscript stv trv) digest ∧
        sign (serverCvSignInput digest) kv (rv.drop 64) ok sig ∧ sig.length = 64 ∧
        IsDerEcdsaSig enc (beValue (sig.take 32)) (beValue (sig.drop 32)) ∧
        8 ≤ enc.length ∧ enc.length ≤ 72⌋ -∗
      -- a read-only share of the string literal `"TLS 1.3, server CertificateVerify"`;
      (∃ ql : ℚ, S.points_to (global "Tls_Conn#__cerb_stringLit_sign_cv_0")
        (.Array_ char (some 34)) ql cvContextLiteral) -∗
      -- read-only inputs unchanged;
      S.array st «unsigned char» f_LVspecified_OVinteger qs stv -∗
      S.array tr «unsigned char» f_LVspecified_OVinteger qt trv -∗
      -- on success the message is written at `fl[pos ..)`, the rest of `fl` is unchanged;
      -- on failure `fl` is unchanged;
      S.array fl «unsigned char» f_LVspecified_OVinteger 1
        (if ok then
          flv.take pos.toNat ++ certificateVerifyMessage enc ++
            flv.drop (pos.toNat + 8 + enc.length)
         else flv) -∗
      S.array pkey «unsigned char» f_LVspecified_OVinteger qk kv -∗
      S.array rnd «unsigned char» f_LVspecified_OVinteger qr rv -∗
      -- result: the new end offset `pos + 8 + |enc|` on success, `0` on failure.
      Q ((if ok then pos + 8 + (enc.length : Int) else 0 : Int))) -∗
    S.call Tls_Conn.Fn.«Tls_Conn#add_cv» [st, tr, fl, pos, pkey, rnd] Q

end TlsConnSpec
