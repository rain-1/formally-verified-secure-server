module

public import Tls_Conn.Public
public import C2lean.Public
public import Spec.Tls_Conn.Model

open scoped C2lean

@[expose] public section

/-!
# Public specification of `der_sig` in `generated/Tls_Conn.c`

```c
static uint32_t der_sig(uint8_t *der, uint8_t *sig64);
```

`der_sig` converts the raw 64-byte ECDSA P-256 signature `sig64 = r || s` (two 32-byte
big-endian integers) into its DER encoding `SEQUENCE { INTEGER r, INTEGER s }` written at the
start of the 80-byte buffer `der`, and returns the number of bytes written.
-/

namespace TlsConnSpec

open Iris Iris.BI C2lean.Public Ctype

/-- Functional correctness, bounds and memory safety of `der_sig(der, sig64)`.

For an 80-byte writable buffer `der` (contents `dv`) and a readable 64-byte buffer `sig64`
(contents `sg`, a byte string), a call to `der_sig` that returns hands back both buffers and
returns `ret = enc.length` where `enc` is exactly one canonical DER
`SEQUENCE { INTEGER r, INTEGER s }` (`IsDerEcdsaSig`), with `r` the big-endian value of
`sig64[0..32)` and `s` that of `sig64[32..64)`; `8 ≤ ret ≤ 72`; `der[0..ret)` holds `enc`,
`der[ret..80)` is unchanged, and `sig64` is unchanged.

The C library contracts used (`memcpy`) are the abstract premise `LibCSpecs S`. -/
def der_sig_spec {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (der sig64 : location) (dv sg : List Int) (q : ℚ) (Q : value → PROP),
    -- PRECONDITIONS
    -- `der` holds 80 bytes and `sig64` holds 64 bytes.
    dv.length = 80 →
    sg.length = 64 →
    -- every entry of `sig64` is an octet (as for any `uint8_t` array).
    IsBytes sg →
    ⊢
    -- `der` is exclusively owned and writable (hence disjoint from `sig64`) ...
    S.array der «unsigned char» f_LVspecified_OVinteger 1 dv -∗
    -- ... and `sig64` is readable (any fraction `q`).
    S.array sig64 «unsigned char» f_LVspecified_OVinteger q sg -∗
    -- POSTCONDITIONS (if `der_sig` returns)
    (∀ (enc : List Int),
      -- the bytes written are the canonical DER encoding of `(r, s)`, of length 8 .. 72;
      ⌊IsDerEcdsaSig enc (beValue (sg.take 32)) (beValue (sg.drop 32)) ∧
        8 ≤ enc.length ∧ enc.length ≤ 72⌋ -∗
      -- `der` now starts with `enc`; the rest `der[enc.length .. 80)` is unchanged;
      S.array der «unsigned char» f_LVspecified_OVinteger 1 (enc ++ dv.drop enc.length) -∗
      -- `sig64` is unchanged;
      S.array sig64 «unsigned char» f_LVspecified_OVinteger q sg -∗
      -- and the return value is the encoding length.
      Q (enc.length : Int)) -∗
    S.call Tls_Conn.Fn.«Tls_Conn#der_sig» [der, sig64] Q

end TlsConnSpec
