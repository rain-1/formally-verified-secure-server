module

public import Tls_Conn.Public
public import C2lean.Public

open scoped C2lean

@[expose] public section

/-!
# Assumed contracts of the HACL* functions called by `add_cv`

`generated/Tls_Conn.c` calls `Hacl_P256_ecdsa_sign_p256_sha2` and `Hacl_Hash_SHA2_hash_256`,
whose implementations are not part of the supplied sources. The CertificateVerify results are
proved assuming the contracts below, stated relative to an abstract description of the
cryptographic results:

* `sign msg key nonce ok sig` describes the permitted outcomes of ECDSA-P256/SHA-256 signing:
  the returned status `ok` and the 64 bytes `sig` (`r || s`) written to `signature`;
* `sha256 input digest` describes the permitted 32-byte digests of `input`.

Taking `sign` and `sha256` to be the actual HACL* functional specifications gives the intended
results; nothing about ECDSA or SHA-256 themselves is assumed or proved.
-/

namespace TlsConnSpec

open Iris Iris.BI C2lean.Public Ctype

/-- Assumed contract of `bool Hacl_P256_ecdsa_sign_p256_sha2(uint8_t *signature,
uint32_t msg_len, uint8_t *msg, uint8_t *private_key, uint8_t *nonce)`:
given a writable 64-byte `signature` buffer and readable `msg` (`msg_len` bytes),
`private_key` (32 bytes) and `nonce` (32 bytes) buffers, it only reads the inputs, returns
them unchanged, and stores 64 bytes `sig` into `signature`, returning a status `ok`
(`true` = 1, `false` = 0) such that `sign msg private_key nonce ok sig` holds. The
writable buffer is disjoint from the inputs (it is owned exclusively); the inputs may overlap
each other. -/
def HaclP256SignContract {PROP : Type} [BI PROP] (S : Vocab PROP)
    (sign : List Int → List Int → List Int → Bool → List Int → Prop) : Prop :=
  ∀ (signature msg key nonce : location) (old m k n : List Int) (msg_len : Int)
    (qm qk qn : ℚ) (Q : value → PROP),
    old.length = 64 → k.length = 32 → n.length = 32 → msg_len = m.length →
    «unsigned int».hasType msg_len →
    ⊢ S.array signature «unsigned char» f_LVspecified_OVinteger 1 old -∗
      S.array msg «unsigned char» f_LVspecified_OVinteger qm m -∗
      S.array key «unsigned char» f_LVspecified_OVinteger qk k -∗
      S.array nonce «unsigned char» f_LVspecified_OVinteger qn n -∗
      (∀ (ok : Bool) (sig : List Int),
        ⌊sign m k n ok sig ∧ sig.length = 64⌋ -∗
        S.array signature «unsigned char» f_LVspecified_OVinteger 1 sig -∗
        S.array msg «unsigned char» f_LVspecified_OVinteger qm m -∗
        S.array key «unsigned char» f_LVspecified_OVinteger qk k -∗
        S.array nonce «unsigned char» f_LVspecified_OVinteger qn n -∗
        Q ((if ok then 1 else 0 : Int))) -∗
      S.call Tls_Conn.Fn.Hacl_P256_ecdsa_sign_p256_sha2 [signature, msg_len, msg, key, nonce] Q

/-- Assumed contract of `void Hacl_Hash_SHA2_hash_256(uint8_t *output, uint8_t *input,
uint32_t input_len)`: given a writable 32-byte `output` buffer and a readable buffer `input`
holding at least `input_len` bytes, it only reads `input`, returns it unchanged and stores into
`output` 32 bytes `digest` with `sha256 (first input_len bytes of input) digest`. -/
def HaclSha256Contract {PROP : Type} [BI PROP] (S : Vocab PROP)
    (sha256 : List Int → List Int → Prop) : Prop :=
  ∀ (output input : location) (old buf : List Int) (input_len : Int) (qi : ℚ)
    (Q : value → PROP),
    old.length = 32 → 0 ≤ input_len → input_len ≤ buf.length →
    «unsigned int».hasType input_len →
    ⊢ S.array output «unsigned char» f_LVspecified_OVinteger 1 old -∗
      S.array input «unsigned char» f_LVspecified_OVinteger qi buf -∗
      (∀ (digest : List Int),
        ⌊sha256 (buf.take input_len.toNat) digest ∧ digest.length = 32⌋ -∗
        S.array output «unsigned char» f_LVspecified_OVinteger 1 digest -∗
        S.array input «unsigned char» f_LVspecified_OVinteger qi buf -∗
        Q value.Vunit) -∗
      S.call Tls_Conn.Fn.Hacl_Hash_SHA2_hash_256 [output, input, input_len] Q

end TlsConnSpec
