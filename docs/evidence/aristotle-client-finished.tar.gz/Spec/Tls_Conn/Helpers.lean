module

public import Spec.Tls_Conn.Contracts

open scoped C2lean

@[expose] public section

/-!
# Public contracts of the functions reached by `Tls_Conn_input` in phase 1

Each `<function>_memory_safety` property states, for one C function of `generated/Tls_Conn.c`
reached from `Tls_Conn_input` while `st[0] == 1`, the preconditions under which a call is
memory safe (no undefined behaviour) and the postcondition that holds if the call returns.
They are the contracts used to compose the proof of the entry point.

Notation: `bytes_at S p q bs` owns fraction `q` of the `unsigned char` cells at `p` holding the
bytes `bs` (`q = 1`: writable). Distinct `bytes_at`/`S.array` resources are disjoint. A trailing
`True` premise in a postcondition hands back leftover resources (no claim about memory leaks).
-/

namespace TlsConnSpec

open Iris Iris.BI C2lean.Public C2lean.Public.Resources Ctype

/-! ## Pure helpers -/

/-- `Tls_Crypto_inc_seq(seq, i)`: big-endian increment with carry of the first `i` bytes. -/
def incPrefix (s : List ℤ) : ℕ → List ℤ
  | 0 => s
  | j + 1 => if s.getD j 0 = 255 then incPrefix (s.set j 0) j else s.set j (s.getD j 0 + 1)

/-- `Tls_Crypto_last_nz(b, n, i)`: the largest `j < i` with `b[j] ≠ 0`, or `n` if none. -/
def lastNz (b : List ℤ) (n : ℤ) : ℕ → ℤ
  | 0 => n
  | j + 1 => if b.getD j 0 ≠ 0 then (j : ℤ) else lastNz b n j

/-- The 8 write-sequence bytes `st[232, 240)` replaced by `w` (all other bytes kept). -/
def withWriteSeq (sb w : List ℤ) : List ℤ := sb.take 232 ++ w ++ sb.drop 240

/-- The 8 read-sequence bytes `st[180, 188)` replaced by `w` (all other bytes kept). -/
def withReadSeq (sb w : List ℤ) : List ℤ := sb.take 180 ++ w ++ sb.drop 188

/-- Outcome of `Tls_Conn_open_rec(st, inp, rlen, inner, ty)`: either the record was not opened
(`0xFFFFFFFF`, state unchanged) or it opened under the state's client read key, IV and sequence
number, the read sequence number advanced, and the content type was located (`0xFFFFFFFE`: all
plaintext bytes zero). -/
def OpenRecPost (m : AeadModel) (sb inb : List ℤ) (rlen r : ℤ) (sb' ib' tb' : List ℤ) : Prop :=
  sb'.length = 512 ∧ ib'.length = 16640 ∧ tb'.length = 1 ∧
  ((r = 4294967295 ∧ sb' = sb) ∨
   (r ≠ 4294967295 ∧
    openFirstRecord m sb inb rlen.toNat = some (ib'.take (rlen.toNat - 16)) ∧
    sb' = withReadSeq sb (incPrefix (slice sb 180 8) 8) ∧
    ((r = 4294967294 ∧ ∀ k, k < rlen.toNat - 16 → ib'.getD k 0 = 0) ∨
     (0 ≤ r ∧ r < rlen - 16 ∧ ib'.getD r.toNat 0 ≠ 0 ∧ tb' = [ib'.getD r.toNat 0] ∧
      ∀ k, r.toNat < k → k < rlen.toNat - 16 → ib'.getD k 0 = 0))))

/-- Outcome of `Tls_Conn_check_cfin(st, inner, out, res, consumed)`. -/
def CfinPost (sb ib : List ℤ) (consumed : ℤ) (sb' rb' : List ℤ) : Prop :=
  (slice ib 4 32 = finishedVerify (slice sb 8 32) (slice sb 104 32) →
    sb' = connectedState sb ∧ rb' = [consumed, 0, 0, 0]) ∧
  (slice ib 4 32 ≠ finishedVerify (slice sb 8 32) (slice sb 104 32) →
    (∃ w : List ℤ, w.length = 8 ∧ sb' = withWriteSeq sb w) ∧ rb'.length = 4 ∧
    rb'.getD 0 0 = consumed ∧ rb'.getD 2 0 = 0 ∧ rb'.getD 3 0 = 1)

/-- Outcome of `Tls_Conn_phase1(st, inp, rtype, rlen, out, res)` for a complete record of
`rlen` body bytes whose header type byte is `rtype`. -/
def Phase1RecordPost (m : AeadModel) (sb inb : List ℤ) (rtype rlen : ℤ) (sb' rb' : List ℤ) : Prop :=
  rb'.getD 2 0 = 0 ∧
  (sb'.getD 0 0 ≠ 1 →
    rtype = 23 ∧ 17 ≤ rlen ∧
    openFirstRecord m sb inb rlen.toNat =
      some (finishedMessage (finishedVerify (slice sb 8 32) (slice sb 104 32)) ++ [22] ++
        zeros (rlen.toNat - 16 - 37)) ∧
    sb' = connectedState sb ∧ rb' = [5 + rlen, 0, 0, 0]) ∧
  (sb'.getD 0 0 = 1 → sb'.length = sb.length ∧
    ∀ i, i < sb.length → ¬ (180 ≤ i ∧ i < 188) → ¬ (232 ≤ i ∧ i < 240) →
      sb'.getD i 0 = sb.getD i 0) ∧
  (rtype = 23 → 17 ≤ rlen → openFirstRecord m sb inb rlen.toNat = none →
    sb'.getD 0 0 = 1 ∧ slice sb' 180 8 = slice sb 180 8)

/-! ## Function contracts -/

/-- `static uint32_t put_u8(uint8_t *out, uint32_t pos, uint8_t v)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def put_u8_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (out : object_value) (pos v : ℤ) (bs : Bytes) (Q : value → PROP),
    «unsigned int».hasType pos → «unsigned char».hasType v →
    pos < bs.ilength → bs.ilength < 2 ^ 32 →
    ⊢ bytes_at S out 1 bs -∗
      (bytes_at S out 1 (bs.iset pos v) -∗ Q ((pos + 1 : ℤ) : value)) -∗
      S.call «Tls_Conn».Fn.«Tls_Conn#put_u8» [out, pos, v] Q

/-- `static uint32_t put_u16(uint8_t *out, uint32_t pos, uint32_t v)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def put_u16_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (out : object_value) (pos v : ℤ) (bs : Bytes) (Q : value → PROP),
    «unsigned int».hasType pos → «unsigned int».hasType v →
    pos + 2 ≤ bs.ilength → bs.ilength < 2 ^ 32 →
    ⊢ bytes_at S out 1 bs -∗
      (bytes_at S out 1 ((bs.iset pos (v / 256 % 256)).iset (pos + 1) (v % 256)) -∗
        Q ((pos + 2 : ℤ) : value)) -∗
      S.call «Tls_Conn».Fn.«Tls_Conn#put_u16» [out, pos, v] Q

/-- `static uint32_t put_buf(uint8_t *out, uint32_t pos, uint8_t *src, uint32_t len)`.
The source buffer is nonempty and the destination nonempty (as `memcpy` requires valid pointers
even for a zero count).

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def put_buf_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (out src : object_value) (pos len : ℤ) (bs sb : Bytes) (q : ℚ) (Q : value → PROP),
    «unsigned int».hasType pos → «unsigned int».hasType len →
    0 < bs.ilength → pos + len ≤ bs.ilength → bs.ilength < 2 ^ 32 →
    0 < sb.ilength → len ≤ sb.ilength →
    ⊢ bytes_at S out 1 bs -∗ bytes_at S src q sb -∗
      (bytes_at S out 1 (bs.itake pos ++ sb.itake len ++ bs.idrop (pos + len)) -∗
        bytes_at S src q sb -∗ Q ((pos + len : ℤ) : value)) -∗
      S.call «Tls_Conn».Fn.«Tls_Conn#put_buf» [out, pos, src, len] Q

/-- `uint32_t Tls_Util_put_lit_go(uint8_t *out, uint32_t pos, uint8_t *lit, uint32_t l, uint32_t j)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def put_lit_go_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (out lit : object_value) (pos l j : ℤ) (bs lb : Bytes) (q : ℚ) (Q : value → PROP),
    «unsigned int».hasType pos → «unsigned int».hasType l → «unsigned int».hasType j →
    j ≤ l → l ≤ lb.ilength → pos + l ≤ bs.ilength → bs.ilength < 2 ^ 32 →
    ⊢ bytes_at S out 1 bs -∗ bytes_at S lit q lb -∗
      (bytes_at S out 1
          (bs.itake (pos + j) ++ (lb.idrop j).itake (l - j) ++ bs.idrop (pos + l)) -∗
        bytes_at S lit q lb -∗ Q ((pos + l : ℤ) : value)) -∗
      S.call «Tls_Conn».Fn.Tls_Util_put_lit_go [out, pos, lit, l, j] Q

/-- `static uint32_t put_lit_c(uint8_t *out, uint32_t pos, uint8_t *lit, uint32_t l)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def put_lit_c_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (out lit : object_value) (pos l : ℤ) (bs lb : Bytes) (q : ℚ) (Q : value → PROP),
    «unsigned int».hasType pos → «unsigned int».hasType l →
    l ≤ lb.ilength → pos + l ≤ bs.ilength → bs.ilength < 2 ^ 32 →
    ⊢ bytes_at S out 1 bs -∗ bytes_at S lit q lb -∗
      (bytes_at S out 1 (bs.itake pos ++ lb.itake l ++ bs.idrop (pos + l)) -∗
        bytes_at S lit q lb -∗ Q ((pos + l : ℤ) : value)) -∗
      S.call «Tls_Conn».Fn.«Tls_Conn#put_lit_c» [out, pos, lit, l] Q

/-- `static uint32_t rd16(uint8_t *b, uint32_t pos)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def rd16_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (b : object_value) (pos : ℤ) (bs : Bytes) (q : ℚ) (Q : value → PROP),
    «unsigned int».hasType pos → pos + 2 ≤ bs.ilength → bs.ilength < 2 ^ 32 →
    ⊢ bytes_at S b q bs -∗
      (bytes_at S b q bs -∗ Q ((bs[pos]! * 256 + bs[pos + 1]! : ℤ) : value)) -∗
      S.call «Tls_Conn».Fn.«Tls_Conn#rd16» [b, pos] Q

/-- `static uint32_t rd24(uint8_t *b, uint32_t pos)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def rd24_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (b : object_value) (pos : ℤ) (bs : Bytes) (q : ℚ) (Q : value → PROP),
    «unsigned int».hasType pos → pos + 3 ≤ bs.ilength → bs.ilength < 2 ^ 32 →
    ⊢ bytes_at S b q bs -∗
      (bytes_at S b q bs -∗
        Q ((bs[pos]! * 65536 + bs[pos + 1]! * 256 + bs[pos + 2]! : ℤ) : value)) -∗
      S.call «Tls_Conn».Fn.«Tls_Conn#rd24» [b, pos] Q

/-- `void Tls_Conn_set_res(uint32_t *res, uint32_t c, uint32_t o, uint32_t a, uint32_t s)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def set_res_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (res : object_value) (c o a s : ℤ) (rb : Bytes) (Q : value → PROP),
    «unsigned int».hasType c → «unsigned int».hasType o → «unsigned int».hasType a →
    «unsigned int».hasType s → rb.ilength = 4 →
    ⊢ S.array res «unsigned int» f_LVspecified_OVinteger 1 rb -∗
      (S.array res «unsigned int» f_LVspecified_OVinteger 1 [c, o, a, s] -∗ Q value.Vunit) -∗
      S.call «Tls_Conn».Fn.Tls_Conn_set_res [res, c, o, a, s] Q

/-- `static bool seq_ok(uint8_t *seq)`; a `bool` result is 1 or 0.

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def seq_ok_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (seq : object_value) (sb : Bytes) (q : ℚ) (Q : value → PROP),
    sb.ilength = 8 →
    ⊢ bytes_at S seq q sb -∗
      (bytes_at S seq q sb -∗
        Q ((if sb[(0 : ℤ)]! = 0 ∧ sb[(1 : ℤ)]! = 0 then 1 else 0 : ℤ) : value)) -∗
      S.call «Tls_Conn».Fn.«Tls_Conn#seq_ok» [seq] Q

/-- `uint32_t Tls_Crypto_last_nz(uint8_t *b, uint32_t n, uint32_t i)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def last_nz_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (b : object_value) (n i : ℤ) (bs : Bytes) (q : ℚ) (Q : value → PROP),
    «unsigned int».hasType n → «unsigned int».hasType i → i ≤ bs.ilength →
    ⊢ bytes_at S b q bs -∗
      (bytes_at S b q bs -∗ Q ((lastNz bs n i.toNat : ℤ) : value)) -∗
      S.call «Tls_Conn».Fn.Tls_Crypto_last_nz [b, n, i] Q

/-- `static uint32_t record_content_type(uint8_t *inner, uint32_t il, uint8_t *ty)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def record_content_type_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (inner ty : object_value) (il : ℤ) (ib tb : Bytes) (q : ℚ) (Q : value → PROP),
    «unsigned int».hasType il → il ≤ ib.ilength → tb.ilength = 1 →
    ⊢ bytes_at S inner q ib -∗ bytes_at S ty 1 tb -∗
      (∀ (r : ℤ) (tb' : Bytes),
        ⌊(r = 4294967294 ∧ tb' = tb ∧ ∀ k, 0 ≤ k → k < il → ib[k]! = 0) ∨
          (0 ≤ r ∧ r < il ∧ ib[r]! ≠ 0 ∧ tb' = [ib[r]!] ∧
            ∀ k, r < k → k < il → ib[k]! = 0)⌋ -∗
        bytes_at S inner q ib -∗ bytes_at S ty 1 tb' -∗ Q r) -∗
      S.call «Tls_Conn».Fn.«Tls_Conn#record_content_type» [inner, il, ty] Q

/-- `bool Tls_Util_ct_eq(uint8_t *a, uint8_t *b, uint32_t n, uint32_t i, uint8_t acc)`:
1 exactly when `acc == 0` and `a[i, n) == b[i, n)`.

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def ct_eq_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (a b : object_value) (n i acc : ℤ) (ab bb : Bytes) (qa qb : ℚ) (Q : value → PROP),
    «unsigned int».hasType n → «unsigned int».hasType i → «unsigned char».hasType acc →
    i ≤ n → n ≤ ab.ilength → n ≤ bb.ilength →
    ⊢ bytes_at S a qa ab -∗ bytes_at S b qb bb -∗
      (bytes_at S a qa ab -∗ bytes_at S b qb bb -∗
        Q ((if acc = 0 ∧ ∀ k, i ≤ k → k < n → ab[k]! = bb[k]! then 1 else 0 : ℤ) : value)) -∗
      S.call «Tls_Conn».Fn.Tls_Util_ct_eq [a, b, n, i, acc] Q

/-- `void Tls_Crypto_make_nonce(uint8_t *nonce, uint8_t *iv, uint8_t *seq, uint32_t i)`:
fills `nonce[i, 12)` with the record nonce bytes.

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def make_nonce_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (nonce iv seq : object_value) (i : ℤ) (nb ivb sb : Bytes) (qv qs : ℚ) (Q : value → PROP),
    «unsigned int».hasType i → i ≤ 12 →
    nb.ilength = 12 → ivb.ilength = 12 → sb.ilength = 8 →
    ⊢ bytes_at S nonce 1 nb -∗ bytes_at S iv qv ivb -∗
      bytes_at S seq qs sb -∗
      (bytes_at S nonce 1 (nb.itake i ++ (recordNonce ivb sb).idrop i) -∗
        bytes_at S iv qv ivb -∗ bytes_at S seq qs sb -∗
        Q value.Vunit) -∗
      S.call «Tls_Conn».Fn.Tls_Crypto_make_nonce [nonce, iv, seq, i] Q

/-- `void Tls_Crypto_inc_seq(uint8_t *seq, uint32_t i)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. -/
def inc_seq_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (seq : object_value) (i : ℤ) (sb : Bytes) (Q : value → PROP),
    «unsigned int».hasType i → i ≤ 8 → sb.ilength = 8 →
    ⊢ bytes_at S seq 1 sb -∗
      (bytes_at S seq 1 (incPrefix sb i.toNat) -∗ Q value.Vunit) -∗
      S.call «Tls_Conn».Fn.Tls_Crypto_inc_seq [seq, i] Q

/-- `static void expand_label(uint8_t *out, uint32_t len, uint8_t *secret, uint8_t *label,
uint32_t ll, uint8_t *ctx, uint32_t cl)`: writes `HKDF-Expand-Label` into `out[0, len)`.

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. Assumes the HACL*/EverCrypt contracts
`CryptoContracts`. -/
def expand_label_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    ∀ (out secret label ctx : object_value) (len ll cl : ℤ) (ob sec lab cx : Bytes)
      (qs ql qc : ℚ) (Q : value → PROP),
      «unsigned int».hasType len → «unsigned int».hasType ll → «unsigned int».hasType cl →
      0 < len → len ≤ 8160 → len ≤ ob.ilength → sec.ilength = 32 →
      ll ≤ lab.ilength → cl ≤ cx.ilength → 0 < cx.ilength → 10 + ll + cl ≤ 128 →
      ⊢ bytes_at S out 1 ob -∗ bytes_at S secret qs sec -∗
        bytes_at S label ql lab -∗ bytes_at S ctx qc cx -∗
        (bytes_at S out 1
            (expandLabel sec (lab.itake ll) (cx.itake cl) len.toNat ++ ob.idrop len) -∗
          bytes_at S secret qs sec -∗ bytes_at S label ql lab -∗
          bytes_at S ctx qc cx -∗ True -∗ Q value.Vunit) -∗
        S.call «Tls_Conn».Fn.«Tls_Conn#expand_label» [out, len, secret, label, ll, ctx, cl] Q

/-- `static void traffic_keys(uint8_t *key, uint8_t *iv, uint8_t *secret, uint8_t suite)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. Assumes the HACL*/EverCrypt contracts
`CryptoContracts`. -/
def traffic_keys_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    ∀ (key iv secret : object_value) (suite : ℤ) (kb ivb sec : Bytes) (qs : ℚ)
      (Q : value → PROP),
      «unsigned char».hasType suite → kb.ilength = 32 → ivb.ilength = 12 → sec.ilength = 32 →
      ⊢ bytes_at S key 1 kb -∗ bytes_at S iv 1 ivb -∗
        bytes_at S secret qs sec -∗
        (bytes_at S key 1
            (if suite = 1 then expandLabel sec labelKey [] 16 ++ kb.drop 16
             else expandLabel sec labelKey [] 32) -∗
          bytes_at S iv 1 (expandLabel sec labelIv [] 12) -∗
          bytes_at S secret qs sec -∗ True -∗ Q value.Vunit) -∗
        S.call «Tls_Conn».Fn.«Tls_Conn#traffic_keys» [key, iv, secret, suite] Q

/-- `static void install_keys(uint8_t *st, uint32_t ko, uint32_t vo, uint32_t so,
uint8_t *secret)`, at the only offsets used on the phase-1 path (the client read keys).

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. Assumes the HACL*/EverCrypt contracts
`CryptoContracts`. -/
def install_keys_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    ∀ (st secret : object_value) (sb sec : Bytes) (qs : ℚ) (Q : value → PROP),
      sb.ilength = 512 → sec.ilength = 32 →
      ⊢ bytes_at S st 1 sb -∗ bytes_at S secret qs sec -∗
        (bytes_at S st 1
            (sb.take 136 ++ clientAppKeyBlock (sb.getD 245 0) sec ++ sb.drop 188) -∗
          bytes_at S secret qs sec -∗ True -∗ Q value.Vunit) -∗
        S.call «Tls_Conn».Fn.«Tls_Conn#install_keys»
          [st, (136 : ℤ), (168 : ℤ), (180 : ℤ), secret] Q

/-- `static void install_client_app(uint8_t *st)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. Assumes the HACL*/EverCrypt contracts
`CryptoContracts`. -/
def install_client_app_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    ∀ (st : object_value) (sb : Bytes) (Q : value → PROP),
      sb.ilength = 512 →
      ⊢ bytes_at S st 1 sb -∗
        (bytes_at S st 1
            (sb.take 136 ++ clientAppKeyBlock (sb.getD 245 0) (slice sb 248 32) ++ sb.drop 188) -∗
          True -∗ Q value.Vunit) -∗
        S.call «Tls_Conn».Fn.«Tls_Conn#install_client_app» [st] Q

/-- `static void finished_mac(uint8_t *out, uint8_t *secret, uint8_t *th)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. Assumes the HACL*/EverCrypt contracts
`CryptoContracts`. -/
def finished_mac_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    ∀ (out secret th : object_value) (ob sec thb : Bytes) (qs qt : ℚ) (Q : value → PROP),
      ob.ilength = 32 → sec.ilength = 32 → thb.ilength = 32 →
      ⊢ bytes_at S out 1 ob -∗ bytes_at S secret qs sec -∗
        bytes_at S th qt thb -∗
        (bytes_at S out 1 (finishedVerify sec thb) -∗
          bytes_at S secret qs sec -∗ bytes_at S th qt thb -∗
          True -∗ Q value.Vunit) -∗
        S.call «Tls_Conn».Fn.«Tls_Conn#finished_mac» [out, secret, th] Q

/-- `static uint32_t unseal(uint8_t *key, uint8_t *iv, uint8_t *seq, uint8_t *hdr, uint8_t *body,
uint32_t n, uint8_t *inner, uint8_t suite)`: `body` holds exactly the `n` body bytes.

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. Assumes the HACL*/EverCrypt contracts
`CryptoContracts`. -/
def unseal_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    ∀ (key iv seq hdr body inner : object_value) (n suite : ℤ) (kb ivb sb hb bb ib : Bytes)
      (qk qv qh qb : ℚ) (Q : value → PROP),
      «unsigned int».hasType n → «unsigned char».hasType suite → 17 ≤ n → n ≤ 16640 →
      kb.ilength = 32 → ivb.ilength = 12 → sb.ilength = 8 → hb.ilength = 5 → bb.ilength = n →
      n - 16 ≤ ib.ilength →
      ⊢ bytes_at S key qk kb -∗ bytes_at S iv qv ivb -∗
        bytes_at S seq 1 sb -∗ bytes_at S hdr qh hb -∗
        bytes_at S body qb bb -∗ bytes_at S inner 1 ib -∗
        (∀ (r : ℤ) (sb' ib' : Bytes),
          ⌊ib'.length = ib.length ∧ ib'.drop (n - 16).toNat = ib.drop (n - 16).toNat ∧
            ((r = 0 ∧ sb' = incPrefix sb 8 ∧
              m.openWith suite kb (recordNonce ivb sb) hb (bb.take (n - 16).toNat)
                (bb.drop (n - 16).toNat) = some (ib'.take (n - 16).toNat)) ∨
             (r = 1 ∧ sb' = sb))⌋ -∗
          bytes_at S key qk kb -∗ bytes_at S iv qv ivb -∗
          bytes_at S seq 1 sb' -∗ bytes_at S hdr qh hb -∗
          bytes_at S body qb bb -∗ bytes_at S inner 1 ib' -∗ Q r) -∗
        S.call «Tls_Conn».Fn.«Tls_Conn#unseal» [key, iv, seq, hdr, body, n, inner, suite] Q

/-- `uint32_t Tls_Conn_open_rec(uint8_t *st, uint8_t *inp, uint32_t rlen, uint8_t *inner,
uint8_t *ty)` with `inner` the 16640-byte scratch buffer.

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. Assumes the HACL*/EverCrypt contracts
`CryptoContracts`. -/
def open_rec_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    ∀ (st inp inner ty : object_value) (rlen : ℤ) (sb inb ib tb : Bytes) (qi : ℚ)
      (Q : value → PROP),
      «unsigned int».hasType rlen → 17 ≤ rlen → rlen ≤ 16640 → 5 + rlen ≤ inb.ilength →
      sb.ilength = 512 → ib.ilength = 16640 → tb.ilength = 1 →
      ⊢ bytes_at S st 1 sb -∗ bytes_at S inp qi inb -∗
        bytes_at S inner 1 ib -∗ bytes_at S ty 1 tb -∗
        (∀ (r : ℤ) (sb' ib' tb' : Bytes), ⌊OpenRecPost m sb inb rlen r sb' ib' tb'⌋ -∗
          bytes_at S st 1 sb' -∗ bytes_at S inp qi inb -∗
          bytes_at S inner 1 ib' -∗ bytes_at S ty 1 tb' -∗ Q r) -∗
        S.call «Tls_Conn».Fn.Tls_Conn_open_rec [st, inp, rlen, inner, ty] Q

/-- `static uint32_t seal(uint8_t *key, uint8_t *iv, uint8_t *seq, uint8_t ctype,
uint8_t *plain, uint32_t plen, uint8_t *out, uint8_t suite)` (memory effects only).

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. Assumes the HACL*/EverCrypt contracts
`CryptoContracts`. -/
def seal_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    ∀ (key iv seq plain out : object_value) (ctype plen suite : ℤ) (kb ivb sb pb ob : Bytes)
      (qk qv qp : ℚ) (Q : value → PROP),
      «unsigned char».hasType ctype → «unsigned int».hasType plen →
      «unsigned char».hasType suite → 0 < plen → plen ≤ 16384 →
      kb.ilength = 32 → ivb.ilength = 12 → sb.ilength = 8 → pb.ilength = plen →
      plen + 22 ≤ ob.ilength → ob.ilength < 2 ^ 32 →
      ⊢ bytes_at S key qk kb -∗ bytes_at S iv qv ivb -∗
        bytes_at S seq 1 sb -∗ bytes_at S plain qp pb -∗
        bytes_at S out 1 ob -∗
        (∀ (r : ℤ) (sb' ob' : Bytes),
          ⌊sb'.length = 8 ∧ ob'.length = ob.length ∧ (r = 0 ∨ r = plen + 22)⌋ -∗
          bytes_at S key qk kb -∗ bytes_at S iv qv ivb -∗
          bytes_at S seq 1 sb' -∗ bytes_at S plain qp pb -∗
          bytes_at S out 1 ob' -∗ Q r) -∗
        S.call «Tls_Conn».Fn.«Tls_Conn#seal» [key, iv, seq, ctype, plain, plen, out, suite] Q

/-- `static uint32_t send_rec(uint8_t *st, uint8_t ctype, uint8_t *plain, uint32_t plen,
uint8_t *out)`: only the write sequence number `st[232, 240)` may change.

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. Assumes the HACL*/EverCrypt contracts
`CryptoContracts`. -/
def send_rec_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    ∀ (st plain out : object_value) (ctype plen : ℤ) (sb pb ob : Bytes) (qp : ℚ)
      (Q : value → PROP),
      «unsigned char».hasType ctype → «unsigned int».hasType plen → 0 < plen → plen ≤ 16384 →
      sb.ilength = 512 → pb.ilength = plen → plen + 22 ≤ ob.ilength → ob.ilength < 2 ^ 32 →
      ⊢ bytes_at S st 1 sb -∗ bytes_at S plain qp pb -∗
        bytes_at S out 1 ob -∗
        (∀ (r : ℤ) (sb' ob' : Bytes),
          ⌊(∃ w : Bytes, w.length = 8 ∧ sb' = withWriteSeq sb w) ∧ ob'.length = ob.length ∧
            (r = 0 ∨ r = plen + 22)⌋ -∗
          bytes_at S st 1 sb' -∗ bytes_at S plain qp pb -∗
          bytes_at S out 1 ob' -∗ Q r) -∗
        S.call «Tls_Conn».Fn.«Tls_Conn#send_rec» [st, ctype, plain, plen, out] Q

/-- `static uint32_t send_alert(uint8_t *st, uint8_t level, uint8_t desc, uint8_t *out)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. Assumes the HACL*/EverCrypt contracts
`CryptoContracts`. -/
def send_alert_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    ∀ (st out : object_value) (level desc : ℤ) (sb ob : Bytes) (Q : value → PROP),
      «unsigned char».hasType level → «unsigned char».hasType desc → sb.ilength = 512 →
      24 ≤ ob.ilength → ob.ilength < 2 ^ 32 →
      ⊢ bytes_at S st 1 sb -∗ bytes_at S out 1 ob -∗
        (∀ (r : ℤ) (sb' ob' : Bytes),
          ⌊(∃ w : Bytes, w.length = 8 ∧ sb' = withWriteSeq sb w) ∧ ob'.length = ob.length ∧
            0 ≤ r ∧ r ≤ 24⌋ -∗
          bytes_at S st 1 sb' -∗ bytes_at S out 1 ob' -∗ Q r) -∗
        S.call «Tls_Conn».Fn.«Tls_Conn#send_alert» [st, level, desc, out] Q

/-- `void Tls_Conn_fatal(uint8_t *st, uint8_t desc, uint8_t *out, uint32_t *res,
uint32_t consumed)`

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. Assumes the HACL*/EverCrypt contracts
`CryptoContracts`. -/
def fatal_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    ∀ (st out res : object_value) (desc consumed : ℤ) (sb ob rb : Bytes) (Q : value → PROP),
      «unsigned char».hasType desc → «unsigned int».hasType consumed → sb.ilength = 512 →
      ob.ilength = 20480 → rb.ilength = 4 →
      ⊢ bytes_at S st 1 sb -∗ bytes_at S out 1 ob -∗
        S.array res «unsigned int» f_LVspecified_OVinteger 1 rb -∗
        (∀ (n : ℤ) (sb' ob' : Bytes),
          ⌊(∃ w : Bytes, w.length = 8 ∧ sb' = withWriteSeq sb w) ∧ ob'.length = 20480 ∧
            0 ≤ n ∧ n ≤ 24⌋ -∗
          bytes_at S st 1 sb' -∗ bytes_at S out 1 ob' -∗
          S.array res «unsigned int» f_LVspecified_OVinteger 1 [consumed, n, 0, 1] -∗
          Q value.Vunit) -∗
        S.call «Tls_Conn».Fn.Tls_Conn_fatal [st, desc, out, res, consumed] Q

/-- `void Tls_Conn_check_cfin(uint8_t *st, uint8_t *inner, uint8_t *out, uint32_t *res,
uint32_t consumed)`; `inner[4, 36)` holds the received verify data.

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. Assumes the HACL*/EverCrypt contracts
`CryptoContracts`. -/
def check_cfin_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    ∀ (st inner out res : object_value) (consumed : ℤ) (sb ib ob rb : Bytes) (qi : ℚ)
      (Q : value → PROP),
      «unsigned int».hasType consumed → sb.ilength = 512 → 36 ≤ ib.ilength →
      ob.ilength = 20480 → rb.ilength = 4 →
      ⊢ bytes_at S st 1 sb -∗ bytes_at S inner qi ib -∗
        bytes_at S out 1 ob -∗
        S.array res «unsigned int» f_LVspecified_OVinteger 1 rb -∗
        (∀ (sb' ob' rb' : Bytes), ⌊ob'.length = 20480 ∧ CfinPost sb ib consumed sb' rb'⌋ -∗
          bytes_at S st 1 sb' -∗ bytes_at S inner qi ib -∗
          bytes_at S out 1 ob' -∗
          S.array res «unsigned int» f_LVspecified_OVinteger 1 rb' -∗ True -∗ Q value.Vunit) -∗
        S.call «Tls_Conn».Fn.Tls_Conn_check_cfin [st, inner, out, res, consumed] Q

/-- `void Tls_Conn_phase1(uint8_t *st, uint8_t *inp, uint8_t rtype, uint32_t rlen,
uint8_t *out, uint32_t *res)` for a complete record (`5 + rlen` input bytes present).

Memory safety: under these preconditions the call has no undefined behaviour, and if it
returns the stated postcondition holds. Assumes the HACL*/EverCrypt contracts
`CryptoContracts`. -/
def phase1_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    ∀ (st inp out res : object_value) (rtype rlen : ℤ) (sb inb ob rb : Bytes) (qi : ℚ)
      (Q : value → PROP),
      «unsigned char».hasType rtype → «unsigned int».hasType rlen → rlen ≤ 16640 →
      5 + rlen ≤ inb.ilength → sb.ilength = 512 → sb.getD 0 0 = 1 →
      ob.ilength = 20480 → rb.ilength = 4 →
      ⊢ bytes_at S st 1 sb -∗ bytes_at S inp qi inb -∗
        bytes_at S out 1 ob -∗
        S.array res «unsigned int» f_LVspecified_OVinteger 1 rb -∗
        (∀ (sb' ob' rb' : Bytes),
          ⌊sb'.length = 512 ∧ ob'.length = 20480 ∧ rb'.length = 4 ∧
            Phase1RecordPost m sb inb rtype rlen sb' rb'⌋ -∗
          bytes_at S st 1 sb' -∗ bytes_at S inp qi inb -∗
          bytes_at S out 1 ob' -∗
          S.array res «unsigned int» f_LVspecified_OVinteger 1 rb' -∗ True -∗ Q value.Vunit) -∗
        S.call «Tls_Conn».Fn.Tls_Conn_phase1 [st, inp, rtype, rlen, out, res] Q

end TlsConnSpec
