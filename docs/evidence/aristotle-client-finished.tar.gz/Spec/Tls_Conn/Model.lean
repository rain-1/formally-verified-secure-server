module

public import Spec.Tls_Conn.Crypto

@[expose] public section

/-!
# TLS 1.3 record and key-schedule model for the client Finished transition

Pure definitions, independent of the C code, describing what `Tls_Conn_input` should do while
the connection waits for the client Finished message (`st[0] == 1`).

Connection-state layout (a 512-byte buffer `st`, offsets as in `reference/Tls.State.fst`):

| bytes        | contents                                              |
|--------------|-------------------------------------------------------|
| `[0]`        | connection phase (0 hello, 1 waiting for Finished, 2 connected) |
| `[8, 40)`    | client handshake traffic secret                       |
| `[104, 136)` | transcript hash through the server Finished           |
| `[136, 168)` | client read key (AES-128-GCM uses the first 16 bytes) |
| `[168, 180)` | client read IV                                        |
| `[180, 188)` | client read sequence number (big-endian)              |
| `[232, 240)` | server write sequence number                          |
| `[245]`      | cipher-suite byte (1 = AES-128-GCM, otherwise ChaCha20-Poly1305) |
| `[248, 280)` | client application traffic secret                     |
-/

namespace TlsConnSpec

/-- `len` bytes of `b` starting at offset `off`. -/
def slice (b : Bytes) (off len : ℕ) : Bytes := (b.drop off).take len

/-- A run of `n` zero bytes. -/
def zeros (n : ℕ) : Bytes := List.replicate n 0

/-- Big-endian two-byte encoding of `v` (taken modulo `2^16`). -/
def u16be (v : ℕ) : Bytes := [((v / 256 % 256 : ℕ) : ℤ), ((v % 256 : ℕ) : ℤ)]

/-- The big-endian 16-bit number stored at offset `i`. -/
def rd16 (b : Bytes) (i : ℕ) : ℕ := (b.getD i 0).toNat * 256 + (b.getD (i + 1) 0).toNat

/-! ## HKDF-Expand-Label (RFC 8446, section 7.1) -/

/-- `"tls13 "` -/
def tls13Prefix : Bytes := ascii "tls13 "
/-- `"key"` -/
def labelKey : Bytes := ascii "key"
/-- `"iv"` -/
def labelIv : Bytes := ascii "iv"
/-- `"finished"` -/
def labelFinished : Bytes := ascii "finished"

/-- The serialized `HkdfLabel` structure:
`uint16 length; opaque label<7..255> = "tls13 " + Label; opaque context<0..255>`. -/
def hkdfLabel (len : ℕ) (label ctx : Bytes) : Bytes :=
  u16be len ++ [(((6 + label.length) % 256 : ℕ) : ℤ)] ++ tls13Prefix ++ label ++
    [((ctx.length % 256 : ℕ) : ℤ)] ++ ctx

/-- `HKDF-Expand-Label(secret, label, context, len)` with SHA-256. -/
def expandLabel (secret label ctx : Bytes) (len : ℕ) : Bytes :=
  hkdfExpandSha256 secret (hkdfLabel len label ctx) len

/-- `finished_key = HKDF-Expand-Label(secret, "finished", "", 32)`. -/
def finishedKey (secret : Bytes) : Bytes := expandLabel secret labelFinished [] 32

/-- `FinishedVerify(secret, th) = HMAC-SHA-256(finished_key(secret), th)` (RFC 8446, 4.4.4). -/
def finishedVerify (secret th : Bytes) : Bytes := hmacSha256 (finishedKey secret) th

/-- The 36-byte Finished handshake message carrying `verifyData`: type 20 and length 32. -/
def finishedMessage (verifyData : Bytes) : Bytes := [20, 0, 0, 32] ++ verifyData

/-! ## Record protection (RFC 8446, sections 5.2 and 5.3) -/

/-- Per-record nonce: the IV XOR the sequence number left-padded with four zero bytes. -/
def recordNonce (iv seq : Bytes) : Bytes :=
  (List.range 12).map fun i =>
    (((iv.getD i 0).toNat ^^^ (if i < 4 then 0 else (seq.getD (i - 4) 0).toNat) : ℕ) : ℤ)

/-- Authenticated opening, as a mathematical model. `open key nonce aad ciphertext tag` is
`some plaintext` when the tag authenticates, and `none` when it is rejected. -/
abbrev AeadOpen := Bytes → Bytes → Bytes → Bytes → Bytes → Option Bytes

/-- The two record ciphers. Their opening functions are parameters of the specification: the
external contracts of `EverCrypt_AEAD_decrypt_expand_aes128_gcm` and
`Hacl_AEAD_Chacha20Poly1305_decrypt` say that a successful return produces the model's
plaintext. -/
structure AeadModel where
  /-- AES-128-GCM opening (16-byte key). -/
  aes128gcmOpen : AeadOpen
  /-- ChaCha20-Poly1305 opening (32-byte key). -/
  chacha20poly1305Open : AeadOpen

/-- Opening with the cipher selected by the suite byte: AES-128-GCM with the first 16 key bytes
when the suite byte is 1, ChaCha20-Poly1305 with all 32 key bytes otherwise. -/
def AeadModel.openWith (m : AeadModel) (suite : ℤ) (key nonce aad ct tag : Bytes) :
    Option Bytes :=
  if suite = 1 then m.aes128gcmOpen (key.take 16) nonce aad ct tag
  else m.chacha20poly1305Open key nonce aad ct tag

/-! ## The incoming record -/

/-- The body length declared by the five-byte record header at the start of `inp`. -/
def recordLen (inp : Bytes) : ℕ := rd16 inp 3

/-- Opening the first record of `inp`, which has `rlen` body bytes, with the client read key,
IV and sequence number held in the connection state `st`. The additional data is the five-byte
record header; the last 16 body bytes are the tag. -/
def openFirstRecord (m : AeadModel) (st inp : Bytes) (rlen : ℕ) : Option Bytes :=
  m.openWith (st.getD 245 0) (slice st 136 32) (recordNonce (slice st 168 12) (slice st 180 8))
    (inp.take 5) (slice inp 5 (rlen - 16)) (slice inp (5 + rlen - 16) 16)

/-- The record framing that `Tls_Conn_input` treats as one complete encrypted record: a header
of type 23 (application data) declaring `17 ≤ rlen ≤ 16640` body bytes, all of which are
present. -/
def CompleteEncryptedRecord (inp : Bytes) : Prop :=
  5 ≤ inp.length ∧ inp.getD 0 0 = 23 ∧ 17 ≤ recordLen inp ∧ recordLen inp ≤ 16640 ∧
    5 + recordLen inp ≤ inp.length

/-- **Property 1 (what a transition to phase 2 requires).** The first record of `inp` is a
complete encrypted record that opens under the pre-call client handshake key, IV and read
sequence number. After removing the zero padding, its inner content type is handshake (22) and
its content is exactly the 36-byte Finished message whose verify data is
`FinishedVerify(client_handshake_traffic_secret, hash_through_server_Finished)`, both taken
from the pre-call state. -/
def ClientFinishedAccepted (m : AeadModel) (st inp : Bytes) : Prop :=
  CompleteEncryptedRecord inp ∧
    openFirstRecord m st inp (recordLen inp) =
      some (finishedMessage (finishedVerify (slice st 8 32) (slice st 104 32)) ++ [22] ++
        zeros (recordLen inp - 16 - 37))

/-- A complete encrypted record whose authentication tag the model rejects. -/
def RejectedRecord (m : AeadModel) (st inp : Bytes) : Prop :=
  CompleteEncryptedRecord inp ∧ openFirstRecord m st inp (recordLen inp) = none

/-! ## Installing the client application keys -/

/-- Client application key and IV derived from the client application traffic secret
`secret` (RFC 8446, section 7.3): `HKDF-Expand-Label(secret, "key", "", key_length)` and
`HKDF-Expand-Label(secret, "iv", "", 12)`. The key slot is 32 bytes; for AES-128-GCM
(suite byte 1) only its first 16 bytes hold key material and the rest are zero. -/
def clientAppKeyBlock (suite : ℤ) (secret : Bytes) : Bytes :=
  (if suite = 1 then expandLabel secret labelKey [] 16 ++ zeros 16
   else expandLabel secret labelKey [] 32) ++
  expandLabel secret labelIv [] 12 ++ zeros 8

/-- **Property 2 (state after the transition).** The connection state with phase 2 and the
client read key, IV and sequence number (`st[136, 188)`) replaced by the keys derived from the
pre-call client application traffic secret `st[248, 280)`, with a zero sequence number. All
other bytes are unchanged. -/
def connectedState (st : Bytes) : Bytes :=
  ((st.take 136 ++ clientAppKeyBlock (st.getD 245 0) (slice st 248 32) ++ st.drop 188).set 0 2)

/-! ## Outcomes of a phase-1 call

Each predicate relates the pre-call state `st` and input bytes `inp` to the post-call state `st'`
and result slots `res'` (`res'[0]` bytes consumed, `res'[1]` output bytes, `res'[2]` application
bytes, `res'[3]` disposition: 0 ok, 1 fatal, 2 peer closed). -/

/-- **Property 1.** Leaving phase 1 requires a complete encrypted record that opens under the
pre-call client handshake keys and carries exactly the expected client Finished message. -/
def TransitionRequiresFinished (m : AeadModel) (st inp st' : Bytes) : Prop :=
  st'.getD 0 0 ≠ 1 → ClientFinishedAccepted m st inp

/-- **Property 2.** Leaving phase 1 enters phase 2 with the client application key, IV and a
zero read sequence installed from the pre-call client application traffic secret (all other
state bytes unchanged), and reports success with no output or application bytes and exactly the
first record (header included) consumed. -/
def TransitionInstallsAppKeys (st inp st' res' : Bytes) : Prop :=
  st'.getD 0 0 ≠ 1 →
    st' = connectedState st ∧ res' = [((5 + recordLen inp : ℕ) : ℤ), 0, 0, 0]

/-- **Property 3.** A phase-1 call never returns application bytes; an incomplete header or body
consumes nothing and leaves the state unchanged; when the phase stays 1 only the read sequence
number `st[180, 188)` (after a successful opening) and the write sequence number `st[232, 240)`
(after a fatal alert) may change; and a complete record with a rejected tag keeps phase 1 and
the read sequence number. -/
def Phase1FailureBehaviour (m : AeadModel) (st inp st' res' : Bytes) : Prop :=
  res'.getD 2 0 = 0 ∧
  (inp.length < 5 → res'.getD 0 0 = 0 ∧ st' = st) ∧
  (5 ≤ inp.length → recordLen inp ≤ 16640 → inp.length < 5 + recordLen inp →
    res'.getD 0 0 = 0 ∧ st' = st) ∧
  (st'.getD 0 0 = 1 → st'.length = st.length ∧
    ∀ i, i < st.length → ¬ (180 ≤ i ∧ i < 188) → ¬ (232 ≤ i ∧ i < 240) →
      st'.getD i 0 = st.getD i 0) ∧
  (RejectedRecord m st inp → st'.getD 0 0 = 1 ∧ slice st' 180 8 = slice st 180 8)

/-- All three properties together. -/
def Phase1Outcome (m : AeadModel) (st inp st' res' : Bytes) : Prop :=
  TransitionRequiresFinished m st inp st' ∧ TransitionInstallsAppKeys st inp st' res' ∧
    Phase1FailureBehaviour m st inp st' res'

end TlsConnSpec
