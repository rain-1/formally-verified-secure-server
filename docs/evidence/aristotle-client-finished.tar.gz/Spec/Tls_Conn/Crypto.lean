module

public import Mathlib.Data.Rat.Defs
public import Mathlib.Data.List.Basic

@[expose] public section

/-!
# Hash-based primitives used by the TLS 1.3 key schedule

Byte strings are lists of integers, each in `0 ‥ 255`, matching the way C byte buffers are
described in the specifications. This file gives executable reference definitions of

* SHA-256 (FIPS 180-4),
* HMAC-SHA-256 (RFC 2104 / FIPS 198-1),
* HKDF-Expand with HMAC-SHA-256 (RFC 5869, section 2.3).

They are the meaning given to the HACL* functions `Hacl_HMAC_compute_sha2_256` and
`Hacl_HKDF_expand_sha2_256` in the external contracts (`Spec/Tls_Conn/Contracts.lean`).
These definitions were checked against standard test vectors (FIPS 180-4, RFC 4231, RFC 5869).
-/

namespace TlsConnSpec

/-- A byte string. Each element is meant to lie in `0 ‥ 255`. -/
abbrev Bytes := List ℤ

namespace Sha256

/-- Round constants of SHA-256. -/
def K : List UInt32 := [
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2]

/-- Initial hash value of SHA-256. -/
def H0 : List UInt32 :=
  [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]

/-- Rotate a 32-bit word right by `n` bits (`0 < n < 32`). -/
def rotr (x : UInt32) (n : UInt32) : UInt32 := (x >>> n) ||| (x <<< (32 - n))

/-- The byte at position `i` as a natural number below 256. -/
def byteAt (b : Bytes) (i : ℕ) : ℕ := (b.getD i 0).toNat % 256

/-- Big-endian 32-bit word starting at byte `i`. -/
def wordAt (b : Bytes) (i : ℕ) : UInt32 :=
  UInt32.ofNat (byteAt b i * 2 ^ 24 + byteAt b (i + 1) * 2 ^ 16 + byteAt b (i + 2) * 2 ^ 8 +
    byteAt b (i + 3))

/-- Message padding: append `0x80`, zeros, and the 64-bit big-endian bit length, so that the
total length is a multiple of 64 bytes. -/
def pad (msg : Bytes) : Bytes :=
  let n := msg.length
  let zeros := (119 - n % 64) % 64
  let bits := 8 * n
  msg ++ [0x80] ++ List.replicate zeros 0 ++
    (List.range 8).reverse.map (fun k => (((bits / 2 ^ (8 * k)) % 256 : ℕ) : ℤ))

/-- The 64-word message schedule of one 64-byte block starting at byte `off`. -/
def schedule (b : Bytes) (off : ℕ) : List UInt32 :=
  let w0 := (List.range 16).map (fun t => wordAt b (off + 4 * t))
  (List.range 48).foldl (fun (w : List UInt32) t =>
    let i := t + 16
    let x15 := w.getD (i - 15) 0
    let x2 := w.getD (i - 2) 0
    let s0 := rotr x15 7 ^^^ rotr x15 18 ^^^ (x15 >>> 3)
    let s1 := rotr x2 17 ^^^ rotr x2 19 ^^^ (x2 >>> 10)
    w ++ [w.getD (i - 16) 0 + s0 + w.getD (i - 7) 0 + s1]) w0

/-- The SHA-256 compression function applied to state `h` and the block at byte `off`. -/
def compress (h : List UInt32) (b : Bytes) (off : ℕ) : List UInt32 :=
  let w := schedule b off
  let init := h
  let final := (List.range 64).foldl (fun (s : List UInt32) t =>
    let a := s.getD 0 0
    let bb := s.getD 1 0
    let c := s.getD 2 0
    let d := s.getD 3 0
    let e := s.getD 4 0
    let f := s.getD 5 0
    let g := s.getD 6 0
    let hh := s.getD 7 0
    let S1 := rotr e 6 ^^^ rotr e 11 ^^^ rotr e 25
    let ch := (e &&& f) ^^^ ((~~~ e) &&& g)
    let t1 := hh + S1 + ch + K.getD t 0 + w.getD t 0
    let S0 := rotr a 2 ^^^ rotr a 13 ^^^ rotr a 22
    let maj := (a &&& bb) ^^^ (a &&& c) ^^^ (bb &&& c)
    let t2 := S0 + maj
    [t1 + t2, a, bb, c, d + t1, e, f, g]) init
  (List.range 8).map (fun i => h.getD i 0 + final.getD i 0)

/-- Big-endian bytes of a 32-bit word. -/
def wordBytes (x : UInt32) : Bytes :=
  [(((x.toNat / 2 ^ 24) % 256 : ℕ) : ℤ), (((x.toNat / 2 ^ 16) % 256 : ℕ) : ℤ),
    (((x.toNat / 2 ^ 8) % 256 : ℕ) : ℤ), ((x.toNat % 256 : ℕ) : ℤ)]

end Sha256

/-- SHA-256 of a byte string (32 bytes). -/
def sha256 (msg : Bytes) : Bytes :=
  let p := Sha256.pad msg
  let h := (List.range (p.length / 64)).foldl (fun h i => Sha256.compress h p (64 * i)) Sha256.H0
  h.flatMap Sha256.wordBytes

/-- HMAC-SHA-256 (block size 64 bytes): `H((K' ⊕ opad) ‖ H((K' ⊕ ipad) ‖ msg))`, where `K'` is
the key (hashed first if longer than 64 bytes) padded with zeros to 64 bytes. -/
def hmacSha256 (key msg : Bytes) : Bytes :=
  let k := if 64 < key.length then sha256 key else key
  let k0 := (List.range 64).map (fun i => (Sha256.byteAt k i : ℤ))
  let ipad := k0.map (fun x => ((x.toNat ^^^ 0x36 : ℕ) : ℤ))
  let opad := k0.map (fun x => ((x.toNat ^^^ 0x5c : ℕ) : ℤ))
  sha256 (opad ++ sha256 (ipad ++ msg))

/-- HKDF-Expand with HMAC-SHA-256 (RFC 5869): the first `len` bytes of `T(1) ‖ T(2) ‖ …` with
`T(0) = ""` and `T(i) = HMAC(prk, T(i-1) ‖ info ‖ [i])`. -/
def hkdfExpandSha256 (prk info : Bytes) (len : ℕ) : Bytes :=
  let n := (len + 31) / 32
  let blocks := (List.range n).foldl (fun (acc : Bytes × Bytes) i =>
    let t := hmacSha256 prk (acc.2 ++ info ++ [((i + 1 : ℕ) : ℤ)])
    (acc.1 ++ t, t)) ([], [])
  blocks.1.take len

/-! ## Byte-string helpers -/

/-- Hexadecimal rendering of a byte string. -/
def toHex (b : Bytes) : String :=
  String.join (b.map fun x =>
    let n := x.toNat
    String.ofList [Nat.digitChar (n / 16), Nat.digitChar (n % 16)])

/-- Bytes of an ASCII string. -/
def ascii (s : String) : Bytes := s.toList.map (fun c => (c.toNat : ℤ))

end TlsConnSpec
