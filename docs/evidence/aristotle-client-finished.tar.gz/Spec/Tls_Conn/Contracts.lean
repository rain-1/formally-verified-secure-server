module

public import C2lean.Public.Resources
public import Tls_Conn.Public
public import Spec.Tls_Conn.Model

open scoped C2lean

@[expose] public section

/-!
# External contracts of the HACL*/EverCrypt functions reached in phase 1

`Tls_Conn.c` calls six cryptographic library functions on the phase-1 path. Their bodies are
outside this verification; each contract below is an explicit assumption that appears as a
hypothesis of the public property. The contracts follow the F* bindings in
`reference/Hacl.HKDF.fst`, `reference/Hacl.HMAC.fst`, `reference/EverCrypt.AEAD.fst` and
`reference/Hacl.AEAD_Chacha20Poly1305.fst`, and are no stronger than them:

* every argument buffer is owned for the call (output buffers writable, inputs readable with any
  fraction) and is handed back; nothing else is touched;
* HKDF-Expand and HMAC write the SHA-256-based values defined in `Spec/Tls_Conn/Crypto.lean`;
* a decryption that returns 0 has written the plaintext of the opening model; on any other
  return value the plaintext buffer holds arbitrary bytes (the AES backend may write into it
  even when authentication fails);
* encryption writes some bytes into the ciphertext and tag buffers (their values are not used
  on the phase-1 path).
-/

namespace TlsConnSpec

open Iris Iris.BI C2lean.Public C2lean.Public.Resources Ctype

variable {PROP : Type} [BI PROP]

/-- `Hacl_HKDF_expand_sha2_256(okm, prk, prklen, info, infolen, len)` writes
`HKDF-Expand-SHA-256(prk[0, prklen), info[0, infolen), len)` into `okm[0, len)`. -/
def HkdfExpandContract (S : Vocab PROP) : Prop :=
  ∀ (okm prk info : object_value) (prklen infolen len : ℤ) (okm0 prkB infoB : Bytes)
    (qp qi : ℚ) (Q : value → PROP),
    okm0.ilength = len → prkB.ilength = prklen → infoB.ilength = infolen →
    32 ≤ prklen → prklen ≤ 65536 → 0 < infolen → infolen ≤ 1000 → 0 < len → len ≤ 8160 →
    ⊢ bytes_at S okm 1 okm0 -∗ bytes_at S prk qp prkB -∗ bytes_at S info qi infoB -∗
      (bytes_at S okm 1 (hkdfExpandSha256 prkB infoB len.toNat) -∗
        bytes_at S prk qp prkB -∗ bytes_at S info qi infoB -∗ Q value.Vunit) -∗
      S.call «Tls_Conn».Fn.Hacl_HKDF_expand_sha2_256 [okm, prk, prklen, info, infolen, len] Q

/-- `Hacl_HMAC_compute_sha2_256(dst, key, key_len, data, data_len)` writes
`HMAC-SHA-256(key[0, key_len), data[0, data_len))` into `dst[0, 32)`. -/
def HmacSha256Contract (S : Vocab PROP) : Prop :=
  ∀ (dst key data : object_value) (keylen datalen : ℤ) (dst0 keyB dataB : Bytes)
    (qk qd : ℚ) (Q : value → PROP),
    dst0.ilength = 32 → keyB.ilength = keylen → dataB.ilength = datalen →
    0 < keylen → keylen ≤ 65536 → 0 < datalen → datalen ≤ 65536 →
    ⊢ bytes_at S dst 1 dst0 -∗ bytes_at S key qk keyB -∗ bytes_at S data qd dataB -∗
      (bytes_at S dst 1 (hmacSha256 keyB dataB) -∗
        bytes_at S key qk keyB -∗ bytes_at S data qd dataB -∗ Q value.Vunit) -∗
      S.call «Tls_Conn».Fn.Hacl_HMAC_compute_sha2_256 [dst, key, keylen, data, datalen] Q

/-- `EverCrypt_AEAD_decrypt_expand_aes128_gcm(k, iv, 12, ad, 5, cipher, cipher_len, tag, dst)`
returns an `uint8_t`; a zero return means the model opening of
`(k[0,16), iv[0,12), ad[0,5), cipher[0, cipher_len), tag[0,16))` succeeded with the plaintext
now in `dst[0, cipher_len)`. On any return `dst` holds some bytes. -/
def Aes128GcmDecryptContract (S : Vocab PROP) (m : AeadModel) : Prop :=
  ∀ (k iv ad cipher tag dst : object_value) (cipherlen : ℤ) (kB ivB adB cB tagB dst0 : Bytes)
    (qk qv qa qc qt : ℚ) (Q : value → PROP),
    kB.ilength = 16 → ivB.ilength = 12 → adB.ilength = 5 → cB.ilength = cipherlen →
    tagB.ilength = 16 → dst0.ilength = cipherlen → 0 < cipherlen → cipherlen + 16 ≤ 16640 →
    ⊢ bytes_at S k qk kB -∗ bytes_at S iv qv ivB -∗ bytes_at S ad qa adB -∗
      bytes_at S cipher qc cB -∗ bytes_at S tag qt tagB -∗ bytes_at S dst 1 dst0 -∗
      (∀ (r : ℤ) (dst1 : Bytes),
        ⌊«unsigned char».hasType r ∧ dst1.ilength = cipherlen ∧
          (r = 0 → m.aes128gcmOpen kB ivB adB cB tagB = some dst1)⌋ -∗
        bytes_at S k qk kB -∗ bytes_at S iv qv ivB -∗ bytes_at S ad qa adB -∗
        bytes_at S cipher qc cB -∗ bytes_at S tag qt tagB -∗ bytes_at S dst 1 dst1 -∗ Q r) -∗
      S.call «Tls_Conn».Fn.EverCrypt_AEAD_decrypt_expand_aes128_gcm
        [k, iv, (12 : ℤ), ad, (5 : ℤ), cipher, cipherlen, tag, dst] Q

/-- `Hacl_AEAD_Chacha20Poly1305_decrypt(output, input, input_len, data, 5, key, nonce, tag)`
returns an `uint32_t`; a zero return means the model opening of
`(key[0,32), nonce[0,12), data[0,5), input[0, input_len), tag[0,16))` succeeded with the
plaintext now in `output[0, input_len)`. On any return `output` holds some bytes. -/
def Chacha20Poly1305DecryptContract (S : Vocab PROP) (m : AeadModel) : Prop :=
  ∀ (output input data key nonce tag : object_value) (inputlen : ℤ)
    (out0 inB dataB keyB nonceB tagB : Bytes) (qi qd qk qn qt : ℚ) (Q : value → PROP),
    out0.ilength = inputlen → inB.ilength = inputlen → dataB.ilength = 5 →
    keyB.ilength = 32 → nonceB.ilength = 12 → tagB.ilength = 16 → 0 < inputlen →
    inputlen + 16 ≤ 16640 →
    ⊢ bytes_at S output 1 out0 -∗ bytes_at S input qi inB -∗ bytes_at S data qd dataB -∗
      bytes_at S key qk keyB -∗ bytes_at S nonce qn nonceB -∗ bytes_at S tag qt tagB -∗
      (∀ (r : ℤ) (out1 : Bytes),
        ⌊«unsigned int».hasType r ∧ out1.ilength = inputlen ∧
          (r = 0 → m.chacha20poly1305Open keyB nonceB dataB inB tagB = some out1)⌋ -∗
        bytes_at S output 1 out1 -∗ bytes_at S input qi inB -∗ bytes_at S data qd dataB -∗
        bytes_at S key qk keyB -∗ bytes_at S nonce qn nonceB -∗ bytes_at S tag qt tagB -∗
        Q r) -∗
      S.call «Tls_Conn».Fn.Hacl_AEAD_Chacha20Poly1305_decrypt
        [output, input, inputlen, data, (5 : ℤ), key, nonce, tag] Q

/-- `EverCrypt_AEAD_encrypt_expand_aes128_gcm(k, iv, 12, ad, 5, plain, plain_len, cipher, tag)`
returns an `uint8_t` and leaves some bytes in `cipher[0, plain_len)` and `tag[0, 16)`. -/
def Aes128GcmEncryptContract (S : Vocab PROP) : Prop :=
  ∀ (k iv ad plain cipher tag : object_value) (plainlen : ℤ)
    (kB ivB adB pB c0 t0 : Bytes) (qk qv qa qp : ℚ) (Q : value → PROP),
    kB.ilength = 16 → ivB.ilength = 12 → adB.ilength = 5 → pB.ilength = plainlen →
    c0.ilength = plainlen → t0.ilength = 16 → 0 < plainlen → plainlen ≤ 16640 →
    ⊢ bytes_at S k qk kB -∗ bytes_at S iv qv ivB -∗ bytes_at S ad qa adB -∗
      bytes_at S plain qp pB -∗ bytes_at S cipher 1 c0 -∗ bytes_at S tag 1 t0 -∗
      (∀ (r : ℤ) (c1 t1 : Bytes),
        ⌊«unsigned char».hasType r ∧ c1.ilength = plainlen ∧ t1.ilength = 16⌋ -∗
        bytes_at S k qk kB -∗ bytes_at S iv qv ivB -∗ bytes_at S ad qa adB -∗
        bytes_at S plain qp pB -∗ bytes_at S cipher 1 c1 -∗ bytes_at S tag 1 t1 -∗ Q r) -∗
      S.call «Tls_Conn».Fn.EverCrypt_AEAD_encrypt_expand_aes128_gcm
        [k, iv, (12 : ℤ), ad, (5 : ℤ), plain, plainlen, cipher, tag] Q

/-- `Hacl_AEAD_Chacha20Poly1305_encrypt(output, tag, input, input_len, data, 5, key, nonce)`
leaves some bytes in `output[0, input_len)` and `tag[0, 16)`. -/
def Chacha20Poly1305EncryptContract (S : Vocab PROP) : Prop :=
  ∀ (output tag input data key nonce : object_value) (inputlen : ℤ)
    (o0 t0 inB dataB keyB nonceB : Bytes) (qi qd qk qn : ℚ) (Q : value → PROP),
    o0.ilength = inputlen → t0.ilength = 16 → inB.ilength = inputlen → dataB.ilength = 5 →
    keyB.ilength = 32 → nonceB.ilength = 12 → 0 < inputlen → inputlen ≤ 16640 →
    ⊢ bytes_at S output 1 o0 -∗ bytes_at S tag 1 t0 -∗ bytes_at S input qi inB -∗
      bytes_at S data qd dataB -∗ bytes_at S key qk keyB -∗ bytes_at S nonce qn nonceB -∗
      (∀ (o1 t1 : Bytes), ⌊o1.ilength = inputlen ∧ t1.ilength = 16⌋ -∗
        bytes_at S output 1 o1 -∗ bytes_at S tag 1 t1 -∗ bytes_at S input qi inB -∗
        bytes_at S data qd dataB -∗ bytes_at S key qk keyB -∗ bytes_at S nonce qn nonceB -∗
        Q value.Vunit) -∗
      S.call «Tls_Conn».Fn.Hacl_AEAD_Chacha20Poly1305_encrypt
        [output, tag, input, inputlen, data, (5 : ℤ), key, nonce] Q

/-- All external cryptographic assumptions of the phase-1 path, for the opening model `m`. -/
structure CryptoContracts (S : Vocab PROP) (m : AeadModel) : Prop where
  hkdfExpand : HkdfExpandContract S
  hmac : HmacSha256Contract S
  aesDecrypt : Aes128GcmDecryptContract S m
  chachaDecrypt : Chacha20Poly1305DecryptContract S m
  aesEncrypt : Aes128GcmEncryptContract S
  chachaEncrypt : Chacha20Poly1305EncryptContract S

end TlsConnSpec
