module

public import Spec.Tls_Conn.Contracts

open scoped C2lean

@[expose] public section

/-!
# Public specification: `Tls_Conn_input` while waiting for the client Finished

This is the contract proved about the submitted `generated/Tls_Conn.c`. It describes one call
of the public entry point `Tls_Conn_input` made when the connection phase byte `st[0]` is 1.
-/

namespace TlsConnSpec

open Iris Iris.BI C2lean.Public C2lean.Public.Resources Ctype

/-- One call `Tls_Conn_input(st, tr, chain, clen, pkey, rnd, inp, inlen, out, app, appcap, res)`
made in phase 1 satisfies the outcome predicate `post st inp st' res'`.

Assumptions: the ordinary C library contracts (`LibCSpecs`, used for `memcpy` and `memset`,
supplied by the properties below) and the HACL*/EverCrypt contracts `CryptoContracts S m` for
the AEAD opening model `m`.

If the call returns, the state, output and result buffers are handed back together with the
unchanged input, and `post` holds. Any further resources left over by the call are given back as
`True` (no claim about memory leaks is made). -/
def Phase1InputContract {PROP : Type} [BI PROP] (S : Vocab PROP)
    (post : Bytes → Bytes → Bytes → Bytes → Prop) : Prop :=
  ∀ (st tr chain pkey rnd inp out app res : object_value) (clen inlen appcap : ℤ)
    (stB inB outB resB : Bytes) (qi : ℚ) (Q : value → PROP),
    -- PRECONDITIONS
    -- `clen`, `inlen` and `appcap` are `uint32_t` values.
    «unsigned int».hasType clen → «unsigned int».hasType inlen →
    «unsigned int».hasType appcap →
    -- `st` holds 512 initialized bytes, and the connection waits for the client Finished.
    stB.length = 512 → stB.getD 0 0 = 1 →
    -- `inp` holds `inlen` received bytes (arbitrary values).
    inB.ilength = inlen →
    -- `out` holds 20480 initialized bytes and `res` four initialized `uint32_t` values.
    outB.length = 20480 → resB.length = 4 →
    -- Ownership: `st`, `out` and `res` writable, `inp` readable (any fraction `qi`); being
    -- separate resources, the four buffers are pairwise disjoint. `tr`, `chain`, `pkey`, `rnd`
    -- and `app` are not accessed in phase 1.
    ⊢ bytes_at S st 1 stB -∗ bytes_at S inp qi inB -∗ bytes_at S out 1 outB -∗
      S.array res «unsigned int» f_LVspecified_OVinteger 1 resB -∗
      -- POSTCONDITIONS (if the call returns)
      (∀ (stB' outB' resB' : Bytes),
        bytes_at S st 1 stB' -∗ bytes_at S inp qi inB -∗ bytes_at S out 1 outB' -∗
        S.array res «unsigned int» f_LVspecified_OVinteger 1 resB' -∗
        ⌊stB'.length = 512 ∧ outB'.length = 20480 ∧ resB'.length = 4 ∧
          post stB inB stB' resB'⌋ -∗
        True -∗ Q value.Vunit) -∗
      S.call «Tls_Conn».Fn.Tls_Conn_input
        [st, tr, chain, clen, pkey, rnd, inp, inlen, out, app, appcap, res] Q

/-- **Property 1** for `Tls_Conn_input` in phase 1, for both cipher suites: a transition out of
phase 1 requires a complete type-23 record that opens under the pre-call client handshake key,
IV and read sequence number and whose plaintext is exactly the expected client Finished message
followed by content type 22 and zero padding. -/
def tls_conn_input_transition_requires_finished {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    Phase1InputContract S (fun st inp st' _ => TransitionRequiresFinished m st inp st')

/-- **Property 2** for `Tls_Conn_input` in phase 1, for both cipher suites: a transition out of
phase 1 enters phase 2 with the client application key and IV installed and a zero read
sequence number, and reports `{5 + rlen, 0, 0, 0}` in `res`. -/
def tls_conn_input_transition_installs_app_keys {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    Phase1InputContract S (fun st inp st' res' => TransitionInstallsAppKeys st inp st' res')

/-- **Property 3** for `Tls_Conn_input` in phase 1, for both cipher suites: no application
bytes; incomplete input consumes nothing and changes nothing; non-transition calls change at
most the read and write sequence numbers; a rejected tag keeps phase 1 and the read sequence
number. -/
def tls_conn_input_phase1_failure_behaviour {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    Phase1InputContract S (fun st inp st' res' => Phase1FailureBehaviour m st inp st' res')

/-- **Memory safety** of `Tls_Conn_input` in phase 1, for both cipher suites: under the
preconditions of `Phase1InputContract`, the call (including every function it reaches) performs
no undefined behaviour, and if it returns the four buffers are handed back with their sizes. -/
def tls_conn_input_phase1_memory_safety {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (m : AeadModel), CryptoContracts S m →
    Phase1InputContract S (fun _ _ _ _ => True)

end TlsConnSpec
