# Building the public specification of `Tls_Conn_input` (phase 1)

The delivered Lean files are:

* `Spec/Tls_Conn/Crypto.lean` — reference SHA-256, HMAC-SHA-256 and HKDF-Expand,
* `Spec/Tls_Conn/Model.lean` — the TLS 1.3 record / key-schedule model and the three outcome
  predicates (properties 1, 2 and 3),
* `Spec/Tls_Conn/Contracts.lean` — the assumed contracts of the six HACL*/EverCrypt functions,
* `Spec/Tls_Conn/ClientFinished.lean` — the public properties of `Tls_Conn_input`,
* `Spec/Tls_Conn/Helpers.lean` — the contracts (memory safety and postconditions) of every
  function reached by `Tls_Conn_input` in phase 1,
* `Tls_Conn/Public.lean` — the generated function handles of `generated/Tls_Conn.c`,
* `C2lean/IList.lean`, `C2lean/IrisCompat.lean`, `C2lean/Public.lean`, `C2lean/Public/*.lean` —
  the public C specification vocabulary.

## Fresh project

1. Create an empty directory, copy the files above into it keeping their paths, and write a
   `lean-toolchain` file containing

   ```
   leanprover/lean4:v4.34.0
   ```

2. Write `lakefile.toml`:

   ```toml
   name = "tls_conn_public_spec"

   [[lean_lib]]
   name = "C2lean"
   globs = ["C2lean.+"]

   [[lean_lib]]
   name = "Tls_Conn"
   globs = ["Tls_Conn.+"]

   [[lean_lib]]
   name = "Spec"
   globs = ["Spec.+"]

   [[require]]
   name = "iris"
   git = "https://github.com/leanprover-community/iris-lean"
   subDir = "Iris"
   rev = "391b22c69f63169c3b1c9dbb0ff736ebeef6514f"

   [[require]]
   name = "mathlib"
   git = "https://github.com/leanprover-community/mathlib4"
   rev = "5ed2965256430c3649e86755f9576b54eca72435"

   [[require]]
   name = "aesop"
   git = "https://github.com/leanprover-community/aesop"
   rev = "v4.34.0"

   [[require]]
   name = "batteries"
   git = "https://github.com/leanprover-community/batteries"
   rev = "v4.34.0"
   ```

3. From that directory run

   ```
   lake update
   lake exe cache get
   lake build Spec
   ```
