# Summary of changes for run b269b83c-3a05-49e5-866c-3c852fdd53a6
Properties 1, 2 and 3 from `SPECIFICATION.txt` are all proved for the submitted `generated/Tls_Conn.c`, starting from `Tls_Conn_input` with `st[0] == 1`. The proofs depend on the C library and HACL*/EverCrypt contracts listed below. Both suites are covered by one statement: `st[245] == 1` is AES-128-GCM, any other value is ChaCha20-Poly1305. I also proved memory safety for `Tls_Conn_input` and, separately, for each of the 27 functions it reaches in phase 1. All results are partial correctness: they hold if the call returns, and do not claim that it returns. The code was translated as submitted for Linux/x86-64, with include paths `generated`, `csrc/hacl`, `csrc/krml` and no defines.

**Property outcomes** (public statements in `Spec/Tls_Conn/ClientFinished.lean`, definitions in `Spec/Tls_Conn/Model.lean`):
- **Property 1 – proved.** If the call leaves phase 1, then:
  - `inp` began with a complete type-23 record with \(17 \le rlen \le 16640\).
  - That record opens under the pre-call key `st[136,168)` (first 16 bytes for AES), with the nonce built from `st[168,180)` and the big-endian read sequence `st[180,188)`, and the 5-byte header as AAD.
  - The plaintext is exactly `20,0,0,32 || FinishedVerify(st[8,40), st[104,136))`, then type 22, then zero padding.
  - Both arguments to `FinishedVerify` are the pre-call values, so opening provably leaves them intact before the comparison.
- **Property 2 – proved.** On that transition, `st` becomes the pre-call state with exactly these changes, and `res == {5 + rlen, 0, 0, 0}`:
  - `st[0] = 2`;
  - `st[136,168)` holds `HKDF-Expand-Label(st[248,280), "key", "", 16 or 32)`, zero-padded for AES;
  - `st[168,180)` holds `HKDF-Expand-Label(st[248,280), "iv", "", 12)`;
  - `st[180,188)` is all zeros.
- **Property 3 – proved.**
  - `res[2] == 0` always.
  - `inlen < 5` gives zero consumed and leaves `st` entirely unchanged (stronger than requested).
  - A complete header declaring `rlen <= 16640` with an incomplete body also gives zero consumed and an unchanged `st`.
  - While still in phase 1, only `st[180,188)` and `st[232,240)` can change.
  - A rejected tag keeps phase 1 and the read sequence.
- **Memory safety – proved.** This covers `Tls_Conn_input` in phase 1 and each reached function under its own stated preconditions:
  - `Tls_Conn_phase1`, `Tls_Conn_open_rec`, `Tls_Conn_check_cfin`, `Tls_Conn_fatal`, `Tls_Conn_set_res`;
  - `unseal`, `seal`, `send_rec`, `send_alert`;
  - `finished_mac`, `expand_label`, `install_client_app`, `install_keys`, `traffic_keys`;
  - `record_content_type`, `seq_ok`, `rd16`, `rd24`;
  - `put_u8`, `put_u16`, `put_buf`, `put_lit_c`;
  - `Tls_Util_put_lit_go`, `Tls_Util_ct_eq`, `Tls_Crypto_make_nonce`, `Tls_Crypto_inc_seq`, `Tls_Crypto_last_nz`.
  
  Their contracts are in `Spec/Tls_Conn/Helpers.lean`.

**Preconditions for `Tls_Conn_input`:**
- `clen`, `inlen` and `appcap` are `uint32_t` values.
- `st` has 512 initialized, writable bytes with `st[0] == 1`.
- `inp` holds `inlen` readable bytes; the contents are arbitrary.
- `out` has 20480 writable bytes.
- `res` has four initialized `uint32_t` slots.
- These four buffers are pairwise disjoint.

Phase 1 never touches `tr`, `chain`, `pkey`, `rnd` or `app`, so nothing is required of them. The proofs do not depend on the `do_ch` handoff contents.

**Assumed external contracts (not verified):**
- `memcpy` and `memset` behave as the standard C library specifies.
- The HACL*/EverCrypt functions, modelled on the F* bindings in `reference/` (`Spec/Tls_Conn/Contracts.lean`):
  - `Hacl_HKDF_expand_sha2_256` and `Hacl_HMAC_compute_sha2_256` produce reference HKDF-Expand-SHA-256 and HMAC-SHA-256 outputs. These reference definitions are executable and agree with the FIPS 180-4, RFC 4231 and RFC 5869 test vectors.
  - For AES-128-GCM and ChaCha20-Poly1305 decryption, a zero return means an abstract opening function accepted the input and produced that plaintext. On any other return the scratch buffer may hold arbitrary bytes.
  - Encryption writes some ciphertext and tag bytes.
  - Each function touches only its own argument buffers.
- The opening functions are left abstract: every result holds for any choice of them.

**Open obligations:** none within the requested scope. The HACL*/EverCrypt and C library implementations are covered only by the contracts above. No claim about memory leaks is made.

`Spec/BUILD.md` explains how to build the published specification files on their own.