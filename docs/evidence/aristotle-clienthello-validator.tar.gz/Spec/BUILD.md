# Building the public specification of the EverParse ClientHello binding

The delivered Lean files are:

* `Spec/ClientHello/Grammar.lean` — the `ClientHelloBody` grammar of `reference/ClientHello.3d`
  (`IsClientHelloBody`, `IsExtensionList`, `IsExtension`, `be16`), the result encoding
  (`validatorMaxLength`, `ResultEncoding`), the grammar outcome (`GrammarOutcome`) and
  `extensionEnd`;
* `Spec/ClientHello/Contracts.lean` — the contracts of the functions reached by
  `Tls_ChValid_validate_prefix` (`ClientHelloValidateClientHelloBody`, `ValidateExtension`,
  `Load16`, the `EverParse.h` helpers and `ignore_error`);
* `Spec/ClientHello/ValidatePrefix.lean` — properties 1 and 2 of `Tls_ChValid_validate_prefix`;
* `ClientHello/Public.lean`, `ch_check/Public.lean` — the function handles of
  `csrc/everparse/ClientHello.c` and `csrc/everparse/ch_check.c`;
* `C2lean/IList.lean`, `C2lean/IrisCompat.lean`, `C2lean/Public.lean`, `C2lean/Public/*.lean` —
  the public C specification vocabulary.

## Fresh project

1. Create an empty directory, copy the files above into it keeping their paths, and write a
   `lean-toolchain` file containing

   ```
   leanprover/lean4:v4.34.0
   ```

2. Write `lakefile.toml`:

   ```toml
   name = "clienthello_public_spec"

   [[lean_lib]]
   name = "C2lean"
   globs = ["C2lean.+"]

   [[lean_lib]]
   name = "ClientHello"
   globs = ["ClientHello.+"]

   [[lean_lib]]
   name = "ch_check"
   globs = ["ch_check.+"]

   [[lean_lib]]
   name = "Spec"
   globs = ["Spec.+"]

   [[require]]
   name = "iris"
   git = "https://github.com/leanprover-community/iris-lean"
   subDir = "Iris"
   rev = "391b22c69f63169c3b1c9dbb0ff736ebeef6514f"

   [[require]]
   name = "mathlib"
   git = "https://github.com/leanprover-community/mathlib4"
   rev = "5ed2965256430c3649e86755f9576b54eca72435"

   [[require]]
   name = "aesop"
   git = "https://github.com/leanprover-community/aesop"
   rev = "v4.34.0"

   [[require]]
   name = "batteries"
   git = "https://github.com/leanprover-community/batteries"
   rev = "v4.34.0"
   ```

3. From that directory run

   ```
   lake update
   lake exe cache get
   lake build Spec
   ```
