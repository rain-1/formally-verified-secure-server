module

public import Spec.ClientHello.Grammar
public import C2lean.Public.Resources
public import ClientHello.Public
public import ch_check.Public

open scoped C2lean

@[expose] public section

/-!
# Public contracts of the functions reached by `Tls_ChValid_validate_prefix`

Each contract below describes one C function of the linked program made of
`csrc/everparse/ch_check.c` and `csrc/everparse/ClientHello.c` (including the `static inline`
helpers of `EverParse.h` and `EverParseEndianness.h` compiled into `ClientHello.c`): the
caller's preconditions, and what holds if the call returns. A contract that owns no memory
describes a function that reads and writes no memory visible to the caller.

Notation: `bytes_at S p q bs` is ownership of fraction `q` of the consecutive initialized
`unsigned char` objects at `p`, holding `bs` (a fraction below 1 only allows reading). A contract
that receives `bytes_at S p q bs` and hands back `bytes_at S p q bs` leaves those bytes unchanged
and keeps no access to them after returning.
-/

namespace ClientHelloSpec

open Iris Iris.BI C2lean.Public C2lean.Public.Resources Ctype
open Ctype.ctype Ctype.basicType Ctype.integerType Ctype.integerBaseType

/-- The C parameter list of `EVERPARSE_ERROR_HANDLER`:
`(const char *, const char *, const char *, uint64_t, uint8_t *, uint8_t *, uint64_t)`. -/
def errorHandlerParams : List (Ctype.ctype × Bool) :=
  [(Pointer (Basic (Integer Char)), false), (Pointer (Basic (Integer Char)), false),
   (Pointer (Basic (Integer Char)), false), (Basic (Integer (Unsigned Long)), false),
   (Pointer (Basic (Integer (Unsigned Ichar))), false),
   (Pointer (Basic (Integer (Unsigned Ichar))), false), (Basic (Integer (Unsigned Long)), false)]

/-- The function named `h`, called through an `EVERPARSE_ERROR_HANDLER` pointer, needs no memory
and returns: for any arguments of the handler's parameter types, a call with no resources
returns. Such a handler cannot read or write any memory of its caller. -/
def ErrorHandlerNoop {PROP : Type} [BI PROP] (S : Vocab PROP) (h : String) : Prop :=
  ∀ (typename_s fieldname reason : pointer_value) (code : ℤ) (ctx input : pointer_value)
    (pos : ℤ) (Q : value → PROP),
    «unsigned long».hasType code → «unsigned long».hasType pos →
    ⊢ Q value.Vunit -∗
      S.callTyped ⟨h⟩ .Void errorHandlerParams false
        [typename_s, fieldname, reason, code, ctx, input, pos] Q

/-- `ignore_error` (`ch_check.c`), the error handler passed by `Tls_ChValid_validate_prefix`,
accesses no memory: for any arguments, a call with no resources returns. In particular it writes
nothing, neither through its `uint8_t *` arguments nor anywhere else. -/
def ignore_error_noop {PROP : Type} [BI PROP] (S : Vocab PROP) : Prop :=
  ∀ (a b c : pointer_value) (code : ℤ) (ctx input : pointer_value) (pos : ℤ) (Q : value → PROP),
    «unsigned long».hasType code → «unsigned long».hasType pos →
    ⊢ Q value.Vunit -∗
      S.call «ch_check».Fn.«ch_check#ignore_error» [a, b, c, code, ctx, input, pos] Q

/-- `EverParseIsError(PositionOrError)` returns `1` if `PositionOrError > 2^60 - 1` and `0`
otherwise, accessing no memory. -/
def everparse_is_error_contract {PROP : Type} [BI PROP] (S : Vocab PROP) : Prop :=
  ∀ (x : ℤ) (Q : value → PROP),
    «unsigned long».hasType x →
    ⊢ Q ((if validatorMaxLength < x then 1 else 0 : ℤ)) -∗
      S.call «ClientHello».Fn.«ClientHello#EverParseIsError» [x] Q

/-- `EverParseIsSuccess(PositionOrError)` returns `1` if `PositionOrError <= 2^60 - 1` and `0`
otherwise, accessing no memory. -/
def everparse_is_success_contract {PROP : Type} [BI PROP] (S : Vocab PROP) : Prop :=
  ∀ (x : ℤ) (Q : value → PROP),
    «unsigned long».hasType x →
    ⊢ Q ((if x ≤ validatorMaxLength then 1 else 0 : ℤ)) -∗
      S.call «ClientHello».Fn.«ClientHello#EverParseIsSuccess» [x] Q

/-- `EverParseSetValidatorErrorPos(Error, Position)` with a position `0 <= Position <= 2^60 - 1`
keeps the top four bits of `Error` (the error kind) and puts `Position` in the low 60 bits:
it returns `(Error / 2^60) * 2^60 + Position`, accessing no memory. -/
def everparse_set_validator_error_pos_contract {PROP : Type} [BI PROP] (S : Vocab PROP) : Prop :=
  ∀ (err pos : ℤ) (Q : value → PROP),
    «unsigned long».hasType err → 0 ≤ pos → pos ≤ validatorMaxLength →
    ⊢ Q ((err / 1152921504606846976 * 1152921504606846976 + pos : ℤ)) -∗
      S.call «ClientHello».Fn.«ClientHello#EverParseSetValidatorErrorPos» [err, pos] Q

/-- `EverParseGetValidatorErrorKind(Error)` returns the top four bits `Error / 2^60`, accessing
no memory. -/
def everparse_get_validator_error_kind_contract {PROP : Type} [BI PROP] (S : Vocab PROP) :
    Prop :=
  ∀ (err : ℤ) (Q : value → PROP),
    «unsigned long».hasType err →
    ⊢ Q ((err / 1152921504606846976 : ℤ)) -∗
      S.call «ClientHello».Fn.«ClientHello#EverParseGetValidatorErrorKind» [err] Q

/-- `EverParseErrorReasonOfResult(Code)` returns a pointer (to one of its string literals),
accessing no memory of the caller. -/
def everparse_error_reason_of_result_contract {PROP : Type} [BI PROP] (S : Vocab PROP) :
    Prop :=
  ∀ (code : ℤ) (Q : value → PROP),
    «unsigned long».hasType code →
    ⊢ (∀ p : pointer_value, Q p) -∗
      S.call «ClientHello».Fn.«ClientHello#EverParseErrorReasonOfResult» [code] Q

/-- `EverParseCheckConstraintOk(Ok, Position)` with `0 <= Position <= 2^60 - 1` returns
`Position` if `Ok != 0`, and otherwise the constraint-failed error
`EVERPARSE_VALIDATOR_ERROR_CONSTRAINT_FAILED | Position` (`6 * 2^60 + Position`), accessing no
memory. -/
def everparse_check_constraint_ok_contract {PROP : Type} [BI PROP] (S : Vocab PROP) : Prop :=
  ∀ (ok pos : ℤ) (Q : value → PROP),
    «unsigned char».hasType ok → 0 ≤ pos → pos ≤ validatorMaxLength →
    ⊢ Q ((if ok ≠ 0 then pos else 6917529027641081856 + pos : ℤ)) -∗
      S.call «ClientHello».Fn.«ClientHello#EverParseCheckConstraintOk» [ok, pos] Q

/-- `Load16(b)` for `b = base + i` where `base[i]` and `base[i + 1]` are readable bytes of the
buffer `base` (`0 <= i` and `i + 2 <= length`): it returns the host (little-endian x86-64)
`uint16_t` `base[i] + 256 * base[i + 1]`, and hands the buffer back unchanged.
It copies the two bytes with `memcpy`, whose C library contract is assumed. -/
def load16_contract {PROP : Type} [BI PROP] (S : Vocab PROP) (_hProp : LibCSpecs S) : Prop :=
  ∀ (base : object_value) (i : ℤ) (bytes : List ℤ) (q : ℚ) (Q : value → PROP),
    0 ≤ i → i + 2 ≤ bytes.length →
    ⊢ bytes_at S base q bytes -∗
      (bytes_at S base q bytes -∗
        Q ((bytes.getD i.toNat 0 + 256 * bytes.getD (i + 1).toNat 0 : ℤ))) -∗
      S.call «ClientHello».Fn.«ClientHello#Load16»
        [S.array_shift base «unsigned char» (.OVinteger i)] Q

/-- `ValidateExtension(Ctxt, ErrorHandlerFn, Input, InputLength, StartPosition)` (the validator
of one `Extension`, as called on the truncated extension vector): with `Input` holding the
readable `bytes`, `InputLength <= length` and `StartPosition <= InputLength`, and an error
handler that needs no memory, it hands the bytes back unchanged and returns
`extensionEnd bytes InputLength StartPosition` when that is a position (a complete extension
inside `[StartPosition, InputLength)`), and otherwise an encoded error above `2^60 - 1`. -/
def validate_extension_contract {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (ctx : pointer_value) (h : String) (input : pointer_value) (inputLength startPosition : ℤ)
    (bytes : List ℤ) (q : ℚ) (Q : value → PROP),
    ErrorHandlerNoop S h →
    bytes.length ≤ 4294967295 →
    0 ≤ startPosition → startPosition ≤ inputLength → inputLength ≤ bytes.length →
    ⊢ bytes_at S input q bytes -∗
      (∀ r : ℤ, bytes_at S input q bytes -∗
        ⌊match extensionEnd bytes inputLength startPosition with
          | some e => r = e
          | none => validatorMaxLength < r ∧ r ≤ 18446744073709551615⌋ -∗ Q r) -∗
      S.call «ClientHello».Fn.«ClientHello#ValidateExtension»
        [(ctx : value), (pointer_value.PVfunptr h : value), input, inputLength, startPosition] Q

/-- `ClientHelloValidateClientHelloBody(Ctxt, ErrorHandlerFn, Input, InputLength, 0)` with
`Input` holding `InputLength` readable bytes (`InputLength` a `uint32_t` value, possibly zero)
and an error handler that needs no memory (any `Ctxt`): it hands the bytes back unchanged and
returns a result `r` that is a success offset `r <= InputLength` or an encoded error above
`2^60 - 1` (`ResultEncoding`), such that a success means `Input[0, r)` is a complete
`ClientHelloBody` and every complete `ClientHelloBody` prefix is the one reported
(`GrammarOutcome`). It copies bytes with `memcpy`, whose C library contract is assumed. -/
def client_hello_validate_body_contract {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ∀ (ctx : pointer_value) (h : String) (input : pointer_value) (inputLength : ℤ)
    (bytes : List ℤ) (q : ℚ) (Q : value → PROP),
    ErrorHandlerNoop S h →
    «unsigned int».hasType inputLength → (bytes.length : ℤ) = inputLength →
    ⊢ bytes_at S input q bytes -∗
      (∀ r : ℤ, bytes_at S input q bytes -∗
        ⌊ResultEncoding bytes r ∧ GrammarOutcome bytes r⌋ -∗ Q r) -∗
      S.call «ClientHello».Fn.ClientHelloValidateClientHelloBody
        [(ctx : value), (pointer_value.PVfunptr h : value), input, inputLength, (0 : ℤ)] Q

end ClientHelloSpec
