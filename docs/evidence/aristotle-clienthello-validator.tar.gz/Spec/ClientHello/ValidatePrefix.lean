module

public import Spec.ClientHello.Contracts

open scoped C2lean

@[expose] public section

/-!
# Public specification: `Tls_ChValid_validate_prefix`

```c
uint64_t Tls_ChValid_validate_prefix(uint8_t *b, uint32_t len) {
  return ClientHelloValidateClientHelloBody(NULL, ignore_error, b, len, 0);
}
```

These are the contracts proved about the linked program made of the submitted
`csrc/everparse/ch_check.c` and `csrc/everparse/ClientHello.c` (Linux x86-64). They are
partial-correctness statements: the outcome holds if the call returns.
-/

namespace ClientHelloSpec

open Iris Iris.BI C2lean.Public C2lean.Public.Resources Ctype

/-- A call `Tls_ChValid_validate_prefix(b, len)` on any readable byte span satisfies the outcome
predicate `post bytes r` about its result `r`.

Preconditions: `len` is a `uint32_t` value (zero allowed) and `b` points to `len` readable
initialized bytes `bytes`, of which the caller lends any fraction `q` (nothing at all is
required when `len == 0`).

Postconditions (if the call returns): the very same fraction of the same bytes is handed back,
so the input is unchanged and no access to it is retained, the call performed no undefined
behaviour (in particular no out-of-bounds read or write), and the result `r` satisfies
`post bytes r`. -/
def ValidatePrefixContract {PROP : Type} [BI PROP] (S : Vocab PROP)
    (post : List ℤ → ℤ → Prop) : Prop :=
  ∀ (b : pointer_value) (len : ℤ) (bytes : List ℤ) (q : ℚ) (Q : value → PROP),
    -- PRECONDITIONS
    -- `len` is a `uint32_t` value, and `b[0, len)` are readable initialized bytes.
    «unsigned int».hasType len → (bytes.length : ℤ) = len →
    ⊢ bytes_at S b q bytes -∗
      -- POSTCONDITIONS (if the call returns)
      -- the bytes come back unchanged, and the result `r` satisfies `post bytes r`
      (∀ r : ℤ, bytes_at S b q bytes -∗ ⌊post bytes r⌋ -∗ Q r) -∗
      S.call «ch_check».Fn.Tls_ChValid_validate_prefix [b, len] Q

/-- `Tls_ChValid_validate_prefix(b, len)` forwards exactly the result of
`ClientHelloValidateClientHelloBody(NULL, ignore_error, b, (uint64_t)len, 0)`: validation starts at
offset zero, with a `NULL` context and the `ignore_error` handler, and any property `Q` of the
(`uint64_t`) value returned by that call holds of the value returned by the adapter. -/
def ValidatePrefixForwards {PROP : Type} [BI PROP] (S : Vocab PROP) : Prop :=
  ∀ (b : pointer_value) (len : ℤ) (Q : value → PROP),
    «unsigned int».hasType len →
    ⊢ S.call «ClientHello».Fn.ClientHelloValidateClientHelloBody
        [(pointer_value.PVnull : value),
         (pointer_value.PVfunptr «ch_check».Fn.«ch_check#ignore_error».name : value),
         b, len, (0 : ℤ)]
        (fun v => iprop(∃ (r : ℤ), ⌊v = r ∧ «unsigned long».hasType r⌋ ∗ Q v)) -∗
      S.call «ch_check».Fn.Tls_ChValid_validate_prefix [b, len] Q

/-- **Property 1** of `SPECIFICATION.txt` for `Tls_ChValid_validate_prefix`:
* for any readable span `b[0, len)` (`len` any `uint32_t`, including zero) the call has no
  undefined behaviour (no out-of-bounds read or write), hands the input back unchanged with no
  access retained, and returns either a success offset `0 <= r <= len` or an encoded error
  `2^60 - 1 < r <= 2^64 - 1` (`ResultEncoding`);
* the adapter forwards exactly the validator's result, starting validation at offset zero
  (`ValidatePrefixForwards`);
* the error callback `ignore_error` it installs accesses (in particular writes) no memory
  (`ignore_error_noop`).

Assumption: the C library contract of `memcpy` (part of `LibCSpecs`), used by `Load16`. -/
def tls_chvalid_validate_prefix_property1 {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ValidatePrefixContract S ResultEncoding ∧ ValidatePrefixForwards S ∧ ignore_error_noop S

/-- **Property 2** of `SPECIFICATION.txt` for `Tls_ChValid_validate_prefix`: under the same
preconditions, a success result `r` (at most `2^60 - 1`) is at most `len` and `b[0, r)` is one
complete `ClientHelloBody` of `reference/ClientHello.3d`; `r == len` implies that the whole
input is one complete `ClientHelloBody`; and conversely, whenever a prefix `b[0, n)` (for
instance the whole input) is a complete `ClientHelloBody`, the result is exactly `n`
(`GrammarOutcome`).

Assumption: the C library contract of `memcpy` (part of `LibCSpecs`), used by `Load16`. The
grammar and bounds of the validator are proved, not assumed. -/
def tls_chvalid_validate_prefix_property2 {PROP : Type} [BI PROP] (S : Vocab PROP)
    (_hProp : LibCSpecs S) : Prop :=
  ValidatePrefixContract S GrammarOutcome

end ClientHelloSpec
