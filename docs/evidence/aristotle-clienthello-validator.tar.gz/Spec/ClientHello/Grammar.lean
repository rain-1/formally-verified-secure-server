module

public import C2lean.Public

@[expose] public section

/-!
# The `ClientHelloBody` grammar of `reference/ClientHello.3d`

A byte string is modelled as a `List ℤ` (each element is the value of one `uint8_t`). The
definitions below transcribe the EverParse 3D grammar:

```
typedef struct _Extension {
  UINT16BE ext_type;
  UINT16BE ext_len;
  UINT8    ext_data[:byte-size ext_len];
} Extension;

entrypoint typedef struct _ClientHelloBody {
  UINT16BE legacy_version;
  UINT8    random[32];
  UINT8    session_id_len { session_id_len <= 32 };
  UINT8    session_id[:byte-size session_id_len];
  UINT16BE cipher_suites_len { cipher_suites_len >= 2 && cipher_suites_len % 2 == 0 };
  UINT8    cipher_suites[:byte-size cipher_suites_len];
  UINT8    compression_len { compression_len >= 1 };
  UINT8    compression[:byte-size compression_len];
  UINT16BE extensions_len ;
  Extension extensions[:byte-size extensions_len];
} ClientHelloBody;
```

Multibyte lengths are big-endian. The grammar describes framing only: the meaning of the field
values (versions, cipher suites, extension types, duplicates, ...) is left to the caller.
-/

namespace ClientHelloSpec

/-- The value of a big-endian `UINT16BE` made of the bytes `hi`, `lo` (in that order). -/
def be16 (hi lo : ℤ) : ℤ := hi * 256 + lo

/-- One complete `Extension`: two bytes of `ext_type`, two bytes of big-endian `ext_len`, then
exactly `ext_len` bytes of `ext_data`. -/
def IsExtension (s : List ℤ) : Prop :=
  ∃ (type_hi type_lo len_hi len_lo : ℤ) (ext_data : List ℤ),
    s = [type_hi, type_lo, len_hi, len_lo] ++ ext_data ∧
    (ext_data.length : ℤ) = be16 len_hi len_lo

/-- `Extension extensions[:byte-size n]` for a byte string of length `n`: the bytes are exactly
tiled by complete `Extension` entries (no partial entry at the end). -/
inductive IsExtensionList : List ℤ → Prop where
  | nil : IsExtensionList []
  | cons {e rest : List ℤ} : IsExtension e → IsExtensionList rest → IsExtensionList (e ++ rest)

/-- `s` is one complete value of `ClientHelloBody`: the fields in order, with the declared
lengths and constraints of the 3D grammar, and nothing after the extension vector. -/
def IsClientHelloBody (s : List ℤ) : Prop :=
  ∃ (legacy_version random : List ℤ) (session_id_len : ℤ) (session_id : List ℤ)
    (cs_hi cs_lo : ℤ) (cipher_suites : List ℤ) (compression_len : ℤ) (compression : List ℤ)
    (ext_hi ext_lo : ℤ) (extensions : List ℤ),
    s = legacy_version ++ random ++ [session_id_len] ++ session_id ++ [cs_hi, cs_lo] ++
          cipher_suites ++ [compression_len] ++ compression ++ [ext_hi, ext_lo] ++ extensions ∧
    -- `UINT16BE legacy_version` and `UINT8 random[32]`
    legacy_version.length = 2 ∧ random.length = 32 ∧
    -- `session_id_len <= 32`, followed by that many bytes
    session_id_len ≤ 32 ∧ (session_id.length : ℤ) = session_id_len ∧
    -- `cipher_suites_len >= 2 && cipher_suites_len % 2 == 0`, followed by that many bytes
    2 ≤ be16 cs_hi cs_lo ∧ be16 cs_hi cs_lo % 2 = 0 ∧
    (cipher_suites.length : ℤ) = be16 cs_hi cs_lo ∧
    -- `compression_len >= 1`, followed by that many bytes
    1 ≤ compression_len ∧ (compression.length : ℤ) = compression_len ∧
    -- `extensions_len`, followed by exactly that many bytes of complete extensions
    (extensions.length : ℤ) = be16 ext_hi ext_lo ∧ IsExtensionList extensions

/-- `EVERPARSE_VALIDATOR_MAX_LENGTH` (`2^60 - 1`): results up to this value are end positions,
results above it are encoded errors. -/
def validatorMaxLength : ℤ := 1152921504606846975

/-- The encoding of a validation result `r` for an input of `bytes`: either a success, an end
offset `0 ≤ r ≤ len`, or a failure, an encoded error strictly above `2^60 - 1` (and a `uint64_t`).
Since `len` is a `uint32_t`, the two ranges are disjoint. -/
def ResultEncoding (bytes : List ℤ) (r : ℤ) : Prop :=
  (0 ≤ r ∧ r ≤ bytes.length) ∨ (validatorMaxLength < r ∧ r ≤ 18446744073709551615)

/-- What a validation result `r` says about the grammar, for an input of `bytes`:
* a success `r` (at most `2^60 - 1`) is at most `len`, and `bytes[0, r)` is one complete
  `ClientHelloBody`;
* in particular `r == len` means the whole input is one complete `ClientHelloBody`;
* conversely, if some prefix `bytes[0, n)` is a complete `ClientHelloBody` (for instance the whole
  input, `n = len`), then the result is exactly `n`. -/
def GrammarOutcome (bytes : List ℤ) (r : ℤ) : Prop :=
  (r ≤ validatorMaxLength → r ≤ bytes.length ∧ IsClientHelloBody (bytes.take r.toNat)) ∧
  (r = bytes.length → IsClientHelloBody bytes) ∧
  (∀ n : ℕ, n ≤ bytes.length → IsClientHelloBody (bytes.take n) → r = n)

/-- One step of `ValidateExtension` on the bytes `bs`, with the (truncated) input length `T`,
starting at position `p`: the end position of a complete `Extension` at `p` within `[p, T)`, or
`none` if there is none (not enough bytes for the header or for the declared `ext_data`). -/
def extensionEnd (bs : List ℤ) (T p : ℤ) : Option ℤ :=
  if p + 4 ≤ T ∧ p + 4 + be16 (bs.getD (p + 2).toNat 0) (bs.getD (p + 3).toNat 0) ≤ T then
    some (p + 4 + be16 (bs.getD (p + 2).toNat 0) (bs.getD (p + 3).toNat 0))
  else none

end ClientHelloSpec
