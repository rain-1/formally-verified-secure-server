# Summary of changes for run 5cde04da-cd4a-4e0c-8d7d-12ec0ddad7ea
Both requested properties of `Tls_ChValid_validate_prefix` are now machine-checked against the actual code, and both hold under the conditions below. The proof covers the program made by linking the unmodified `csrc/everparse/ch_check.c` and `csrc/everparse/ClientHello.c` (Linux x86-64, `-std=gnu11`, include paths `generated`, `csrc/everparse`, `csrc/krml`, no defines). It goes through the real submitted bodies of `ClientHelloValidateClientHelloBody`, `ValidateExtension`, `Load16` and the `EverParse.h` result helpers. There are no `sorry`s, and only Lean's standard axioms are used.

**Caller preconditions (both properties):** `len` is any `uint32_t`, including 0, and `b` points to `len` readable, initialized bytes. Any read-only share of them is enough, and nothing is needed when `len == 0`.

**Property 1 — proved.**
- The call has no undefined behaviour, so there are no out-of-bounds reads or writes.
- It hands back the same share of the same bytes: the input is unchanged and no access to it is kept.
- If it returns, the result `r` is either a success offset `0 <= r <= len` or an encoded error with `2^60 - 1 < r <= 2^64 - 1`. Because `len` is a `uint32_t`, the two ranges cannot overlap.
- The adapter returns exactly the result of `ClientHelloValidateClientHelloBody(NULL, ignore_error, b, len, 0)`, so validation starts at offset 0.
- `ignore_error` needs no memory at all, so it writes nothing.

**Property 2 — proved, including the converse.**
- A success `r` satisfies `r <= len`, and `b[0, r)` is one complete `ClientHelloBody` of `reference/ClientHello.3d`:
  - a two-byte `legacy_version` and a 32-byte `random`;
  - `session_id_len <= 32`, followed by that many bytes;
  - a big-endian `cipher_suites_len` that is even and at least 2, followed by that many bytes;
  - `compression_len >= 1`, followed by that many bytes;
  - a big-endian `extensions_len`, followed by exactly that many bytes tiled by complete type/length/value extensions.
- `r == len` means the whole input matches.
- Conversely, if any prefix `b[0, n)` is a complete `ClientHelloBody`, the result is exactly `n`; in particular a full match gives `r == len`.
- The validator's grammar correctness and bounds are proved from its C body, not assumed.

**Also proved and registered as supporting results:**
- the contracts of `ClientHelloValidateClientHelloBody` and `ValidateExtension`;
- `Load16`: it reads only the two in-bounds bytes and returns their little-endian value, which the code then byte-swaps into a big-endian length;
- `ignore_error` touches no memory;
- `EverParseIsError`, `EverParseIsSuccess`, `EverParseSetValidatorErrorPos`, `EverParseGetValidatorErrorKind` and `EverParseCheckConstraintOk` return the exact expected values;
- `EverParseErrorReasonOfResult` is memory safe.

**Assumptions and limits:**
- **`memcpy`:** the only external assumption is the standard C library contract for `memcpy`, which `Load16` uses to copy two bytes into a local `uint16_t`.
- **Partial correctness:** each outcome holds if the call returns; termination is not claimed.
- **Implementation-defined behaviour:** integer conversions follow GCC/Clang on x86-64.
- **Grammar scope:** the grammar covers framing only. Negotiation policy, duplicate extensions and the meaning of field values are left to the caller.

The public specifications are in `Spec/ClientHello/ValidatePrefix.lean`, `Spec/ClientHello/Contracts.lean` and `Spec/ClientHello/Grammar.lean`, published with the public interfaces they depend on. Build instructions are in `Spec/BUILD.md`, and every claim is listed in the Properties table.