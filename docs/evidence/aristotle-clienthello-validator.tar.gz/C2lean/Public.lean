module

public import Mathlib.Data.Rat.Defs
public import C2lean.Public.Integer
public import C2lean.Public.Array
public import C2lean.IList
public import C2lean.IrisCompat

@[expose] public section

/-!
# Public interface vocabulary

A specification imports a program's generated `Public.lean`, which imports this vocabulary and
records aggregate layouts (`tagDefs`) and a named `CFun` handle per function. Distributing the
support sources alongside that interface makes the specification usable in a standalone Lean
project with the documented public dependencies.

A `Spec.lean` states a predicate on an arbitrary `Vocab PROP`:

```lean
def f_spec {PROP : Type} [BI PROP] (S : C2lean.Public.Vocab PROP)
    (hProp : C2lean.Public.LibCSpecs S) : Prop :=
  ∀ x, … → ⊢ P -∗ S.call Fn.f [x] Q
```

The vocabulary supplies operations for calls, owned memory, C object layouts and accesses of
device registers, without assuming laws about those operations. `LibCSpecs S` is an abstract proposition whose interpretation
uses the existing private libc bundle. A contract states the caller's preconditions and the guarantees of
each returning call, including resources returned to the caller. Such a contract does not by
itself claim termination or whole-program startup safety.

The call predicates inherit the prerequisite that the name, signature and encoded arguments
describe a well-formed translated C call. They do not establish that prerequisite themselves.
-/

open Iris Iris.BI

namespace C2lean.Public

/-- A named C function handle for public specifications. -/
structure CFun where
  name : String
  deriving DecidableEq

/-- Operations available to a public property. No laws about these operations are assumed. -/
class Vocab (PROP : Type u) [BI PROP] where
  /-- `wp_ccall f args Q`: if `f` with encoded arguments `args` is a well-formed translated
  C call, the call is safe and every result `v` satisfies `Q v`. Well-formedness includes the
  argument count, value kinds/ranges and required variadic calling form. This predicate does
  not assert that those conditions hold for a hand-written argument list. -/
  wp_ccall : String → List value → (value → PROP) → PROP
  /-- Call through a function pointer at an expected C signature. The signature includes
  parameter attributes and whether the pointer's function type is variadic. The same
  well-formed-call prerequisite as `wp_ccall` applies; signature matching does not establish it. -/
  wp_ccall0 : Ctype.ctype → List (Ctype.ctype × Bool) → Bool → String → List value →
    (value → PROP) → PROP
  /-- Typed call with an explicit calling convention, with the same well-formed-call
  prerequisite as `wp_ccall0`. -/
  wp_ccall0_cc : Ctype.callingConvention → Ctype.ctype → List (Ctype.ctype × Bool) → Bool →
    String → List value → (value → PROP) → PROP
  /-- `points_to p τ q v`: fraction `q` of the object of type `τ` at `p`, which holds `v`. -/
  points_to : object_value → Ctype.ctype → ℚ → loaded_value → PROP
  /-- Ownership of an object that may be misaligned, such as a packed member. This predicate
  does not promise that converting its address to an aligned pointer is safe. -/
  points_to_misaligned : object_value → Ctype.ctype → ℚ → loaded_value → PROP
  /-- The pointer has the alignment and access provenance required by the object type. The
  predicate is a resource proposition because type-based access permissions depend on memory. -/
  ptr_well_derived : object_value → Ctype.ctype → PROP
  /-- A value's representation as provenance-preserving C bytes. These are distinct from
  ordinary `unsigned char` bytes, which do not preserve pointer provenance. -/
  representation_bytes : Ctype.ctype → loaded_value → loaded_value → Prop
  /-- Whether contracts must preserve the object's strict-aliasing commitments. -/
  strictAliasing : Prop
  /-- `array_shift p τ k`: `p + k` for a pointer `p` to `τ`. -/
  array_shift : object_value → Ctype.ctype → object_value → object_value
  /-- `member_shift p tag m`: `&p->m` for a pointer `p` to `struct tag` or `union tag`. -/
  member_shift : object_value → String → String → object_value
  /-- `malloced p τ`: the block at `p` came from `malloc` and may be passed to `free`. -/
  malloced : object_value → Ctype.ctype → PROP
  /-- Ownership of the current thread's `errno`. -/
  errno : PROP
  /-- `device_read addr size Φ`: permission for one read of the device register of `size` bytes at
  `addr`, which a volatile access through a pointer converted from an integer makes; `Φ v` holds
  for the representation `v`, an unsigned integer, that the read returns. -/
  device_read : Nat → Nat → (Nat → PROP) → PROP
  /-- `device_write addr size v Φ`: permission for one write of `v`, the representation of `size`
  bytes as an unsigned integer, to the device register at `addr`; `Φ` holds after it. -/
  device_write : Nat → Nat → Nat → PROP → PROP
  sizeof : Ctype.ctype → Int
  alignof : Ctype.ctype → Int
  /-- The library assumptions required by an ordinary libc client. Their implementation
  belongs to the private verification environment. This field supplies no proof. -/
  libCSpecs : Prop
  /-- The separate tracked-I/O assumptions. Select this family independently of `libCSpecs`. -/
  libCIOSpecs : Prop

/-- Abstract ordinary-libc assumptions. The public interface exposes no library formulas. -/
abbrev LibCSpecs {PROP : Type u} [BI PROP] (S : Vocab PROP) : Prop := S.libCSpecs

/-- Abstract assumptions for the existing tracked-I/O model. -/
abbrev LibCIOSpecs {PROP : Type u} [BI PROP] (S : Vocab PROP) : Prop := S.libCIOSpecs

/-- `S.call f args Q` is `S.wp_ccall` for the function with handle `f`, retaining its
well-formed-call prerequisite. A handle records a name, not valid arguments for that function. -/
abbrev Vocab.call {PROP : Type u} [BI PROP] (S : Vocab PROP) (f : CFun) (args : List value)
    (Q : value → PROP) : PROP :=
  S.wp_ccall f.name args Q

/-- A call through a function pointer with the stated signature. Its interpretation checks
the actual callee's signature after linking. Argument well-formedness remains a prerequisite;
matching the signature does not validate the supplied list's count, values or variadic packing. -/
abbrev Vocab.callTyped {PROP : Type u} [BI PROP] (S : Vocab PROP) (f : CFun)
    (τret : Ctype.ctype) (τparams : List (Ctype.ctype × Bool)) (variadic : Bool)
    (args : List value) (Q : value → PROP) : PROP :=
  S.wp_ccall0 τret τparams variadic f.name args Q

/-- `callTyped` with an explicit calling convention and the same well-formed-call prerequisite. -/
abbrev Vocab.callTypedCC {PROP : Type u} [BI PROP] (S : Vocab PROP) (f : CFun)
    (cc : Ctype.callingConvention) (τret : Ctype.ctype)
    (τparams : List (Ctype.ctype × Bool)) (variadic : Bool)
    (args : List value) (Q : value → PROP) : PROP :=
  S.wp_ccall0_cc cc τret τparams variadic f.name args Q

/-- `S.array p τ f q elems`: consecutive objects of type `τ` from `p` on, holding
`f elem` for each of `elems`. The empty array owns no resources. -/
abbrev Vocab.array {PROP : Type u} [BI PROP] [S : Vocab PROP] {T : Type}
    (p : object_value) (τ : Ctype.ctype) (f : T → loaded_value) (q : ℚ) (elems : List T) : PROP :=
  arrayWith S.points_to S.array_shift p τ f q elems

/-- A raw array owns its entire storage with an existentially quantified loaded value. -/
def Vocab.raw_array {PROP : Type u} [BI PROP] [S : Vocab PROP]
    (p : object_value) (τ : Ctype.ctype) (q : ℚ) (n : Int) : PROP :=
  iprop(∃ v : loaded_value, S.points_to p (.Array_ τ (some n)) q v)

namespace Vocab

scoped syntax:36 term:37 " ↦[" term ", " term "] " term:36 : term
scoped syntax:36 term:37 " ↦[" term "] " term:36 : term
scoped macro_rules
  | `($ell ↦[$tau, $q] $v) => `(C2lean.Public.Vocab.points_to $ell $tau $q $v)
  | `($ell ↦[$tau] $v) => `(C2lean.Public.Vocab.points_to $ell $tau 1 $v)

end Vocab

/-- A public property over the vocabulary. A specification with an explicit library-proof
argument is closed as `fun S => ∀ hProp : LibCSpecs S, spec S hProp`. -/
abbrev Property := ∀ {PROP : Type} [BI PROP], Vocab PROP → Prop

end C2lean.Public
