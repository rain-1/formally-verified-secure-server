module

/-
Compatibility shims for the Iris-Lean proof mode.

Iris-Lean reorganised a few pieces of its interface when it moved to the Lean 4.33
release line.  The changes below are purely surface-level, so rather than rewriting
every proof in the repository we re-introduce the spellings c2lean uses.
-/

public import Iris.ProofMode

public meta import Lean

@[expose] public section

/-
`Entails'` is `Entails` tagged so that Iris proof-mode goals can be recognised.  It used
to be an `abbrev`; it is now a plain `def`, which hides it from the proof-mode tactics
(`istart`, `icases`, …) whenever the hypothesis side is not itself a parsed `Hyps`
context — exactly the shape of c2lean's `⊨` wp-rule statements.  Restore the old
reducibility so that those tactics see through it again.
-/
set_option allowUnsafeReducibility true in
attribute [reducible] Iris.ProofMode.Entails'

namespace Iris.ProofMode
open Lean

/-- `⌜h⌝` moves a hypothesis into the pure Lean context.  Iris-Lean now spells this `%h`. -/
syntax "⌜" binderIdent "⌝" : icasesPat

macro_rules
  | `(icasesPat| ⌜$name:ident⌝) => `(icasesPat| %$name:ident)
  | `(icasesPat| ⌜_⌝) => `(icasesPat| %_)

/-- `□p` moves a hypothesis into the intuitionistic context.  Iris-Lean now spells this `#p`. -/
syntax "□" icasesPat : icasesPat

macro_rules
  | `(icasesPat| □ $pat) => `(icasesPat| #$pat)

/-
Iris-Lean used to separate the arguments of a proof-mode term (`h $$ a, b`) and the
hypotheses of a framing spec pattern (`h $$ [Ha, Hb]`) with commas; both are now
whitespace-separated.  Accept the comma spellings and translate them.  Both shims
require at least one comma so that they never compete with the built-in syntax.
-/

syntax term " $$ " specPat "," specPat,+ : pmTerm

macro_rules
  | `(pmTerm| $t:term $$ $p:specPat, $ps:specPat,*) => `(pmTerm| $t:term $$ $p $ps*)

syntax "[" ident "," ident,+ "]" (" as " ident)? : specPat

macro_rules
  | `(specPat| [$i:ident, $is:ident,*]) => do
      let fs ← (#[i] ++ is.getElems).mapM fun x => `(frameIdent| $x:ident)
      `(specPat| [$fs*])
  | `(specPat| [$i:ident, $is:ident,*] as $x:ident) => do
      let fs ← (#[i] ++ is.getElems).mapM fun y => `(frameIdent| $y:ident)
      `(specPat| [$fs*] as $x:ident)

end Iris.ProofMode

/-- An empty big separating conjunction is `emp`, so a proof may drop it even without
`BIAffine` (struct and array unfolds end in one). -/
instance Iris.BI.bigOp_sep_nil_affine {PROP : Type _} [Iris.BI PROP] :
    Iris.BI.Affine (iprop([∗] []) : PROP) :=
  ⟨Iris.BI.bigOp_sep_nil.1⟩

/-- `P` keeps all its resources and also yields the persistent `Q` it contains.  Under
`BIAffine`, `persistent_entails_left` does this from `P ⊢ Q`; without it, `P` usually entails
only `<absorb> Q`, because the rest of `P` cannot be dropped.  For example, a hash table yields
the `ptr_well_derived` of its bucket array once its chains are forgotten.  In a proof:
`icases absorbingly_persistent_entails_left h $$ HP with ⟨HP, #HQ⟩`. -/
theorem Iris.BI.absorbingly_persistent_entails_left {PROP : Type _} [Iris.BI PROP] {P Q : PROP}
    [Iris.BI.Persistent Q] (h : P ⊢ <absorb> Q) : P ⊢ P ∗ □ Q :=
  (Iris.BI.and_intro .rfl
    ((h.trans (Iris.BI.absorbingly_mono Iris.BI.persistent)).trans
      Iris.BI.absorbingly_persistently.1)).trans
    Iris.BI.persistently_and_intuitionistically_sep_right.1

namespace C2lean

/-- `⌊φ⌋` is `<affine> ⌜φ⌝`: the pure fact `φ`, owning no resources.  Unlike `⌜φ⌝`, it is not
absorbing, so it is the form to use where a pure fact is an operand of `∗` or the premise of a
`-∗`: a proof can neither hide resources in it nor be stuck with it without `BIAffine`.  Under
`∧`, under `→` and as the whole conclusion of `⊢`, keep `⌜φ⌝`. `⌊h⌋` is not an `icases`
pattern; destructure with `%h` or `⌜h⌝` as usual.

The notation is scoped, so that C2lean can be imported together with libraries that declare
the same notation (mir2lean's `SepLogic`).  Outside `namespace C2lean`, write
`open scoped C2lean` to use it. -/
scoped syntax "⌊" term "⌋" : term

macro_rules
  | `(iprop(⌊$φ⌋)) => ``(iprop(<affine> ⌜$φ⌝))

-- Also outside `iprop(…)`: where Mathlib's floor notation `⌊x⌋` is in scope, `⌊φ⌋` parses both
-- ways and reaches the elaborator as a choice, which keeps the reading that type-checks.  Without
-- an expected type (a bare `#check ⌊x⌋`) the two readings are ambiguous; add a type ascription.
macro_rules
  | `(⌊$φ⌋) => ``(iprop(<affine> ⌜$φ⌝))

/-- Print `<affine> ⌜φ⌝` as `⌊φ⌋`. -/
@[scoped app_unexpander Iris.BI.BIBase.affinely]
meta def unexpandAffinePure : Lean.PrettyPrinter.Unexpander
  | `($_ iprop(⌜$φ⌝)) => `(iprop(⌊$φ⌋))
  | _ => throw ()

end C2lean

/-- Without `BIAffine`, `iintro`, `icases` and `ipure` fail on a pure `⌜φ⌝` because it is not
affine, but Iris's errors only say the hypothesis is "not an existential quantifier" or "cannot be
turned into a universal quantifier".  Run the Iris tactic and say what to change instead. -/
@[no_fallback, tactic Iris.ProofMode.tacticIintro___,
  tactic Iris.ProofMode.«tacticIcases+keep__With__», tactic Iris.ProofMode.tacticIpure__,
  tactic Iris.ProofMode.tacticIpure__With_]
meta def evalWithAffinePureHint : Lean.Elab.Tactic.Tactic := fun stx => do
  let some iris := (Lean.Elab.Tactic.tacticElabAttribute.getEntries (← Lean.getEnv)
      stx.getKind).find? (·.declName != decl_name%)
    | Lean.Elab.throwUnsupportedSyntax
  try iris.value stx
  catch
    | .error ref msg =>
      unless (← msg.toString).contains "iprop(⌜" do throw (.error ref msg)
      throw (.error ref m!"{msg}\n\nHint: C2Lean has no `BIAffine`, so `⌜φ⌝` is not affine: \
        `⌜φ⌝ -∗ Q` and `⌜φ⌝ ∗ P` can be introduced or destructured only if the goal is \
        absorbing.  With `open scoped C2lean`, state the fact as `⌊φ⌋` (`⌊φ⌋ -∗ Q`, `⌊φ⌋ ∗ P`) \
        or as `⌜φ⌝ → Q`; then `%h` and `⌜h⌝` work.")
    | ex => throw ex
