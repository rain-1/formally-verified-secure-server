module

public import C2lean.Public

@[expose] public section

/-!
# String and byte ownership for customer specifications

These predicates describe owned memory. Library function contracts remain private.
-/

open Iris Iris.BI Ctype Ctype.ctype object_value loaded_value

namespace C2lean.Public.Resources

variable {PROP : Type u} [BI PROP]

/-- Consecutive initialized `unsigned char` objects. -/
def bytes_at (S : Vocab PROP) (ptr : object_value) (q : ℚ)
    (bytes : List ℤ) : PROP :=
  S.array ptr «unsigned char» f_LVspecified_OVinteger q bytes

/-- Consecutive initialized `char` objects, without a terminator requirement. -/
def chars_at (S : Vocab PROP) (ptr : object_value) (q : ℚ)
    (chars : List ℤ) : PROP :=
  S.array ptr char f_LVspecified_OVinteger q chars

/-- A string's nonzero characters and its readable NUL terminator. -/
def cstring_at (S : Vocab PROP) (ptr : object_value) (q : ℚ)
    (chars : List ℤ) : PROP :=
  iprop(chars_at S ptr q chars ∗ ⌊0 ∉ chars⌋ ∗
    S.points_to (S.array_shift ptr char (OVinteger chars.ilength)) char q
      (f_LVspecified_OVinteger 0))

end C2lean.Public.Resources
