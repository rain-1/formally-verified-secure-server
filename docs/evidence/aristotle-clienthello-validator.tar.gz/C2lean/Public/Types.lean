module

@[expose] public section

/-!
# C types and values for public specifications

The data used to state a C contract: C types and aggregate layouts, locations, pointers,
initialized and unspecified object values, and the values passed to a function or returned by it.
The public vocabulary uses these data types to describe inputs, outputs and owned memory.
This module depends only on Lean's standard library.
-/

namespace Ctype

  inductive integerBaseType where
  | Ichar : integerBaseType
  | Short : integerBaseType
  | Int_ : integerBaseType
  | Long : integerBaseType
  | LongLong : integerBaseType
  | IntN_t : Nat → integerBaseType
  | Int_leastN_t : Nat → integerBaseType
  | Int_fastN_t : Nat → integerBaseType
  | Intmax_t : integerBaseType
  | Intptr_t : integerBaseType

  deriving instance DecidableEq, Repr for integerBaseType

  inductive integerType where
  | Char : integerType
  | Bool : integerType
  | Signed : integerBaseType → integerType
  | Unsigned : integerBaseType → integerType
  | Wchar_t : integerType
  | Wint_t : integerType
  | Size_t : integerType
  | Ptrdiff_t : integerType

  deriving instance DecidableEq, Repr for integerType

  inductive realFloatingType where
  | Float : realFloatingType
  | Double : realFloatingType
  | LongDouble : realFloatingType

  deriving instance DecidableEq for realFloatingType

  inductive floatingType where
  | RealFloating : realFloatingType → floatingType

  deriving instance DecidableEq for floatingType

  inductive basicType where
  | Integer : integerType → basicType
  | Floating : floatingType → basicType

  deriving instance DecidableEq for basicType

  structure qualifiers where
    const : Bool
    restrict : Bool
    volatile : Bool

  deriving instance DecidableEq for qualifiers

  /-- A calling convention other than the System V one, which GCC keeps in a function's type. -/
  inductive callingConvention where
  | ms_abi : callingConvention

  deriving instance DecidableEq for callingConvention

  mutual
    inductive ctype where
    | Void : ctype
    | Basic : basicType → ctype
    | Array_ : ctype → Option Int /-array length; interpret n as n.toNat-/ → ctype
    | Function : ctype → cparamtypes → Bool /-is_variadic-/ → ctype
    | FunctionNoParams : qualifiers → ctype → ctype
    /-- A function type with calling convention `cc`, incompatible with every `Function` type. -/
    | FunctionCC : callingConvention → ctype → cparamtypes → Bool /-is_variadic-/ → ctype
    | Pointer : /-qualifiers →-/ ctype → ctype
    | VolatilePointer : ctype → ctype
    | Atomic : ctype → ctype
    | Struct : String → ctype
    | Union : String → ctype
    | Bitfields : List (integerType × Nat) → ctype
    | Byte : ctype
    | VaList : ctype
    | VaListArg : ctype

    inductive cparamtypes where
    | nil
    | cons : ctype → Bool → cparamtypes → cparamtypes
  end

  def cparamtypes.toList (ps : cparamtypes) : List (ctype × Bool) :=
    match ps with
    | nil => []
    | cons τ b ps => (τ, b) :: toList ps

  attribute [pp_nodot] ctype.Array_ ctype.Function ctype.FunctionCC ctype.Pointer ctype.VolatilePointer ctype.Atomic

  deriving instance DecidableEq for ctype, cparamtypes

  @[simp]
  def ctype.definitely_has_nonzero_size (τ : ctype) : Prop :=
    match τ with
    | Void => False
    | Basic _ => True
    | Array_ _ none => False
    | Array_ τ (some n) => n > 0 ∧ τ.definitely_has_nonzero_size
    | Function _ _ _ => False
    | FunctionNoParams _ _ => False
    | FunctionCC _ _ _ _ => False
    | Pointer _ => True
    | VolatilePointer _ => True
    | Atomic τ => τ.definitely_has_nonzero_size
    | Struct _tag => False -- TODO: Be more precise here
    | Union _tag => False -- TODO: Be more precise here
    | Bitfields _ => True
    | Byte => True
    | VaList => True
    | VaListArg => True

  inductive alignment where
  | AlignInteger : Int → alignment
  | AlignType : ctype → alignment

  deriving instance DecidableEq for alignment

  inductive tag_definition where
  | StructDef
      (members : List (String × (Option alignment × /-qualifiers ×-/ ctype)))
      -- Byte offsets in the same order as `members`.
      -- A bit-field cluster has one entry at the byte offset of its first bit-field.
      (member_offsets : List Int)
      (flexible_array_member : Option (String × /-qualifiers ×-/ ctype /-element type-/ × Int /-offset-/))
      (size : Int)
      (alignment : Int)
  | UnionDef
      (members : List (String × (Option alignment × /-qualifiers ×-/ ctype)))
      (size : Int)
      (alignment : Int)
  deriving instance DecidableEq for tag_definition

  abbrev char := integerType.Char
  abbrev bool := integerType.Bool
  abbrev «signed char» := integerType.Signed .Ichar
  abbrev short := integerType.Signed .Short
  abbrev int := integerType.Signed .Int_
  abbrev long := integerType.Signed .Long
  abbrev longlong := integerType.Signed .LongLong
  /-- The C spelling of `longlong`, as `«unsigned long long»` is of its unsigned counterpart; the
  delaborators print it. -/
  abbrev «long long» := integerType.Signed .LongLong
  abbrev intmax_t := integerType.Signed .Intmax_t
  abbrev intptr_t := integerType.Signed .Intptr_t
  abbrev «unsigned char» := integerType.Unsigned .Ichar
  abbrev «unsigned short» := integerType.Unsigned .Short
  abbrev «unsigned int» := integerType.Unsigned .Int_
  abbrev «unsigned long» := integerType.Unsigned .Long
  abbrev «unsigned long long» := integerType.Unsigned .LongLong
  abbrev uintmax_t := integerType.Unsigned .Intmax_t
  abbrev uintptr_t := integerType.Unsigned .Intptr_t
  abbrev wchar_t := integerType.Wchar_t
  abbrev wint_t := integerType.Wint_t
  abbrev size_t := integerType.Size_t
  abbrev ptrdiff_t := integerType.Ptrdiff_t

  attribute [coe] basicType.Integer
  instance : Coe integerType basicType := ⟨basicType.Integer⟩

  attribute [coe] ctype.Basic
  instance : Coe basicType ctype := ⟨ctype.Basic⟩

  abbrev float := ctype.Basic (.Floating (.RealFloating .Float))
  abbrev double := ctype.Basic (.Floating (.RealFloating .Double))
  abbrev «long double» := ctype.Basic (.Floating (.RealFloating .LongDouble))

  postfix:1024 "﹡" => ctype.Pointer

  @[simp]
  def bitfieldValueType (spec : integerType × Nat) : integerType :=
    match spec.fst with
    | .Signed .Ichar | .Signed .Short | .Signed .Long | .Signed (.Int_leastN_t 0) => .Signed (.IntN_t spec.snd)
    | .Unsigned .Ichar | .Unsigned .Short | .Unsigned .Long | .Unsigned (.Int_leastN_t 0) => .Unsigned (.IntN_t spec.snd)
    | ity => ity

  @[simp]
  def bitfieldType (spec : integerType × Nat) : ctype :=
    ctype.Basic (basicType.Integer (bitfieldValueType spec))

  @[simp]
  def bitfieldTypeAt (specs : List (integerType × Nat)) (idx : Nat) : ctype :=
    match specs, idx with
    | [], _ => ctype.Void
    | spec :: _, 0 => bitfieldType spec
    | _ :: specs, idx + 1 => bitfieldTypeAt specs idx

end Ctype

inductive allocation_id where
| AllocId_global : String → allocation_id
| AllocId_dynamic : Nat → allocation_id -- stack- or heap-allocated
| AllocId_threadLocal : Nat → String → allocation_id -- a thread's own object: thread id, name

deriving instance DecidableEq for allocation_id

/-- A non-null address in the target's 64-bit `uintptr_t` range. Address zero is excluded so
that the null pointer is always represented by `pointer_value.PVnull`. -/
abbrev noprov_address := { a : Int // 0 < a ∧ a < 18446744073709551616 }

inductive provenance where
  /-- A pointer with empty provenance at a concrete non-null address. Its address identifies
  the value but does not supply permission to dereference it. -/
  | Prov_empty : noprov_address → provenance
  /-- A pointer into an allocation, with its byte offset and enclosing objects. An enclosure
  `(T, b)` records a `T` object starting at offset `b` that contains the designated bytes.
  The address is determined by the allocation and offset. -/
  | Prov_some : allocation_id → (offset : Int) → (enclosures : List (Ctype.ctype × Int)) →
      provenance
  /-- An integer-derived pointer carrying its address and the allocation used to track its
  lifetime for pointer comparison. This representation alone supplies no memory ownership. -/
  | Prov_int : allocation_id → (address : Int) → provenance

deriving instance DecidableEq for provenance

/-- The location carried by a non-null object pointer. -/
def location := provenance

instance : Inhabited provenance := ⟨.Prov_empty ⟨1, by decide⟩⟩
instance : Inhabited location := ⟨provenance.Prov_empty ⟨1, by decide⟩⟩

abbrev global (ς : String) : location := provenance.Prov_some (.AllocId_global ς) 0 []

/-- Thread `tid`'s instance of object `ς`, such as its `errno` (C11 7.5p2). -/
abbrev threadLocal (tid : Nat) (ς : String) : location :=
  provenance.Prov_some (.AllocId_threadLocal tid ς) 0 []

inductive pointer_value where
  | PVnull : pointer_value
  | PVloc : location → pointer_value
  | PVfunptr : String → pointer_value

notation "null" => pointer_value.PVnull

attribute [coe] pointer_value.PVloc
instance : Coe location pointer_value := ⟨pointer_value.PVloc⟩

inductive pointer_value.IsNull : pointer_value → Prop where
| IsNull_null : pointer_value.IsNull PVnull

instance instDecidable_pointer_value_IsNull pv : Decidable (pointer_value.IsNull pv) := by
  cases pv with
  | PVnull => apply Decidable.isTrue pointer_value.IsNull.IsNull_null
  | _ =>
    apply Decidable.isFalse
    intro h
    cases h

/-- A floating value, represented by its bit pattern. The format (IEEE 754 binary32 for `float`,
binary64 for `double`, x87 80-bit extended precision for `long double`) is part of the value.
A `long double` object has 16 bytes, of
which only the 10 holding these 80 bits are value bytes; the other 6 are padding. -/
inductive floating_value where
  | float (bits : UInt32)
  | double (bits : UInt64)
  | longDouble (bits : BitVec 80)
  deriving DecidableEq

/-- The `float` value denoted by the Lean `Float32` value `f` (e.g. a literal). -/
def floating_value.ofFloat32 (f : Float32) : floating_value := .float f.toBits

/-- The `double` value denoted by the Lean `Float` value `f` (e.g. a literal). -/
def floating_value.ofFloat (f : Float) : floating_value := .double f.toBits

mutual
  inductive object_value where
  | OVinteger : Int → object_value -- TODO: this ignores the fact that integers may have a provenance (specifically, when manually copying a pointer byte-by-byte)
  | OVfloating : floating_value → object_value
  | OVpointer : pointer_value → object_value
  | OVarray : List loaded_value → object_value
  | OVstruct : List loaded_value → object_value
  | OVunion : String /-active member name-/ → loaded_value → object_value
  | OVbitfields : List loaded_value → object_value
  | OVpointer_fragment : pointer_value → Nat /-byte index-/ → object_value

  inductive loaded_value where
  | LVspecified : object_value → loaded_value
  | LVunspecified : Ctype.ctype → loaded_value
end

instance : Inhabited object_value := ⟨object_value.OVinteger 0⟩

instance : Inhabited loaded_value := ⟨loaded_value.LVspecified (object_value.OVinteger 0)⟩

attribute [coe] object_value.OVinteger
instance : Coe Int object_value := ⟨object_value.OVinteger⟩

attribute [coe] object_value.OVpointer
instance : Coe pointer_value object_value := ⟨object_value.OVpointer⟩

attribute [coe] loaded_value.LVspecified
instance : Coe object_value loaded_value := ⟨loaded_value.LVspecified⟩

inductive object_value.IsNull : object_value → Prop where
| IsNull_null : object_value.IsNull null

instance instDecidable_object_value_IsNull v : Decidable (object_value.IsNull v) := by
  cases v with
  | OVpointer pv =>
    cases pv with
    | PVnull => apply Decidable.isTrue object_value.IsNull.IsNull_null
    | _ =>
      apply Decidable.isFalse
      intro h
      cases h
  | _ =>
    apply Decidable.isFalse
    intro h
    cases h

inductive value where
--| Vobject : object_value → value
| Vloaded : loaded_value → value
| Vunit : value
| Vtrue : value
| Vfalse : value
| Vctype : Ctype.ctype → value
| Vlist : List value → value
| Vtuple : List value → value

attribute [coe] value.Vloaded
instance : Coe loaded_value value := ⟨value.Vloaded⟩

abbrev Vobject v := value.Vloaded (loaded_value.LVspecified v)


open loaded_value object_value Ctype.ctype

def loaded_value.elems : loaded_value → List loaded_value
| .LVspecified (.OVarray vs) => vs
| .LVunspecified (.Array_ ty (some n)) => List.replicate n.toNat (LVunspecified ty)
| _ => []

def loaded_value.head (v : loaded_value) : loaded_value := v.elems.head!

-- An array is unspecified iff all elements are unspecified
def loaded_value.cons (v1 v2 : loaded_value) : loaded_value :=
  match v1, v2 with
  | .LVunspecified _, .LVunspecified (Ctype.ctype.Array_ ty (some n)) => .LVunspecified (Ctype.ctype.Array_ ty (some (n + 1)))
  | .LVspecified v1, v2 => .LVspecified (.OVarray (v1 :: v2.elems))
  | v1, .LVspecified (.OVarray vs) => .LVspecified (.OVarray (v1 :: vs))
  | _, _ => default -- Should not happen

def loaded_value.allUnspecifiedOfType (elem_ty : Ctype.ctype) : List loaded_value → Bool
| [] => true
| .LVunspecified ty :: vs => decide (ty = elem_ty) && allUnspecifiedOfType elem_ty vs
| _ => false

def loaded_value.of_elems (elem_ty : Ctype.ctype) (vs : List loaded_value) : loaded_value :=
  if allUnspecifiedOfType elem_ty vs then
    .LVunspecified (Ctype.ctype.Array_ elem_ty (some vs.length))
  else
    .LVspecified (.OVarray vs) -- This hack ensures that `(v.tail elem_ty).elems = v.elems.tail!` holds regardless of `elem_ty`

def loaded_value.tail (elem_ty : Ctype.ctype) : loaded_value → loaded_value
| .LVspecified (.OVarray vs) => loaded_value.of_elems elem_ty vs.tail!
| .LVunspecified (.Array_ ty (some n)) => .LVunspecified (.Array_ ty (some (n - 1)))
| _ => default

def loaded_value.arrayOf (ty : Ctype.ctype) : List loaded_value → loaded_value
  | [] => LVunspecified (Array_ ty (some 0))
  | v :: vs => loaded_value.cons v (loaded_value.arrayOf ty vs)

def loaded_value.structOf (tag : String) (vs : List loaded_value) : loaded_value :=
  if vs.all (fun v => match v with | LVunspecified _ => true | _ => false) then
    LVunspecified (Struct tag)
  else
    LVspecified (OVstruct vs)

abbrev f_LVspecified_OVinteger (v: Int) : loaded_value := LVspecified (OVinteger v)

/-- Whether `p` never dangles: `NULL`, a function pointer, or a pointer into a global's object,
whose storage duration is static (C11 6.2.4p3). A pointer into an object of automatic or allocated
storage duration (a dynamic allocation) dangles once the object's lifetime ends, and so may a
pointer without provenance, which an integer-to-pointer conversion gives: GCC treats it as the
pointer that the integer was computed from (see `int_ptr_alive`). -/
def pointer_value.neverDangles : pointer_value → Bool
  | .PVnull | .PVfunptr _ => true
  | .PVloc (.Prov_empty _) | .PVloc (.Prov_int _ _) => false
  | .PVloc (.Prov_some (.AllocId_global _) _ _) => true
  | .PVloc (.Prov_some (.AllocId_dynamic _) _ _) => false
  -- A thread's own object lives as long as the thread (C11 6.2.4p4).
  | .PVloc (.Prov_some (.AllocId_threadLocal ..) _ _) => false

