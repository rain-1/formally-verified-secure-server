module

public import Mathlib.Order.Notation
public import C2lean.Public.Types

@[expose] public section

/-!
# Integer ranges for public specifications

These definitions state which mathematical integers fit in each C integer type on the target
platform. Integer conversion, bitwise operations and their semantic laws remain private.
-/

@[simp, grind =]
def Ctype.integerType.min_value (τi : Ctype.integerType) : Int :=
  match τi with
  | .Char => -128
  | .Bool => 0
  | .Signed τ =>
    match τ with
    | .Ichar => -128
    | .Short => -32768
    | .Int_ => -2147483648
    | .Long => -9223372036854775808
    | .LongLong => -9223372036854775808
    | .IntN_t n => -2^((1 ⊔ n)-1)
    | .Int_leastN_t n => -2^((1 ⊔ n)-1) -- TODO: check this
    | .Int_fastN_t n => -2^((1 ⊔ n)-1) -- TODO: check this
    | .Intmax_t => -9223372036854775808
    | .Intptr_t => -9223372036854775808
  | .Unsigned _ => 0
  | .Wchar_t => -2147483648
  | .Wint_t => 0
  | .Size_t => 0
  | .Ptrdiff_t => -9223372036854775808

@[simp, grind =]
def Ctype.integerType.max_value (τi : Ctype.integerType) : Int :=
  match τi with
  | .Char => 127
  | .Bool => 1
  | .Signed τ =>
    match τ with
    | .Ichar => 127
    | .Short => 32767
    | .Int_ => 2147483647
    | .Long => 9223372036854775807
    | .LongLong => 9223372036854775807
    | .IntN_t n => 2^((1 ⊔ n)-1) - 1
    | .Int_leastN_t n => 2^((1 ⊔ n)-1) - 1 -- TODO: check this
    | .Int_fastN_t n => 2^((1 ⊔ n)-1) - 1 -- TODO: check this
    | .Intmax_t => 9223372036854775807
    | .Intptr_t => 9223372036854775807
  | .Unsigned τ =>
    match τ with
    | .Ichar => 255
    | .Short => 65535
    | .Int_ => 4294967295
    | .Long => 18446744073709551615
    | .LongLong => 18446744073709551615
    | .IntN_t n => 2^((1 ⊔ n)) - 1
    | .Int_leastN_t n => 2^((1 ⊔ n)) - 1 -- TODO: check this
    | .Int_fastN_t n => 2^((1 ⊔ n)) - 1 -- TODO: check this
    | .Intmax_t => 18446744073709551615
    | .Intptr_t => 18446744073709551615
  | .Wchar_t => 2147483647
  | .Wint_t => 4294967295
  | .Size_t => 18446744073709551615
  | .Ptrdiff_t => 9223372036854775807

@[grind =]
def Ctype.integerType.hasType (τi: Ctype.integerType) (i: Int) : Prop :=
  τi.min_value ≤ i ∧ i ≤ τi.max_value

/- `grind` in Lean 4.34.0 treats `-0` and `0` as distinct literals, so a range proof can fail
kernel checking. Normalize them before arithmetic reasoning. Lean 4.36.0 fixes `grind`;
delete this line then. -/
attribute [grind norm] Int.neg_zero
