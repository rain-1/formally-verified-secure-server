module

public import Mathlib.Data.Rat.Defs
public import C2lean.Public.Types
public import C2lean.IrisCompat

@[expose] public section

open Iris Iris.BI

namespace C2lean.Public

/-- Consecutive ownership, parameterized only by object ownership and pointer arithmetic. -/
@[reducible] def arrayWith {PROP : Type u} [BI PROP]
    (points_to : object_value → Ctype.ctype → ℚ → loaded_value → PROP)
    (array_shift : object_value → Ctype.ctype → object_value → object_value)
    {T : Type} (p : object_value) (τ : Ctype.ctype) (f : T → loaded_value) (q : ℚ) :
    List T → PROP
  | [] => iprop(emp)
  | elem :: elems =>
    iprop(points_to p τ q (f elem) ∗
      arrayWith points_to array_shift (array_shift p τ (.OVinteger 1)) τ f q elems)

end C2lean.Public
