module

-- List functions that use Int for indices and lengths instead of Nat

public import Batteries.Data.List.Lemmas
public import Mathlib.Data.Int.Range
public import Mathlib.Data.List.TakeDrop

@[expose] public section

def List.ilength (xs : List T) : Int := xs.length

@[simp, grind =]
theorem List.ilength_nil :
  [].ilength (T:=T) = 0 := by
  unfold ilength
  simp

@[simp, grind =]
theorem List.ilength_cons (x : T) (xs : List T) :
  (x :: xs).ilength (T:=T) = xs.ilength + 1 := by
  unfold ilength
  simp

@[simp, grind .]
theorem List.ilength_nonneg (xs : List T) :
  0 ≤ xs.ilength := by
  unfold ilength
  simp

instance : GetElem (List T) Int T (λ xs n => 0 ≤ n ∧ n < xs.ilength) := by
  apply GetElem.mk
  intro xs n Hvalid
  apply xs.get
  constructor
  on_goal 2 =>
    exact n.toNat
  unfold List.ilength at Hvalid
  omega

instance List_Int_GetElem? : GetElem? (List T) Int T (λ xs n => 0 ≤ n ∧ n < xs.ilength) := by
  apply GetElem?.mk
  · exact (fun xs n => xs[n.toNat]?)
  · exact (fun xs n => xs[n.toNat]!)

def List.itake (xs : List T) (n : Int) : List T := xs.take n.toNat
def List.idrop (xs : List T) (n : Int) : List T := xs.drop n.toNat

@[simp, grind =]
theorem List.itake_idrop (xs : List T) (n : Int) :
  xs.itake n ++ xs.idrop n = xs := by
  unfold itake idrop
  rw [List.take_append_drop]

theorem drop_succ {T} [Inhabited T] (xs: List T) (k: Nat) :
  k < List.length xs →
  List.drop k xs = xs[k]! :: List.drop (k + 1) xs
  := by
    revert xs
    induction k
    case zero =>
      intros xs Hk
      cases xs
      case nil =>
        grind
      case cons x xs =>
        simp
    case succ k IH =>
      intros xs Hk
      cases xs
      case nil =>
        grind
      case cons x xs =>
        simp
        grind

theorem List.take_succ_getElem! {T} [Inhabited T] {xs : List T} {i : Nat}
    (hi : i < xs.length) :
    xs.take (i + 1) = xs.take i ++ [xs[i]!] := by
  induction xs generalizing i with
  | nil => cases hi
  | cons x xs ih =>
    cases i with
    | zero => rfl
    | succ i =>
      simp only [List.take, List.getElem!_cons_succ]
      rw [ih (by simpa using hi)]
      simp

theorem List.idrop_succ [Inhabited T] {xs : List T} {n : Int}
  (Hn: 0 ≤ n ∧ n < xs.ilength := by omega) :
  xs.idrop n = xs[n]! :: xs.idrop (n + 1) := by
  unfold idrop
  rw [drop_succ]
  simp
  · apply And.intro
    · unfold List_Int_GetElem?
      simp
    · omega
  unfold List.ilength at Hn
  omega

@[simp, grind =]
theorem List.ilength_itake {xs : List T} {n : Int}
  (Hn: 0 ≤ n ∧ n ≤ xs.ilength := by omega) :
  (xs.itake n).ilength = n := by
  unfold itake ilength at *
  rw [List.length_take_of_le]
  on_goal 2 =>
    omega
  omega

theorem List.itake_succ' {T} [Inhabited T] {xs : List T} {n : Int}
    (hn : 0 ≤ n ∧ n < xs.ilength) :
    xs.itake (n + 1) = xs.itake n ++ [xs[n]!] := by
  unfold List.itake List_Int_GetElem?
  have hnat : (n + 1).toNat = n.toNat + 1 := by omega
  rw [hnat, List.take_add_one]
  have hlt : n.toNat < xs.length := by
    unfold List.ilength at hn
    omega
  simp [List.getElem?_eq_getElem hlt]

theorem List.itake_all_of_ilength_le {T} {xs : List T} {n : Int}
    (hn : xs.ilength ≤ n) :
    xs.itake n = xs := by
  unfold List.itake List.ilength at *
  rw [List.take_eq_self_iff]
  omega

@[simp, grind =]
theorem List.ilength_idrop {xs : List T} {n : Int}
  (Hn: 0 ≤ n ∧ n ≤ xs.ilength := by omega) :
  (xs.idrop n).ilength = xs.ilength - n := by
  unfold idrop ilength at *
  rw [List.length_drop]
  omega

theorem List.idrop_all_of_ilength_le {T} {xs : List T} {n : Int}
    (hn : xs.ilength ≤ n) :
    xs.idrop n = [] := by
  unfold List.idrop List.ilength at *
  rw [List.drop_eq_nil_of_le]
  omega

def List.iset (xs : List T) (n : Int) (v : T) : List T := xs.set n.toNat v

@[simp, grind =]
theorem List.ilength_iset {xs : List T} {n : Int} :
  (xs.iset n v).ilength = xs.ilength := by
  unfold iset ilength at *
  rw [List.length_set]

/-- Read-back of a just-written element on a stack array (`t[k] = v; … = t[k]`). The Int index `n`
matches the write index `m`, and is in bounds, so the read returns `v`. Kernel reduction cannot do
this over an opaque base list, hence the explicit lemma. -/
theorem List.getElem!_iset_self {T} [Inhabited T] {xs : List T} {n : Int} {v : T}
    (hn : 0 ≤ n ∧ n < xs.ilength) : (xs.iset n v)[n]! = v := by
  unfold List.iset List.ilength at *
  have hlt : n.toNat < xs.length := by omega
  show (xs.set n.toNat v)[n.toNat]! = v
  rw [getElem!_pos (xs.set n.toNat v) n.toNat (by simpa using hlt)]
  simp [List.getElem_set_self]

/-- Read of an element other than a just-written one: the write at `m` is transparent to a read at a
different index `n`, so it falls through to the underlying list. -/
theorem List.getElem!_iset_ne {T} [Inhabited T] {xs : List T} {m n : Int} {v : T}
    (hmn : m ≠ n) (hm : 0 ≤ m) (hnn : 0 ≤ n) : (xs.iset m v)[n]! = xs[n]! := by
  unfold List.iset at *
  show (xs.set m.toNat v)[n.toNat]! = xs[n.toNat]!
  by_cases hb : n.toNat < xs.length
  · rw [getElem!_pos (xs.set m.toNat v) n.toNat (by simpa [List.length_set] using hb),
        getElem!_pos xs n.toNat hb, List.getElem_set]
    have : ¬ (m.toNat = n.toNat) := by omega
    simp [this]
  · rw [getElem!_neg (xs.set m.toNat v) n.toNat (by rw [List.length_set]; exact hb),
        getElem!_neg xs n.toNat hb]

theorem List.iset_eq_itake_cons_idrop {xs : List T} {n : Int}
  (Hn: 0 ≤ n ∧ n < xs.ilength := by omega)
  {v : T} :
  xs.iset n v = xs.itake n ++ v :: xs.idrop (n + 1) := by
  unfold iset itake idrop ilength at *
  rw [List.set_eq_take_cons_drop]
  have h: n.toNat + 1 = (n + 1).toNat := by
    omega
  rw [h]
  omega

theorem List.swapped_prefix_get_suffix {T} [Inhabited T] {xs ys : List T} {i : Int}
    (hys : ys.ilength = xs.ilength) (hi : 0 ≤ i ∧ i < xs.ilength) :
    (ys.itake i ++ xs.idrop i)[i]! = xs[i]! := by
  unfold List.itake List.idrop List_Int_GetElem?
  unfold List.ilength at hys hi
  have hlen : (ys.take i.toNat).length = i.toNat := by
    simp only [List.length_take]; omega
  simp only [List.getElem!_eq_getElem?_getD,
    List.getElem?_append_right (by omega : (ys.take i.toNat).length ≤ i.toNat), hlen]
  simp [List.getElem?_drop]

theorem List.swapped_prefix_iset_nat {T} [Inhabited T] {xs ys : List T} {i : Nat}
    (hys : ys.length = xs.length) (hi : i < xs.length) :
    (ys.take i ++ xs.drop i).set i ys[i]! =
      ys.take (i + 1) ++ xs.drop (i + 1) := by
  have htake : (ys.take i).length = i := by simp; omega
  rw [List.set_append_right]
  · rw [show i - (ys.take i).length = 0 by omega]
    rw [List.drop_eq_getElem_cons hi]
    simp only [List.set]
    rw [List.take_succ_getElem! (xs:=ys) (i:=i) (by omega)]
    simp
  · omega

theorem List.swapped_prefix_iset {T} [Inhabited T] {xs ys : List T} {i : Int}
    (hys : ys.ilength = xs.ilength) (hi : 0 ≤ i ∧ i < xs.ilength) :
    (ys.itake i ++ xs.idrop i).iset i ys[i]! =
      ys.itake (i + 1) ++ xs.idrop (i + 1) := by
  unfold List.iset List.itake List.idrop List.ilength at *
  change (List.take i.toNat ys ++ List.drop i.toNat xs).set i.toNat ys[i]! =
    List.take (i + 1).toNat ys ++ List.drop (i + 1).toNat xs
  have hnat : (i + 1).toNat = i.toNat + 1 := by omega
  rw [hnat]
  change (List.take i.toNat ys ++ List.drop i.toNat xs).set i.toNat ys[i.toNat]! =
    List.take (i.toNat + 1) ys ++ List.drop (i.toNat + 1) xs
  exact List.swapped_prefix_iset_nat (xs:=xs) (ys:=ys) (i:=i.toNat) (by omega) (by omega)

theorem List.swapped_prefix_done {T} {xs ys : List T} {n : Int}
    (hys : ys.ilength = xs.ilength) (hn : xs.ilength ≤ n) :
    ys.itake n ++ xs.idrop n = ys := by
  rw [List.itake_all_of_ilength_le (xs:=ys) (n:=n) (by omega)]
  rw [List.idrop_all_of_ilength_le (xs:=xs) (n:=n) hn]
  simp

@[simp, grind =]
theorem List.ilength_irange {n : Int}
  (Hn: 0 ≤ n := by omega) :
  (Int.range 0 n).ilength = n := by
  unfold ilength Int.range
  simp
  omega

theorem List.irange_succ {n : Int}
 (Hn: 0 ≤ n := by omega) :
  Int.range 0 (n + 1) = Int.range 0 n ++ [n] := by
  unfold Int.range
  simp
  have h: n.toNat + 1 = (n + 1).toNat := by
    omega
  rw [← h]
  rw [List.range_succ]
  simp
  assumption

@[simp, grind =]
theorem List.getElem_irange {i b a : Int}
  (Hi: 0 ≤ i ∧ i < b - a := by omega) :
  (Int.range a b)[i]! = a + i := by
  unfold Int.range List_Int_GetElem?
  simp
  rw [List.getElem?_range]
  · simp
    omega
  · omega

@[simp, grind =]
theorem List.irange_nil k :
  Int.range k k = [] := by
  unfold Int.range
  simp
