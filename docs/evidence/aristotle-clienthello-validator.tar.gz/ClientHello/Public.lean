module

public import C2lean.Public

@[expose] public section

noncomputable section

namespace «ClientHello»

open Ctype.integerBaseType Ctype.integerType Ctype.realFloatingType Ctype.floatingType Ctype.basicType Ctype.ctype Ctype.tag_definition pointer_value object_value loaded_value value
set_option compiler.extract_closed false

/-! The public interface of the translation unit: its tag definitions and named function handles.
State properties using these and `C2lean.Public.Vocab` (see `C2lean/Public.lean`).
`Program.lean` retains the function signatures and implementation. -/

open C2lean.Public

def tagDefs : List (String × Ctype.tag_definition) := [
  ("__cerb.__mbstate_t", StructDef [("__count", none, Basic (Integer (Signed Int_))), ("__value", none, Union "__cerb.__mbstate_t.__value")] [0, 4] none 8 4),
  ("__cerb.__mbstate_t.__value", UnionDef [("__wch", none, Basic (Integer (Unsigned Int_))), ("__wchb", none, Array_ (Basic (Integer Char)) (some 4))] 4 4),
  ("_G_fpos_t", StructDef [("__pos", none, Basic (Integer (Signed Long))), ("__state", none, Struct "__cerb.__mbstate_t")] [0, 8] none 16 8),
  ("_G_fpos64_t", StructDef [("__pos", none, Basic (Integer (Signed Long))), ("__state", none, Struct "__cerb.__mbstate_t")] [0, 8] none 16 8),
  ("div", StructDef [("quot", none, Basic (Integer (Signed Int_))), ("rem", none, Basic (Integer (Signed Int_)))] [0, 4] none 8 4),
  ("ldiv", StructDef [("quot", none, Basic (Integer (Signed Long))), ("rem", none, Basic (Integer (Signed Long)))] [0, 8] none 16 8),
  ("lldiv", StructDef [("quot", none, Basic (Integer (Signed LongLong))), ("rem", none, Basic (Integer (Signed LongLong)))] [0, 8] none 16 8),
  ("__cerbty_sigset_t", StructDef [("__val", none, Array_ (Basic (Integer (Unsigned Long))) (some 16))] [0] none 128 8),
  ("__cerbty_pthread_attr_t", StructDef [("__data", some (.AlignInteger 8), Array_ (Basic (Integer (Unsigned Ichar))) (some 56))] [0] none 56 8),
  ("__cerbty_pthread_barrier_t", StructDef [("__data", some (.AlignInteger 8), Array_ (Basic (Integer (Unsigned Ichar))) (some 32))] [0] none 32 8),
  ("__cerbty_pthread_barrierattr_t", StructDef [("__data", some (.AlignInteger 4), Array_ (Basic (Integer (Unsigned Ichar))) (some 4))] [0] none 4 4),
  ("__cerbty_pthread_cond_t", StructDef [("__data", some (.AlignInteger 8), Array_ (Basic (Integer (Unsigned Ichar))) (some 48))] [0] none 48 8),
  ("__cerbty_pthread_condattr_t", StructDef [("__data", some (.AlignInteger 4), Array_ (Basic (Integer (Unsigned Ichar))) (some 4))] [0] none 4 4),
  ("__pthread_internal_list", StructDef [("__prev", none, Pointer (Struct "__pthread_internal_list")), ("__next", none, Pointer (Struct "__pthread_internal_list"))] [0, 8] none 16 8),
  (
    "__pthread_mutex_s",
    StructDef
      [
        ("__lock", none, Basic (Integer (Signed Int_))),
        ("__count", none, Basic (Integer (Unsigned Int_))),
        ("__owner", none, Basic (Integer (Signed Int_))),
        ("__nusers", none, Basic (Integer (Unsigned Int_))),
        ("__kind", none, Basic (Integer (Signed Int_))),
        ("__spins", none, Basic (Integer (Signed Short))),
        ("__elision", none, Basic (Integer (Signed Short))),
        ("__list", none, Struct "__pthread_internal_list")
      ]
      [0, 4, 8, 12, 16, 20, 22, 24]
      none
      40
      8
  ),
  (
    "__cerbty_pthread_mutex_t",
    UnionDef [("__data", none, Struct "__pthread_mutex_s"), ("__size", none, Array_ (Basic (Integer Char)) (some 40)), ("__align", none, Basic (Integer (Signed Long)))] 40 8
  ),
  ("__cerbty_pthread_mutexattr_t", StructDef [("__data", some (.AlignInteger 4), Array_ (Basic (Integer (Unsigned Ichar))) (some 4))] [0] none 4 4),
  ("__cerbty_pthread_rwlock_t", StructDef [("__data", some (.AlignInteger 8), Array_ (Basic (Integer (Unsigned Ichar))) (some 56))] [0] none 56 8),
  ("__cerbty_pthread_rwlockattr_t", StructDef [("__data", some (.AlignInteger 8), Array_ (Basic (Integer (Unsigned Ichar))) (some 8))] [0] none 8 8),
  ("__cerb.fd_set", StructDef [("fds_bits", none, Array_ (Basic (Integer (Signed Long))) (some 16))] [0] none 128 8),
  ("timeval", StructDef [("tv_sec", none, Basic (Integer (Signed Long))), ("tv_usec", none, Basic (Integer (Signed Long)))] [0, 8] none 16 8),
  ("timespec", StructDef [("tv_sec", none, Basic (Integer (Signed Long))), ("tv_nsec", none, Basic (Integer (Signed Long)))] [0, 8] none 16 8),
  (
    "random_data",
    StructDef
      [
        ("fptr", none, Pointer (Basic (Integer (Signed Int_)))),
        ("rptr", none, Pointer (Basic (Integer (Signed Int_)))),
        ("state", none, Pointer (Basic (Integer (Signed Int_)))),
        ("rand_type", none, Basic (Integer (Signed Int_))),
        ("rand_deg", none, Basic (Integer (Signed Int_))),
        ("rand_sep", none, Basic (Integer (Signed Int_))),
        ("end_ptr", none, Pointer (Basic (Integer (Signed Int_))))
      ]
      [0, 8, 16, 24, 28, 32, 40]
      none
      48
      8
  ),
  (
    "drand48_data",
    StructDef
      [
        ("__x", none, Array_ (Basic (Integer (Unsigned Short))) (some 3)),
        ("__old_x", none, Array_ (Basic (Integer (Unsigned Short))) (some 3)),
        ("__c", none, Basic (Integer (Unsigned Short))),
        ("__init", none, Basic (Integer (Unsigned Short))),
        ("__a", none, Basic (Integer (Unsigned LongLong)))
      ]
      [0, 6, 12, 14, 16]
      none
      24
      8
  ),
  (
    "EVERPARSE_ERROR_FRAME_s",
    StructDef
      [
        ("filled", none, Basic (Integer (Unsigned Ichar))),
        ("start_pos", none, Basic (Integer (Unsigned Long))),
        ("typename_s", none, Pointer (Basic (Integer Char))),
        ("fieldname", none, Pointer (Basic (Integer Char))),
        ("reason", none, Pointer (Basic (Integer Char))),
        ("error_code", none, Basic (Integer (Unsigned Long)))
      ]
      [0, 8, 16, 24, 32, 40]
      none
      48
      8
  ),
  (
    "tm",
    StructDef
      [
        ("tm_sec", none, Basic (Integer (Signed Int_))),
        ("tm_min", none, Basic (Integer (Signed Int_))),
        ("tm_hour", none, Basic (Integer (Signed Int_))),
        ("tm_mday", none, Basic (Integer (Signed Int_))),
        ("tm_mon", none, Basic (Integer (Signed Int_))),
        ("tm_year", none, Basic (Integer (Signed Int_))),
        ("tm_wday", none, Basic (Integer (Signed Int_))),
        ("tm_yday", none, Basic (Integer (Signed Int_))),
        ("tm_isdst", none, Basic (Integer (Signed Int_))),
        ("tm_gmtoff", none, Basic (Integer (Signed Long))),
        ("tm_zone", none, Pointer (Basic (Integer Char)))
      ]
      [0, 4, 8, 12, 16, 20, 24, 28, 32, 40, 48]
      none
      56
      8
  ),
  (
    "termios",
    StructDef
      [
        ("c_iflag", none, Basic (Integer (Unsigned Int_))),
        ("c_oflag", none, Basic (Integer (Unsigned Int_))),
        ("c_cflag", none, Basic (Integer (Unsigned Int_))),
        ("c_lflag", none, Basic (Integer (Unsigned Int_))),
        ("c_line", none, Basic (Integer (Unsigned Ichar))),
        ("c_cc", none, Array_ (Basic (Integer (Unsigned Ichar))) (some 32)),
        ("c_ispeed", none, Basic (Integer (Unsigned Int_))),
        ("c_ospeed", none, Basic (Integer (Unsigned Int_)))
      ]
      [0, 4, 8, 12, 16, 17, 52, 56]
      none
      60
      4
  )
]

def Fn.memcpy : _root_.C2lean.Public.CFun := {name:="memcpy"}

def Fn.«ClientHello#__c2l_endian_bswap16» : _root_.C2lean.Public.CFun := {name:="ClientHello#__c2l_endian_bswap16"}

def Fn.«ClientHello#Load16» : _root_.C2lean.Public.CFun := {name:="ClientHello#Load16"}

def Fn.«ClientHello#EverParseGetBitfield8» : _root_.C2lean.Public.CFun := {name:="ClientHello#EverParseGetBitfield8"}

def Fn.«ClientHello#EverParseGetBitfield16» : _root_.C2lean.Public.CFun := {name:="ClientHello#EverParseGetBitfield16"}

def Fn.«ClientHello#EverParseGetBitfield32» : _root_.C2lean.Public.CFun := {name:="ClientHello#EverParseGetBitfield32"}

def Fn.«ClientHello#EverParseGetBitfield64» : _root_.C2lean.Public.CFun := {name:="ClientHello#EverParseGetBitfield64"}

def Fn.«ClientHello#EverParseIsError» : _root_.C2lean.Public.CFun := {name:="ClientHello#EverParseIsError"}

def Fn.«ClientHello#EverParseIsSuccess» : _root_.C2lean.Public.CFun := {name:="ClientHello#EverParseIsSuccess"}

def Fn.«ClientHello#EverParseSetValidatorErrorPos» : _root_.C2lean.Public.CFun := {name:="ClientHello#EverParseSetValidatorErrorPos"}

def Fn.«ClientHello#EverParseGetValidatorErrorKind» : _root_.C2lean.Public.CFun := {name:="ClientHello#EverParseGetValidatorErrorKind"}

def Fn.«ClientHello#EverParseErrorReasonOfResult» : _root_.C2lean.Public.CFun := {name:="ClientHello#EverParseErrorReasonOfResult"}

def Fn.«ClientHello#EverParseCheckConstraintOk» : _root_.C2lean.Public.CFun := {name:="ClientHello#EverParseCheckConstraintOk"}

def Fn.ClientHelloValidateClientHelloBody : _root_.C2lean.Public.CFun := {name:="ClientHelloValidateClientHelloBody"}

def Fn.«ClientHello#ValidateExtension» : _root_.C2lean.Public.CFun := {name:="ClientHello#ValidateExtension"}

